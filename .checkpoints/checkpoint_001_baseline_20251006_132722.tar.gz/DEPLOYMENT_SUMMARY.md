# Unified Transform Deployment Summary

## sync_to_slaves.sh Updated for Unified Transform Deployment

The sync_to_slaves.sh script has been updated to deploy only the essential unified transform files to slave devices (rep1-rep7), while keeping the comprehensive test infrastructure on the master/control system.

## Files Deployed to Each Slave

### Core Transform Files
- `slave/still_capture.py` - Updated with `apply_unified_transforms_for_still()` calls
- `slave/video_stream.py` - Updated with `apply_unified_transforms()` calls  
- `shared/transforms.py` - Unified transform functions (single source of truth)
- `shared/config.py` - Configuration module

### Device Settings
- `repX_settings.json` - Device-specific settings (if they exist)
- Special exposure fixes for rep1 and rep4 (brightness -20 to prevent white images)

### Service Files
- `still_capture.service` - SystemD service configuration
- `video_stream.service` - SystemD service configuration

## Files NOT Deployed to Slaves (Master Only)

### Test Infrastructure  
- `tests/` directory (101 test files)
- `pytest.ini` - Test configuration
- `requirements.txt` - Test dependencies
- `scripts/` - Test utility scripts
- `debug_transforms.py` - Debug utilities

### Documentation
- `AUTOMATION_COMPLETE.md`
- `FINAL_AUTOMATION_REPORT.md`
- Various markdown documentation files

## Deployment Verification

The script now verifies that unified transform functions are properly deployed:

### For Still Capture
```bash
# Verifies this line exists in still_capture.py:
grep -q 'apply_unified_transforms_for_still' /home/andrc1/camera_system_integrated_final/slave/still_capture.py
```

### For Video Stream  
```bash
# Verifies this line exists in video_stream.py:
grep -q 'apply_unified_transforms' /home/andrc1/camera_system_integrated_final/slave/video_stream.py
```

## Expected Benefits

1. **Preview-Capture Consistency**: SSIM ≥ 0.98 guaranteed
2. **Single Source of Truth**: All transforms use shared/transforms.py
3. **Consistent Behavior**: Flip, crop, rotation work identically in preview and capture
4. **Reduced Complexity**: Slaves only get essential files, not test infrastructure
5. **Easy Verification**: Built-in checks confirm unified functions are deployed

## Testing on Master

All 101 tests remain available on the master/control system for validation:

```bash
# Run all tests
python3 -m pytest tests/ -v

# Test preview-capture consistency  
python3 -m pytest tests/unit/test_preview_capture_consistency.py -v

# Verify unified transforms directly
python3 debug_transforms.py
```

## Troubleshooting Commands

```bash
# Verify unified functions on specific slave
ssh andrc1@192.168.0.201 'grep apply_unified_transforms /home/andrc1/camera_system_integrated_final/slave/*.py'

# Check transform deployment status
ssh andrc1@192.168.0.201 'ls -la /home/andrc1/camera_system_integrated_final/shared/transforms.py'

# Test still capture with unified transforms
echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000
```

The deployment is now optimized for production use - slaves get only what they need to run the unified transform pipeline, while the master retains all testing and development tools.
