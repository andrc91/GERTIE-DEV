#!/usr/bin/env python3
"""
Focused coverage test for transform functionality
Tests the specific functions we refactored for consistency
"""

import sys
import os
import coverage

# Add project to path
sys.path.insert(0, '/Users/andrew1/Desktop/camera_system_integrated_final')

def test_transform_coverage():
    """Test coverage of transform functions specifically"""
    # Start coverage measurement
    cov = coverage.Coverage(source=['shared.transforms'])
    cov.start()
    
    try:
        # Import and test all the transform functions
        from shared.transforms import (
            apply_unified_transforms, 
            apply_unified_transforms_for_still,
            apply_crop_rgb,
            apply_rotation_rgb,
            load_device_settings,
            save_device_settings,
            get_device_name_from_ip,
            DEFAULT_SETTINGS
        )
        
        import numpy as np
        
        # Create test image
        test_image = np.zeros((100, 100, 3), dtype=np.uint8)
        test_image[:, :, 0] = 255  # Red image
        
        # Test all transform functions
        print("Testing apply_unified_transforms...")
        result1 = apply_unified_transforms(test_image, "test_device")
        
        print("Testing apply_unified_transforms_for_still...")
        result2 = apply_unified_transforms_for_still(test_image, "test_device")
        
        print("Testing apply_crop_rgb...")
        settings = DEFAULT_SETTINGS.copy()
        settings['crop_enabled'] = True
        settings['crop_x'] = 10
        settings['crop_y'] = 10
        settings['crop_width'] = 50
        settings['crop_height'] = 50
        result3 = apply_crop_rgb(test_image, settings)
        
        print("Testing apply_rotation_rgb...")
        result4 = apply_rotation_rgb(test_image, 90)
        
        print("Testing device name function...")
        device_name = get_device_name_from_ip()
        
        print("Testing settings functions...")
        settings = load_device_settings("test_device")
        save_result = save_device_settings("test_device", settings)
        
        print("✅ All transform functions executed successfully")
        
    except Exception as e:
        print(f"❌ Error testing transform functions: {e}")
        return False
    
    finally:
        # Stop coverage and generate report
        cov.stop()
        cov.save()
        
        print("\n" + "="*50)
        print("TRANSFORM FUNCTION COVERAGE REPORT")
        print("="*50)
        
        # Generate coverage report
        cov.report(show_missing=True)
        
        # Get coverage percentage
        total_coverage = cov.report(skip_empty=True)
        
        print(f"\nOverall transform coverage: {total_coverage:.1f}%")
        
        if total_coverage >= 90:
            print("✅ Coverage target met (≥90%)")
            return True
        else:
            print(f"❌ Coverage target not met: {total_coverage:.1f}% < 90%")
            return False

if __name__ == "__main__":
    success = test_transform_coverage()
    sys.exit(0 if success else 1)
