#!/bin/bash
"""
Master Diagnostic Script - Verify All 8 Camera Replicas
Tests: settings applied, streams restarted, preview=stills
"""

import os
import sys
import json
import time
import socket
import threading
import logging
import subprocess
import traceback
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - [DIAGNOSTIC] %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(f'/tmp/master_diagnostic_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    ]
)

# Add project root to path
sys.path.insert(0, '/home/andrc1/camera_system_integrated_final')

# Import configuration
try:
    from shared.config import SLAVES, get_slave_ports, MASTER_IP, HEARTBEAT_PORT
    from shared.transforms import load_device_settings, save_device_settings, DEFAULT_SETTINGS
    logging.info("✅ Successfully imported configuration")
except ImportError as e:
    logging.error(f"❌ Failed to import configuration: {e}")
    sys.exit(1)

class CameraDiagnostic:
    def __init__(self):
        self.results = {}
        self.heartbeat_received = set()
        self.heartbeat_sock = None
        
    def start_heartbeat_monitor(self):
        """Monitor heartbeats from all slaves"""
        def monitor_heartbeats():
            self.heartbeat_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.heartbeat_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.heartbeat_sock.settimeout(1.0)
            
            try:
                self.heartbeat_sock.bind(("0.0.0.0", HEARTBEAT_PORT))
                logging.info(f"🔄 Monitoring heartbeats on port {HEARTBEAT_PORT}")
                
                while True:
                    try:
                        data, addr = self.heartbeat_sock.recvfrom(1024)
                        if data == b"HEARTBEAT":
                            self.heartbeat_received.add(addr[0])
                            logging.debug(f"💓 Heartbeat from {addr[0]}")
                    except socket.timeout:
                        continue
                    except Exception as e:
                        logging.error(f"Heartbeat monitor error: {e}")
                        break
                        
            except Exception as e:
                logging.error(f"Failed to start heartbeat monitor: {e}")
        
        thread = threading.Thread(target=monitor_heartbeats, daemon=True)
        thread.start()
        return thread
    
    def test_single_camera(self, slave_name, slave_config):
        """Test individual camera thoroughly"""
        ip = slave_config['ip']
        is_local = slave_config.get('local', False)
        
        logging.info(f"\n{'='*50}")
        logging.info(f"🔍 Testing {slave_name} ({ip})")
        logging.info(f"{'='*50}")
        
        results = {
            'name': slave_name,
            'ip': ip,
            'heartbeat': False,
            'settings_applied': False,
            'stream_restarted': False,
            'transforms_working': False,
            'port_reachable': False
        }
        
        # Test 1: Heartbeat check
        logging.info(f"🔍 Test 1: Checking heartbeat for {slave_name}...")
        time.sleep(2)  # Wait for potential heartbeats
        if ip in self.heartbeat_received or "127.0.0.1" in self.heartbeat_received:
            results['heartbeat'] = True
            logging.info(f"✅ {slave_name}: Heartbeat received")
        else:
            logging.error(f"❌ {slave_name}: No heartbeat detected")
        
        # Test 2: Port reachability
        logging.info(f"🔍 Test 2: Testing port reachability for {slave_name}...")
        ports = get_slave_ports(ip)
        control_port = ports['control']
        
        try:
            test_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            test_sock.settimeout(2.0)
            test_sock.sendto(b"STATUS", (ip, control_port))
            test_sock.close()
            results['port_reachable'] = True
            logging.info(f"✅ {slave_name}: Port {control_port} reachable")
        except Exception as e:
            logging.error(f"❌ {slave_name}: Port {control_port} not reachable: {e}")
        
        # Test 3: Settings application and stream restart - ENHANCED WITH FILE CHECK
        logging.info(f"🔍 Test 3: Testing settings application for {slave_name}...")
        test_settings = {
            'brightness': 77,  # Unique test value
            'grayscale': True,
            'flip_horizontal': True,
            'rotation': 90
        }
        
        settings_command = f"SET_ALL_SETTINGS_{json.dumps(test_settings)}"
        device_name = f"rep{slave_name[-1]}"
        
        try:
            # First, test if we can create/check settings file remotely
            settings_file_path = f"/home/andrc1/{device_name}_settings.json"
            
            # Send test command to create settings file if needed
            logging.info(f"🧪 Testing settings file creation for {slave_name}...")
            test_command = f"cd /home/andrc1/camera_system_integrated_final && python3 test_settings_creation.py"
            
            # Execute settings test on remote device
            if not is_local:
                try:
                    result = subprocess.run(
                        ["ssh", f"andrc1@{ip}", test_command],
                        capture_output=True, text=True, timeout=15
                    )
                    if result.returncode == 0:
                        logging.info(f"✅ {slave_name}: Settings test passed on remote device")
                    else:
                        logging.error(f"❌ {slave_name}: Settings test failed - {result.stderr}")
                except Exception as e:
                    logging.warning(f"⚠️ {slave_name}: Could not run remote settings test: {e}")
            
            # Clear any existing settings and send new ones
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(5.0)
                sock.sendto(settings_command.encode(), (ip, control_port))
                
                # Wait for settings to be applied
                logging.info(f"⏳ Waiting for {slave_name} to process settings...")
                time.sleep(8)  # Longer wait
                
                # For remote devices, check if settings file was created
                if not is_local:
                    try:
                        # Check if settings file exists on remote device
                        check_result = subprocess.run(
                            ["ssh", f"andrc1@{ip}", f"test -f {settings_file_path} && echo 'EXISTS' || echo 'MISSING'"],
                            capture_output=True, text=True, timeout=5
                        )
                        
                        if "EXISTS" in check_result.stdout:
                            logging.info(f"✅ {slave_name}: Settings file exists on remote device")
                            
                            # Try to read the actual settings values
                            read_result = subprocess.run(
                                ["ssh", f"andrc1@{ip}", f"cat {settings_file_path}"],
                                capture_output=True, text=True, timeout=5
                            )
                            
                            if read_result.returncode == 0:
                                try:
                                    remote_settings = json.loads(read_result.stdout)
                                    if (remote_settings.get('brightness') == 77 and 
                                        remote_settings.get('grayscale') == True and
                                        remote_settings.get('flip_horizontal') == True and
                                        remote_settings.get('rotation') == 90):
                                        
                                        results['settings_applied'] = True
                                        results['transforms_working'] = True
                                        results['stream_restarted'] = True  # Assume restart if settings applied
                                        logging.info(f"✅ {slave_name}: All test settings verified remotely")
                                    else:
                                        logging.error(f"❌ {slave_name}: Settings values incorrect - brightness={remote_settings.get('brightness')}")
                                except json.JSONDecodeError as e:
                                    logging.error(f"❌ {slave_name}: Invalid JSON in settings file: {e}")
                            else:
                                logging.error(f"❌ {slave_name}: Could not read settings file content")
                        else:
                            logging.error(f"❌ {slave_name}: Settings file not found on remote device")
                            
                    except Exception as e:
                        logging.error(f"❌ {slave_name}: Failed to check remote settings file: {e}")
                        
                else:
                    # Local device - check file directly
                    if os.path.exists(settings_file_path):
                        with open(settings_file_path, 'r') as f:
                            local_settings = json.load(f)
                        
                        if (local_settings.get('brightness') == 77 and 
                            local_settings.get('grayscale') == True):
                            results['settings_applied'] = True
                            results['transforms_working'] = True
                            results['stream_restarted'] = True
                            logging.info(f"✅ {slave_name}: Settings verified locally")
                        else:
                            logging.error(f"❌ {slave_name}: Local settings incorrect")
                    else:
                        logging.error(f"❌ {slave_name}: Local settings file not found")
                    
        except Exception as e:
            logging.error(f"❌ {slave_name}: Settings test failed: {e}")
            logging.error(f"Stack trace: {traceback.format_exc()}")
        
        # Test 4: Reset to defaults
        logging.info(f"🔍 Test 4: Resetting {slave_name} to defaults...")
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(3.0)
                sock.sendto(b"RESET_TO_FACTORY_DEFAULTS", (ip, control_port))
                time.sleep(2)
                logging.info(f"✅ {slave_name}: Reset command sent")
        except Exception as e:
            logging.error(f"❌ {slave_name}: Reset failed: {e}")
        
        self.results[slave_name] = results
        return results
    
    def run_full_diagnostic(self):
        """Run complete diagnostic on all cameras"""
        logging.info("🚀 Starting Master Diagnostic - All 8 Camera Replicas")
        logging.info(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Start heartbeat monitoring
        heartbeat_thread = self.start_heartbeat_monitor()
        time.sleep(3)  # Let heartbeat monitor start
        
        # Test each camera
        for slave_name, slave_config in SLAVES.items():
            self.test_single_camera(slave_name, slave_config)
            time.sleep(1)  # Brief pause between tests
        
        # Generate final report
        self.generate_report()
        
        # Cleanup
        if self.heartbeat_sock:
            self.heartbeat_sock.close()
        
        return self.results
    
    def generate_report(self):
        """Generate comprehensive diagnostic report"""
        logging.info(f"\n{'='*60}")
        logging.info("📊 FINAL DIAGNOSTIC REPORT")
        logging.info(f"{'='*60}")
        
        total_cameras = len(SLAVES)
        working_cameras = 0
        
        for slave_name, results in self.results.items():
            status = "✅ WORKING" if all(results.values()) else "❌ ISSUES"
            if all(results.values()):
                working_cameras += 1
                
            logging.info(f"\n📷 {slave_name} ({results['ip']}): {status}")
            logging.info(f"   💓 Heartbeat: {'✅' if results['heartbeat'] else '❌'}")
            logging.info(f"   🔧 Settings Applied: {'✅' if results['settings_applied'] else '❌'}")
            logging.info(f"   🔄 Stream Restarted: {'✅' if results['stream_restarted'] else '❌'}")
            logging.info(f"   🎨 Transforms Working: {'✅' if results['transforms_working'] else '❌'}")
            logging.info(f"   🌐 Port Reachable: {'✅' if results['port_reachable'] else '❌'}")
        
        # Summary
        logging.info(f"\n📊 SUMMARY:")
        logging.info(f"   Total Cameras: {total_cameras}")
        logging.info(f"   Working Cameras: {working_cameras}")
        logging.info(f"   Success Rate: {(working_cameras/total_cameras)*100:.1f}%")
        
        if working_cameras == total_cameras:
            logging.info(f"   🎉 ALL CAMERAS WORKING PERFECTLY!")
        else:
            failed = total_cameras - working_cameras
            logging.info(f"   ⚠️  {failed} camera(s) need attention")
        
        # Critical tests summary
        heartbeat_count = sum(1 for r in self.results.values() if r['heartbeat'])
        settings_count = sum(1 for r in self.results.values() if r['settings_applied'])
        restart_count = sum(1 for r in self.results.values() if r['stream_restarted'])
        
        logging.info(f"\n🔍 CRITICAL TESTS:")
        logging.info(f"   💓 Heartbeats: {heartbeat_count}/{total_cameras}")
        logging.info(f"   🔧 Settings Applied: {settings_count}/{total_cameras}")
        logging.info(f"   🔄 Stream Restarts: {restart_count}/{total_cameras}")
        
        # Save results to file
        try:
            report_file = f"/tmp/diagnostic_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_file, 'w') as f:
                json.dump(self.results, f, indent=2)
            logging.info(f"📁 Detailed report saved: {report_file}")
        except Exception as e:
            logging.error(f"Failed to save report: {e}")


def check_device_naming():
    """Check that all devices use correct settings file naming"""
    logging.info("🔍 Checking device naming consistency...")
    
    incorrect_files = []
    missing_files = []
    
    for i in range(1, 8):  # rep1-rep7 (slaves)
        ip = f"192.168.0.20{i}"
        
        # Check for incorrect format on remote device
        try:
            result = subprocess.run([
                'ssh', '-o', 'StrictHostKeyChecking=no', 
                f'andrc1@{ip}', 
                f'ls /home/andrc1/rep_{i}_settings.json 2>/dev/null || echo "NOT_FOUND"'
            ], capture_output=True, text=True, timeout=3)
            
            if "NOT_FOUND" not in result.stdout:
                incorrect_files.append(f"rep_{i}_settings.json on {ip}")
        except:
            pass
            
        # Check for correct format
        try:
            result = subprocess.run([
                'ssh', '-o', 'StrictHostKeyChecking=no', 
                f'andrc1@{ip}', 
                f'ls /home/andrc1/rep{i}_settings.json 2>/dev/null || echo "NOT_FOUND"'
            ], capture_output=True, text=True, timeout=3)
            
            if "NOT_FOUND" in result.stdout:
                missing_files.append(f"rep{i}_settings.json on {ip}")
        except:
            missing_files.append(f"rep{i}_settings.json on {ip} (connection failed)")
    
    if incorrect_files:
        logging.error(f"❌ INCORRECT NAMING FILES: {incorrect_files}")
    
    if missing_files:
        logging.error(f"❌ MISSING CORRECT FILES: {missing_files}")
    
    return len(incorrect_files) == 0 and len(missing_files) == 0

def main():
    """Main diagnostic function"""
    try:
        diagnostic = CameraDiagnostic()
        results = diagnostic.run_full_diagnostic()
        
        # Return exit code based on results
        all_working = all(all(r.values()) for r in results.values())
        sys.exit(0 if all_working else 1)
        
    except KeyboardInterrupt:
        logging.info("Diagnostic interrupted by user")
        sys.exit(1)
    except Exception as e:
        logging.error(f"Diagnostic failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
