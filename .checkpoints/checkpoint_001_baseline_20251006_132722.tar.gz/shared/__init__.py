# Makes 'shared' a package so 'from shared.config import ...' works


