#!/usr/bin/env python3
"""
High Resolution Still Capture Test Script
Verifies that still captures are producing high resolution images
Run on control1 or any slave to test resolution settings
"""

import json
import os
import logging
import subprocess
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def check_settings_resolution():
    """Check resolution settings in all device settings files"""
    logging.info("🔍 Checking resolution settings in device files...")
    
    settings_files = [
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep1_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep2_settings.json", 
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep3_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep4_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep5_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep6_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep7_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep8_settings.json"
    ]
    
    all_high_res = True
    
    for settings_file in settings_files:
        if os.path.exists(settings_file):
            try:
                with open(settings_file, 'r') as f:
                    settings = json.load(f)
                
                resolution = settings.get('resolution', 'unknown')
                jpeg_quality = settings.get('jpeg_quality', 'unknown')
                crop_width = settings.get('crop_width', 'unknown')
                crop_height = settings.get('crop_height', 'unknown')
                
                device = os.path.basename(settings_file).replace('_settings.json', '')
                
                if resolution == '4608x2592':
                    logging.info(f"✅ {device}: Resolution {resolution} (HIGH RES)")
                else:
                    logging.error(f"❌ {device}: Resolution {resolution} (LOW RES)")
                    all_high_res = False
                
                if jpeg_quality >= 90:
                    logging.info(f"✅ {device}: JPEG Quality {jpeg_quality}% (HIGH QUALITY)")
                else:
                    logging.warning(f"⚠️  {device}: JPEG Quality {jpeg_quality}% (could be higher)")
                
                if crop_width == 4608 and crop_height == 2592:
                    logging.info(f"✅ {device}: Crop {crop_width}x{crop_height} (FULL SENSOR)")
                else:
                    logging.warning(f"⚠️  {device}: Crop {crop_width}x{crop_height} (not full sensor)")
                    
                logging.info(f"   {device}: Complete settings - resolution={resolution}, quality={jpeg_quality}%, crop={crop_width}x{crop_height}")
                
            except Exception as e:
                logging.error(f"❌ Failed to read {settings_file}: {e}")
                all_high_res = False
        else:
            logging.warning(f"⚠️  Settings file not found: {settings_file}")
    
    return all_high_res

def test_libcamera_command():
    """Test that libcamera-still command includes high resolution parameters"""
    logging.info("🧪 Testing libcamera-still command generation...")
    
    try:
        # Import the functions from still_capture.py
        import sys
        sys.path.insert(0, "/Users/andrew1/Desktop/camera_system_integrated_final/slave")
        
        # We can't actually import and run the functions on Mac due to missing dependencies,
        # but we can check that the code structure is correct
        with open("/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py", 'r') as f:
            content = f.read()
        
        # Check for high resolution indicators in the code
        indicators = [
            '--width', '--height',  # Resolution parameters
            '--quality',            # JPEG quality parameter  
            '4608', '2592',        # High resolution values
            'jpeg_quality', '95'   # High quality settings
        ]
        
        found_indicators = []
        for indicator in indicators:
            if indicator in content:
                found_indicators.append(indicator)
        
        logging.info(f"✅ Found high resolution indicators: {found_indicators}")
        
        if '--width' in content and '--height' in content and '--quality' in content:
            logging.info("✅ libcamera-still command includes resolution and quality parameters")
            return True
        else:
            logging.error("❌ libcamera-still command missing resolution or quality parameters")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to test libcamera command: {e}")
        return False

def check_processing_resolution():
    """Check that Picamera2 processing uses high resolution"""
    logging.info("🔍 Checking Picamera2 processing resolution...")
    
    try:
        with open("/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py", 'r') as f:
            content = f.read()
        
        # Look for the still configuration
        if 'main={"size": (4608, 2592)}' in content:
            logging.info("✅ Picamera2 still configuration uses high resolution (4608x2592)")
            return True
        else:
            logging.error("❌ Picamera2 still configuration not using high resolution")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to check processing resolution: {e}")
        return False

def generate_test_recommendations():
    """Generate recommendations for testing high resolution captures"""
    logging.info("📋 TEST RECOMMENDATIONS:")
    logging.info("========================")
    logging.info("")
    logging.info("1. DEPLOY FIXES TO SLAVES:")
    logging.info("   cd ~/Desktop/camera_system_integrated_final")
    logging.info("   ./sync_to_slaves.sh")
    logging.info("")
    logging.info("2. TEST STILL CAPTURE:")
    logging.info("   echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000")
    logging.info("")
    logging.info("3. CHECK LOGS FOR HIGH RESOLUTION:")
    logging.info("   ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since=\"1 minute ago\" | grep \"HIGH RES\"'")
    logging.info("")
    logging.info("4. VERIFY IMAGE PROPERTIES:")
    logging.info("   ssh andrc1@192.168.0.201 'ls -la /home/andrc1/camera_system_integrated_final/captured_images/'")
    logging.info("   ssh andrc1@192.168.0.201 'file /home/andrc1/camera_system_integrated_final/captured_images/rep1_*.jpg | head -1'")
    logging.info("")
    logging.info("5. EXPECTED RESULTS:")
    logging.info("   • Image size: >2MB (was <200KB)")
    logging.info("   • Dimensions: 4608x2592 pixels")
    logging.info("   • Quality: 95% JPEG compression")
    logging.info("   • Logs show: 'HIGH RES image saved'")

def main():
    """Main high resolution test function"""
    logging.info("📸 HIGH RESOLUTION STILL CAPTURE TEST")
    logging.info("=====================================")
    
    try:
        # Check settings files
        settings_ok = check_settings_resolution()
        
        # Check libcamera command
        libcamera_ok = test_libcamera_command()
        
        # Check processing resolution
        processing_ok = check_processing_resolution()
        
        # Overall result
        logging.info("")
        logging.info("📊 TEST RESULTS:")
        logging.info("================")
        
        if settings_ok:
            logging.info("✅ Settings files: All configured for high resolution")
        else:
            logging.error("❌ Settings files: Some not configured for high resolution")
        
        if libcamera_ok:
            logging.info("✅ libcamera-still: Includes resolution and quality parameters")
        else:
            logging.error("❌ libcamera-still: Missing resolution or quality parameters")
        
        if processing_ok:
            logging.info("✅ Picamera2 processing: Uses high resolution configuration")
        else:
            logging.error("❌ Picamera2 processing: Not using high resolution")
        
        if settings_ok and libcamera_ok and processing_ok:
            logging.info("")
            logging.info("🎉 HIGH RESOLUTION FIX READY FOR DEPLOYMENT!")
            logging.info("All components configured for high resolution still captures")
        else:
            logging.error("")
            logging.error("⚠️  HIGH RESOLUTION FIX NEEDS ATTENTION")
            logging.error("Some components not properly configured")
        
        # Generate test recommendations
        logging.info("")
        generate_test_recommendations()
        
    except Exception as e:
        logging.error(f"❌ Test failed: {e}")

if __name__ == "__main__":
    main()
