from master.gui import launch_gui
import threading
import tkinter as tk

if __name__ == "__main__":
    launch_gui()
