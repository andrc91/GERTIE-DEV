#!/bin/bash

# DEFINITIVE FIX DEPLOYMENT SCRIPT
# Deploys fixes for:
# - Bug A: flip_vertical brightness preservation
# - Bug B: RGB/BGR color channel fixes
# - Device naming: proper rep1-7 settings files

echo "🚀 DEPLOYING DEFINITIVE FIXES FOR CAMERA SYSTEM"
echo "================================================"

# Configuration
SCRIPT_DIR="/Users/andrew1/Desktop/camera_system_integrated_final"
SSH_KEY="~/.ssh/id_rsa"
SSH_OPTS="-i $SSH_KEY -o StrictHostKeyChecking=no -o ConnectTimeout=10"
USERNAME="andrc1"

# Source files (fixed versions)
VIDEO_STREAM_FIXED="$SCRIPT_DIR/slave/video_stream_fixed.py"
STILL_CAPTURE_FIXED="$SCRIPT_DIR/slave/still_capture_fixed.py"

# Target path on each Pi
TARGET_DIR="/home/andrc1/camera_system_integrated_final/slave"

echo "📋 DEPLOYMENT PLAN:"
echo "- Deploy video_stream_fixed.py -> video_stream.py"
echo "- Deploy still_capture_fixed.py -> still_capture.py"
echo "- Restart services on rep1-7"
echo ""

# Function to deploy to a single rep
deploy_to_rep() {
    local rep_num=$1
    local ip="192.168.0.20$rep_num"
    
    echo "🔧 DEPLOYING TO REP$rep_num ($ip)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $ip >/dev/null 2>&1; then
        echo "❌ rep$rep_num ($ip) not reachable - skipping"
        return 1
    fi
    
    # Deploy video stream script
    echo "  📤 Deploying video_stream_fixed.py..."
    if scp $SSH_OPTS "$VIDEO_STREAM_FIXED" "$USERNAME@$ip:$TARGET_DIR/video_stream.py"; then
        echo "  ✅ video_stream.py deployed to rep$rep_num"
    else
        echo "  ❌ Failed to deploy video_stream.py to rep$rep_num"
        return 1
    fi
    
    # Deploy still capture script
    echo "  📤 Deploying still_capture_fixed.py..."
    if scp $SSH_OPTS "$STILL_CAPTURE_FIXED" "$USERNAME@$ip:$TARGET_DIR/still_capture.py"; then
        echo "  ✅ still_capture.py deployed to rep$rep_num"
    else
        echo "  ❌ Failed to deploy still_capture.py to rep$rep_num"
        return 1
    fi
    
    # Restart services
    echo "  🔄 Restarting services on rep$rep_num..."
    if ssh $SSH_OPTS "$USERNAME@$ip" "sudo systemctl restart video_stream.service && sudo systemctl restart still_capture.service"; then
        echo "  ✅ Services restarted on rep$rep_num"
    else
        echo "  ⚠️  Service restart may have failed on rep$rep_num"
    fi
    
    # Verify deployment
    echo "  🔍 Verifying deployment on rep$rep_num..."
    if ssh $SSH_OPTS "$USERNAME@$ip" "head -n 5 $TARGET_DIR/video_stream.py | grep -q 'DEFINITIVE FIXED'"; then
        echo "  ✅ rep$rep_num verification passed"
    else
        echo "  ❌ rep$rep_num verification failed"
        return 1
    fi
    
    echo "  🎉 rep$rep_num deployment COMPLETE"
    echo ""
    return 0
}

# Check if source files exist
if [[ ! -f "$VIDEO_STREAM_FIXED" ]]; then
    echo "❌ Source file not found: $VIDEO_STREAM_FIXED"
    exit 1
fi

if [[ ! -f "$STILL_CAPTURE_FIXED" ]]; then
    echo "❌ Source file not found: $STILL_CAPTURE_FIXED"
    exit 1
fi

echo "✅ Source files verified"
echo ""

# Deploy to all reps
successful_deploys=0
failed_deploys=0

for rep_num in {1..7}; do
    if deploy_to_rep $rep_num; then
        ((successful_deploys++))
    else
        ((failed_deploys++))
    fi
done

echo "📊 DEPLOYMENT SUMMARY:"
echo "======================"
echo "✅ Successful: $successful_deploys/7"
echo "❌ Failed: $failed_deploys/7"
echo ""

if [[ $failed_deploys -eq 0 ]]; then
    echo "🎉 ALL DEPLOYMENTS SUCCESSFUL!"
    echo ""
    echo "🧪 TESTING INSTRUCTIONS:"
    echo "1. Test flip_vertical on any rep - brightness should stay constant"
    echo "2. Test preview colors - red objects should appear red (not blue)"
    echo "3. Check logs for 'BRIGHTNESS_PRESERVED' messages"
    echo "4. Verify each rep loads its own settings file (rep1_settings.json, etc.)"
    echo ""
    echo "✅ FIXES DEPLOYED - BUGS A & B SHOULD BE RESOLVED"
else
    echo "⚠️  Some deployments failed. Check individual rep status above."
    echo "💡 You may need to manually deploy to failed reps"
fi

echo ""
echo "📋 NEXT STEPS:"
echo "1. Test the fixes using the GUI"
echo "2. Monitor logs on each rep for any issues"
echo "3. Verify colors and brightness preservation"
echo ""
echo "🎯 BUGS TARGETED:"
echo "- Bug A: flip_vertical brightness preservation ✅"
echo "- Bug B: RGB/BGR color channel fixes ✅"
echo "- Device naming: proper settings file loading ✅"
