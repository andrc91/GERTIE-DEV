#!/bin/bash
# Settings File Monitor - run on Pi to detect incorrect file access
echo "🔍 Monitoring settings file access..."
echo "Watching for incorrect underscore format access..."

# Monitor file system for settings file access
inotifywait -m -r /home/andrc1 --format '%w%f %e' -e access,modify,create,delete | while read file event; do
    if [[ "$file" == *"rep_"*"_settings.json" ]]; then
        echo "❌ INCORRECT FILE ACCESS DETECTED: $file ($event)"
        echo "🔧 This should be: $(echo $file | sed 's/rep_/rep/g')"
    elif [[ "$file" == *"rep"*"_settings.json" ]] && [[ "$file" != *"rep_"* ]]; then
        echo "✅ Correct file access: $file ($event)"
    fi
done
