#!/bin/bash
"""
Deployment Script - Apply All Camera System Fixes
Run this on the master to deploy fixes to all cameras
"""

set -e  # Exit on any error

LOG_FILE="/tmp/camera_deploy_$(date +%Y%m%d_%H%M%S).log"
SCRIPT_DIR="/home/andrc1/camera_system_integrated_final"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo -e "$1" | tee -a "$LOG_FILE"
}

log_success() {
    log "${GREEN}✅ $1${NC}"
}

log_error() {
    log "${RED}❌ $1${NC}"
}

log_info() {
    log "${YELLOW}🔍 $1${NC}"
}

# Check if running on master
check_master() {
    log_info "Checking if running on master device..."
    LOCAL_IP=$(hostname -I | awk '{print $1}')
    if [[ "$LOCAL_IP" != "192.168.0.200" ]]; then
        log_error "This script must run on the master device (192.168.0.200)"
        log_error "Current IP: $LOCAL_IP"
        exit 1
    fi
    log_success "Running on master device"
}

# Stop all camera services
stop_services() {
    log_info "Stopping all camera services..."
    
    # Stop local camera service
    sudo systemctl stop local-camera-slave 2>/dev/null || true
    
    # Stop slave services (updated names)
    sudo systemctl stop video_stream.service 2>/dev/null || true
    sudo systemctl stop still_capture.service 2>/dev/null || true
    
    log_success "All services stopped"
}

# Deploy to remote slaves
deploy_to_slaves() {
    log_info "Deploying to remote slaves (rep1-rep7)..."
    
    # SSH options for strict RSA only
    SSH_OPTS="-o StrictHostKeyChecking=no -o PubkeyAcceptedAlgorithms=+ssh-rsa -o UserKnownHostsFile=/dev/null"
    
    for i in {1..7}; do
        SLAVE_IP="192.168.0.20$i"
        log_info "Deploying to rep$i ($SLAVE_IP)..."
        
        # Copy updated files with strict RSA
        if scp $SSH_OPTS "$SCRIPT_DIR/shared/transforms.py" "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/shared/"; then
            log_success "rep$i: transforms.py deployed"
        else
            log_error "rep$i: Failed to deploy transforms.py"
            continue
        fi
        
        if scp $SSH_OPTS "$SCRIPT_DIR/slave/still_capture.py" "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/slave/"; then
            log_success "rep$i: still_capture.py deployed"
        else
            log_error "rep$i: Failed to deploy still_capture.py"
        fi
        
        if scp $SSH_OPTS "$SCRIPT_DIR/slave/video_stream.py" "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/slave/"; then
            log_success "rep$i: video_stream.py deployed"
        else
            log_error "rep$i: Failed to deploy video_stream.py"
        fi
        
        # Restart services on slave with correct names and sudo
        if ssh $SSH_OPTS "andrc1@$SLAVE_IP" "sudo systemctl restart still_capture.service video_stream.service"; then
            log_success "rep$i: Services restarted"
        else
            log_error "rep$i: Failed to restart services"
        fi
    done
}

# Deploy locally for rep8
deploy_local() {
    log_info "Deploying local camera fixes (rep8)..."
    
    # Create default settings files for all reps
    log_info "Creating default settings files..."
    cd "$SCRIPT_DIR"
    if python3 create_default_settings.py; then
        log_success "Default settings files created"
    else
        log_error "Failed to create default settings files"
    fi
    
    # transforms.py already in place
    log_success "rep8: transforms.py in place"
    
    # Restart local camera service with sudo
    if sudo systemctl restart local-camera-slave 2>/dev/null; then
        log_success "rep8: Local camera service restarted"
    else
        log_info "rep8: Starting local camera manually..."
        # Kill any existing process
        sudo pkill -f local_camera_slave.py 2>/dev/null || true
        sleep 2
        
        # Start manually if systemctl not available
        cd "$SCRIPT_DIR"
        sudo -u andrc1 python3 local_camera_slave.py > /tmp/local_camera.log 2>&1 &
        LOCAL_PID=$!
        log_success "rep8: Local camera started (PID: $LOCAL_PID)"
    fi
}

# Run diagnostic verification
run_diagnostic() {
    log_info "Running comprehensive diagnostic..."
    
    cd "$SCRIPT_DIR"
    
    if python3 master_diagnostic_comprehensive.py; then
        log_success "🎉 DIAGNOSTIC PASSED - All cameras working!"
        return 0
    else
        log_error "❌ DIAGNOSTIC FAILED - Some cameras have issues"
        return 1
    fi
}

# Main deployment process
main() {
    log_info "🚀 Starting Camera System Fix Deployment"
    log_info "📅 $(date)"
    log_info "📁 Log file: $LOG_FILE"
    
    check_master
    
    log_info "Step 1: Stopping services..."
    stop_services
    
    log_info "Step 2: Deploying to remote slaves..."
    deploy_to_slaves
    
    log_info "Step 3: Deploying local camera fixes..."
    deploy_local
    
    log_info "Step 4: Waiting for services to stabilize..."
    sleep 10
    
    log_info "Step 5: Running diagnostic verification..."
    if run_diagnostic; then
        log_success "🎉 DEPLOYMENT SUCCESSFUL - All fixes applied!"
        log_info "📊 Check diagnostic logs for detailed results"
        exit 0
    else
        log_error "⚠️  DEPLOYMENT ISSUES - Check diagnostic output"
        log_info "🔧 Manual fixes may be needed for failed cameras"
        exit 1
    fi
}

# Show usage if requested
if [[ "$1" == "--help" || "$1" == "-h" ]]; then
    echo "Camera System Fix Deployment Script"
    echo "Usage: $0 [--help]"
    echo ""
    echo "This script:"
    echo "1. Stops all camera services"
    echo "2. Deploys fixes to all 8 cameras"
    echo "3. Restarts services"
    echo "4. Runs comprehensive diagnostic"
    echo ""
    echo "Must run on master device (192.168.0.200)"
    exit 0
fi

# Run main deployment
main "$@"
