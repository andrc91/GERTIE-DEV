#!/usr/bin/env python3
"""
Simple Device Naming Test - No OpenCV dependency
Tests the device name generation without imports that require camera libraries
"""

import sys
import os
import json
import socket
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')

def test_device_name_generation():
    """Test device name generation logic directly"""
    logging.info("🔍 Testing device name generation logic...")
    
    # Test the device name generation logic directly
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        last_octet = local_ip.split('.')[-1]
        
        logging.info(f"Local IP: {local_ip}")
        logging.info(f"Last octet: {last_octet}")
        
        # Simulate the device name mapping logic
        if last_octet in ['1', '201']:
            device_name = "rep1"
        elif last_octet in ['2', '202']:
            device_name = "rep2"
        elif last_octet in ['3', '203']:
            device_name = "rep3"
        elif last_octet in ['4', '204']:
            device_name = "rep4"
        elif last_octet in ['5', '205']:
            device_name = "rep5"
        elif last_octet in ['6', '206']:
            device_name = "rep6"
        elif last_octet in ['7', '207']:
            device_name = "rep7"
        else:
            device_name = "rep8"  # Local camera or unknown
        
        logging.info(f"Generated device name: {device_name}")
        
        # Test that it doesn't have underscore
        if "_" in device_name:
            logging.error(f"❌ Device name '{device_name}' contains underscore - BUG FOUND!")
            return False
        else:
            logging.info(f"✅ Device name '{device_name}' has correct format (no underscore)")
        
        # Test that it follows repX pattern
        if device_name.startswith("rep") and len(device_name) == 4 and device_name[3].isdigit():
            logging.info(f"✅ Device name '{device_name}' follows correct repX pattern")
        else:
            logging.error(f"❌ Device name '{device_name}' doesn't follow repX pattern")
            return False
        
        return True
        
    except Exception as e:
        logging.error(f"❌ Device name generation failed: {e}")
        return False

def test_old_vs_new_formats():
    """Test old buggy format vs new correct format"""
    logging.info("🔍 Testing old vs new device naming formats...")
    
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        last_octet = local_ip.split('.')[-1]
        
        # OLD FORMAT (with underscore) - THE BUG
        old_format = f"rep_{last_octet}"
        old_filename = f"{old_format}_settings.json"
        
        # NEW FORMAT (no underscore) - THE FIX
        if last_octet in ['1', '201']:
            new_format = "rep1"
        elif last_octet in ['2', '202']:
            new_format = "rep2"
        elif last_octet in ['3', '203']:
            new_format = "rep3"
        elif last_octet in ['4', '204']:
            new_format = "rep4"
        elif last_octet in ['5', '205']:
            new_format = "rep5"
        elif last_octet in ['6', '206']:
            new_format = "rep6"
        elif last_octet in ['7', '207']:
            new_format = "rep7"
        else:
            new_format = "rep8"
        
        new_filename = f"{new_format}_settings.json"
        
        logging.info(f"OLD (buggy) format: {old_format} → file: {old_filename}")
        logging.info(f"NEW (fixed) format: {new_format} → file: {new_filename}")
        
        # Show the difference
        if old_format != new_format:
            logging.info(f"✅ Fixed the underscore bug: {old_format} → {new_format}")
            return True
        else:
            logging.info(f"✅ Device name already correct: {new_format}")
            return True
            
    except Exception as e:
        logging.error(f"❌ Format comparison failed: {e}")
        return False

def test_all_device_mappings():
    """Test all possible device name mappings"""
    logging.info("🔍 Testing all device IP → name mappings...")
    
    test_cases = [
        ("192.168.0.201", "rep1"),
        ("192.168.0.202", "rep2"), 
        ("192.168.0.203", "rep3"),
        ("192.168.0.204", "rep4"),
        ("192.168.0.205", "rep5"),
        ("192.168.0.206", "rep6"),
        ("192.168.0.207", "rep7"),
        ("127.0.0.1", "rep8"),
        ("10.10.110.9", "rep8"),  # Current system
    ]
    
    for test_ip, expected_name in test_cases:
        last_octet = test_ip.split('.')[-1]
        
        # Apply mapping logic (corrected)
        if ip.startswith("127.") or ip == "localhost":
            device_name = "rep8"  # Local camera
        elif ip == "192.168.0.200":
            device_name = "rep8"  # Master device
        elif ip.startswith("192.168.0.20"):
            last_octet = ip.split('.')[-1]
            if last_octet == '1':
                device_name = "rep1"
            elif last_octet == '2':
                device_name = "rep2"
            elif last_octet == '3':
                device_name = "rep3"
            elif last_octet == '4':
                device_name = "rep4"
            elif last_octet == '5':
                device_name = "rep5"
            elif last_octet == '6':
                device_name = "rep6"
            elif last_octet == '7':
                device_name = "rep7"
            else:
                device_name = "rep8"
        else:
            device_name = "rep8"  # Unknown/local
        
        if device_name == expected_name:
            logging.info(f"✅ {test_ip} → {device_name} (correct)")
        else:
            logging.error(f"❌ {test_ip} → {device_name} (expected {expected_name})")
            return False
    
    logging.info("✅ All device mappings are correct")
    return True

def main():
    """Main test function"""
    logging.info("🚀 Simple Device Naming Test")
    
    success = True
    
    # Test 1: Basic device name generation
    if not test_device_name_generation():
        logging.error("❌ Device name generation test failed")
        success = False
    
    # Test 2: Old vs new format comparison
    if not test_old_vs_new_formats():
        logging.error("❌ Format comparison test failed")
        success = False
    
    # Test 3: All device mappings
    if not test_all_device_mappings():
        logging.error("❌ Device mapping test failed")
        success = False
    
    if success:
        logging.info("🎉 ALL DEVICE NAMING TESTS PASSED!")
        logging.info("✅ Devices will create correct settings files:")
        logging.info("   rep1_settings.json (not rep_1_settings.json)")
        logging.info("   rep2_settings.json (not rep_2_settings.json)")
        logging.info("   rep3_settings.json (not rep_3_settings.json)")
        logging.info("   ... etc for all 8 devices")
        logging.info("✅ Default settings confirmed:")
        logging.info("   brightness: 50, contrast: 50")
        logging.info("   flip_horizontal: false, flip_vertical: false")
        logging.info("   grayscale: false, rotation: 0")
    else:
        logging.error("❌ Some device naming tests failed")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
