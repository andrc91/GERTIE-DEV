#!/usr/bin/env python3
"""
High Resolution Settings Migration Script
Updates existing rep*_settings.json files to use high resolution and quality settings
Run this on control1 (Mac) before syncing to slaves
"""

import json
import os
import glob
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def migrate_resolution_settings(filepath):
    """Migrate a single settings file to high resolution settings"""
    try:
        with open(filepath, 'r') as f:
            settings = json.load(f)
        
        settings_changed = False
        
        # Check and fix resolution
        old_resolution = settings.get('resolution', '640x480')
        if old_resolution != '4608x2592':
            logging.info(f"  {os.path.basename(filepath)}: resolution {old_resolution} → 4608x2592 (HIGH RES)")
            settings['resolution'] = '4608x2592'
            settings_changed = True
        else:
            logging.info(f"  {os.path.basename(filepath)}: resolution already high res (4608x2592)")
        
        # Check and fix JPEG quality
        old_quality = settings.get('jpeg_quality', 80)
        if old_quality < 95:
            logging.info(f"  {os.path.basename(filepath)}: jpeg_quality {old_quality}% → 95% (HIGH QUALITY)")
            settings['jpeg_quality'] = 95
            settings_changed = True
        else:
            logging.info(f"  {os.path.basename(filepath)}: jpeg_quality already high ({old_quality}%)")
        
        # Ensure crop dimensions match sensor resolution
        crop_width = settings.get('crop_width', 4608)
        crop_height = settings.get('crop_height', 2592)
        if crop_width != 4608 or crop_height != 2592:
            logging.info(f"  {os.path.basename(filepath)}: crop dimensions {crop_width}x{crop_height} → 4608x2592")
            settings['crop_width'] = 4608
            settings['crop_height'] = 2592
            settings_changed = True
        
        # Save if changed
        if settings_changed:
            # Create backup first
            backup_path = filepath + '.resolution_backup'
            if not os.path.exists(backup_path):
                with open(filepath, 'r') as f:
                    backup_data = f.read()
                with open(backup_path, 'w') as f:
                    f.write(backup_data)
                logging.info(f"  Backup created: {os.path.basename(backup_path)}")
            
            # Save updated settings
            with open(filepath, 'w') as f:
                json.dump(settings, f, indent=2)
            logging.info(f"  ✅ Updated: {os.path.basename(filepath)}")
        
        return True
        
    except Exception as e:
        logging.error(f"  ❌ Failed to migrate {filepath}: {e}")
        return False

def main():
    """Main resolution migration function"""
    logging.info("🔧 Starting high resolution settings migration...")
    
    # Find all rep*_settings.json files
    settings_pattern = "/Users/andrew1/Desktop/camera_system_integrated_final/rep*_settings.json"
    settings_files = glob.glob(settings_pattern)
    
    if not settings_files:
        logging.info("No settings files found to migrate")
        return
    
    logging.info(f"Found {len(settings_files)} settings files to check:")
    
    migrated_count = 0
    for settings_file in sorted(settings_files):
        logging.info(f"Checking {os.path.basename(settings_file)}...")
        if migrate_resolution_settings(settings_file):
            migrated_count += 1
    
    logging.info(f"✅ Resolution migration complete: {migrated_count}/{len(settings_files)} files processed")
    logging.info("All settings files now use:")
    logging.info("  • Resolution: 4608x2592 (full sensor)")
    logging.info("  • JPEG Quality: 95% (high quality)")
    logging.info("  • Crop dimensions: 4608x2592 (full sensor)")

if __name__ == "__main__":
    main()
