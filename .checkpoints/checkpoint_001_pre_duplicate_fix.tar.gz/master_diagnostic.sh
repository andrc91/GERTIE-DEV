#!/bin/bash
# Comprehensive Multi-Camera System Diagnostic Script
# Run on control1 to test GUI → slave command flow and settings application

echo "🔬 MULTI-CAMERA SYSTEM COMPREHENSIVE DIAGNOSTIC"
echo "==============================================="
echo "Testing command delivery, settings persistence, and stream restart behavior"
echo ""

# Configuration
MASTER_IP="127.0.0.1"
SLAVES=("192.168.0.201" "192.168.0.202" "192.168.0.203" "192.168.0.204" "192.168.0.205" "192.168.0.206" "192.168.0.207")
TEST_SETTINGS='{"iso":800,"brightness":70,"flip_horizontal":true,"grayscale":true,"rotation":90}'

echo "📋 TESTING CONFIGURATION:"
echo "Master IP: $MASTER_IP"
echo "Remote slaves: ${SLAVES[*]}"
echo "Test settings: $TEST_SETTINGS"
echo ""

# Function to test command delivery
test_command_delivery() {
    local ip=$1
    local name=$2
    local port=$3
    local command=$4
    
    echo -n "  📤 Testing $name ($ip:$port) with '$command': "
    
    # Send command with timeout
    if timeout 3 bash -c "echo '$command' | nc -u -w 2 $ip $port" 2>/dev/null; then
        echo "✅ Delivered"
        return 0
    else
        echo "❌ Failed"
        return 1
    fi
}

echo "1. COMMAND DELIVERY TEST"
echo "======================="
echo "Testing if commands reach slave processes..."

# Test control ports (still_capture.py listens here)
for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    test_command_delivery "${SLAVES[$i]}" "rep$rep_num control" 5001 "STATUS"
done

# Test video control ports (video_stream.py listens here)  
for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    test_command_delivery "${SLAVES[$i]}" "rep$rep_num video_control" 5004 "STATUS"
done

# Test rep8 (local camera)
test_command_delivery "127.0.0.1" "rep8 control" 5011 "STATUS"

echo ""

echo "2. SETTINGS PACKAGE DELIVERY TEST" 
echo "================================="
echo "Testing SET_ALL_SETTINGS command delivery..."

# Test settings to control ports (where still_capture.py listens)
echo "📋 Testing settings delivery to control ports (still_capture.py):"
for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    echo -n "  rep$rep_num control port: "
    
    if timeout 5 bash -c "echo 'SET_ALL_SETTINGS_$TEST_SETTINGS' | nc -u -w 3 ${SLAVES[$i]} 5001" 2>/dev/null; then
        echo "✅ Settings sent"
    else
        echo "❌ Settings failed"
    fi
done

# Test settings to video control ports (where video_stream.py listens) 
echo "📋 Testing settings delivery to video control ports (video_stream.py):"
for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    echo -n "  rep$rep_num video_control port: "
    
    if timeout 5 bash -c "echo 'SET_ALL_SETTINGS_$TEST_SETTINGS' | nc -u -w 3 ${SLAVES[$i]} 5004" 2>/dev/null; then
        echo "✅ Settings sent"
    else
        echo "❌ Settings failed"
    fi
done

echo ""

echo "3. SERVICE STATUS CHECK"
echo "======================"
echo "Verifying slave services are running and listening on correct ports..."

for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    ip="${SLAVES[$i]}"
    
    echo "📊 rep$rep_num ($ip):"
    
    # Check if SSH is available
    if timeout 5 ssh -i ~/.ssh/id_rsa -o ConnectTimeout=2 andrc1@$ip "echo connected" 2>/dev/null | grep -q "connected"; then
        echo "  🔗 SSH: ✅ Connected"
        
        # Check services
        video_status=$(ssh -i ~/.ssh/id_rsa andrc1@$ip "systemctl is-active video_stream.service" 2>/dev/null)
        still_status=$(ssh -i ~/.ssh/id_rsa andrc1@$ip "systemctl is-active still_capture.service" 2>/dev/null)
        
        if [ "$video_status" = "active" ]; then
            echo "  🎥 video_stream.service: ✅ Active"
        else
            echo "  🎥 video_stream.service: ❌ $video_status"
        fi
        
        if [ "$still_status" = "active" ]; then
            echo "  📷 still_capture.service: ✅ Active"
        else
            echo "  📷 still_capture.service: ❌ $still_status"
        fi
        
        # Check ports
        echo "  🔍 Port check:"
        ssh -i ~/.ssh/id_rsa andrc1@$ip "netstat -tuln 2>/dev/null | grep ':5001'" && echo "    Port 5001 (control): ✅" || echo "    Port 5001 (control): ❌"
        ssh -i ~/.ssh/id_rsa andrc1@$ip "netstat -tuln 2>/dev/null | grep ':5004'" && echo "    Port 5004 (video_control): ✅" || echo "    Port 5004 (video_control): ❌"
        
    else
        echo "  🔗 SSH: ❌ Not reachable"
    fi
    echo ""
done

echo "4. STREAM RESTART BEHAVIOR TEST"
echo "==============================="
echo "Testing if video streams restart after settings changes..."

# Send START_STREAM to all replicas first
echo "📺 Starting all video streams..."
for i in "${!SLAVES[@]}"; do
    rep_num=$((i + 1))
    echo -n "  rep$rep_num: "
    if timeout 3 bash -c "echo 'START_STREAM' | nc -u -w 2 ${SLAVES[$i]} 5004" 2>/dev/null; then
        echo "✅ START_STREAM sent"
    else
        echo "❌ START_STREAM failed"
    fi
done

echo ""
echo "⏳ Waiting 5 seconds for streams to establish..."
sleep 5

# Test settings change and monitor for restart
echo "🔧 Sending settings change to rep1 and monitoring..."
echo "SET_ALL_SETTINGS_$TEST_SETTINGS" | nc -u -w 2 192.168.0.201 5001

echo "⏳ Waiting 3 seconds for potential restart..."
sleep 3

# Check if rep1 video stream is still active
echo -n "📊 rep1 video stream status after settings: "
if timeout 3 bash -c "echo 'STATUS' | nc -u -w 2 192.168.0.201 5004" 2>/dev/null; then
    echo "✅ Stream responsive"
else
    echo "❌ Stream not responsive"
fi

echo ""

echo "5. SETTINGS PERSISTENCE TEST"
echo "============================"
echo "Testing if settings persist in still_capture.py memory..."

# Send settings to rep2
echo "🔧 Sending test settings to rep2..."
echo "SET_ALL_SETTINGS_$TEST_SETTINGS" | nc -u -w 2 192.168.0.202 5001

echo "⏳ Waiting 2 seconds for settings to apply..."
sleep 2

# Check if we can capture a still (which would use the settings)
echo "📷 Requesting still capture from rep2 to test settings application..."
echo "CAPTURE_STILL" | nc -u -w 2 192.168.0.202 5001

echo ""

echo "6. LOG ANALYSIS"
echo "==============="
echo "Checking recent service logs for errors..."

for i in {1..2}; do  # Check first 2 reps for brevity
    rep_num=$i
    ip="192.168.0.20$rep_num"
    
    echo "📋 rep$rep_num ($ip) recent logs:"
    
    if timeout 5 ssh -i ~/.ssh/id_rsa andrc1@$ip "echo connected" 2>/dev/null | grep -q "connected"; then
        echo "  Video stream log (last 3 lines):"
        ssh -i ~/.ssh/id_rsa andrc1@$ip "sudo journalctl -u video_stream.service -n 3 --no-pager" 2>/dev/null | sed 's/^/    /'
        
        echo "  Still capture log (last 3 lines):"
        ssh -i ~/.ssh/id_rsa andrc1@$ip "sudo journalctl -u still_capture.service -n 3 --no-pager" 2>/dev/null | sed 's/^/    /'
    else
        echo "  ❌ Cannot reach $ip for log analysis"
    fi
    echo ""
done

echo "DIAGNOSTIC SUMMARY"
echo "=================="
echo "🎯 KEY FINDINGS:"

echo ""
echo "💡 LIKELY ISSUES:"
echo "1. GUI sends SET_ALL_SETTINGS to port 5001 (still_capture.py)"
echo "2. video_stream.py listens on port 5004 and may not receive settings"
echo "3. Settings may apply to stills but not to live video previews"
echo "4. Stream restart behavior needs verification"

echo ""
echo "🔧 RECOMMENDED ACTIONS:"
echo "1. Verify video_stream.py receives settings on port 5004"
echo "2. Ensure still_capture.py forwards settings to video_stream.py"
echo "3. Add stream restart confirmation"
echo "4. Test preview vs still image consistency"

echo ""
echo "📊 Run this diagnostic before and after applying fixes to compare results."
