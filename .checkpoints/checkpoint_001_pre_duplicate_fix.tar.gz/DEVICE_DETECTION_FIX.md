# DEVICE DETECTION ISSUE FIXED

## Problem
- Still capture + transforms OK on rep8 local slave
- On rep1 (192.168.0.201), journalctl shows rep8 (127.0.0.1) logs instead of rep1 logs  
- Reps1-7 fail to capture stills due to incorrect device identification

## Root Cause
The `get_device_name_from_ip()` function in `slave/still_capture.py` was:
1. Trying to connect to master (192.168.0.200) to determine IP
2. When master connection failed, falling back to `socket.gethostbyname(hostname)` 
3. This returned 127.0.0.1 which mapped to "rep8" instead of correct device
4. Wrong device detection caused wrong port binding and settings loading

## Solution Implemented

### 1. Enhanced Device Detection (`slave/still_capture.py`)
- **Method 1**: Network interface detection using `netifaces` library (most reliable)
- **Method 2**: Hostname parsing as fallback (extracts rep number directly) 
- **Method 3**: Master connection (original method, now fallback)
- **Method 4**: Hostname resolution (last resort)

### 2. Robust IP Detection Logic
```python
# Priority order for IP detection:
# 1. Network interfaces (eth0, wlan0, etc.) looking for 192.168.0.x
# 2. Parse hostname (rep1 -> 192.168.0.201)  
# 3. Connect to master (original method)
# 4. Standard hostname resolution
```

### 3. Updated Deployment Script (`sync_to_slaves.sh`)
- Installs `netifaces` dependency on all slaves
- Enhanced verification of device detection
- Checks for correct device identification in logs
- Validates port binding (6000 for rep1-7, 6010 for rep8)

### 4. New Verification Tool (`verify_device_detection.sh`)
- Checks all devices for correct identification
- Validates service status and port binding
- Provides troubleshooting commands
- Reports summary of working vs broken devices

## Files Modified
1. `slave/still_capture.py` - Enhanced device detection function
2. `slave/video_stream.py` - Enhanced device detection function (same fix)
3. `sync_to_slaves.sh` - Updated deployment with dependency installation
4. `verify_device_detection.sh` - New verification tool for both services (created)

## Verification Steps
1. Deploy fixes: `./sync_to_slaves.sh`
2. Verify fixes: `./verify_device_detection.sh`  
3. Check specific device: `ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'`
4. Should see: `DEVICE DETECTION: 192.168.0.201 -> rep1` (NOT rep8)

## Expected Behavior After Fix
- rep1 logs show "DEVICE DETECTION: 192.168.0.201 -> rep1"
- rep2 logs show "DEVICE DETECTION: 192.168.0.202 -> rep2"  
- etc.
- All reps1-7 bind to port 6000
- rep8 (local) binds to port 6010
- Still capture works on all devices with correct settings

## Fallback Strategy
If `netifaces` installation fails, the system falls back to hostname parsing which should still work correctly for devices with proper hostnames (rep1, rep2, etc.).
