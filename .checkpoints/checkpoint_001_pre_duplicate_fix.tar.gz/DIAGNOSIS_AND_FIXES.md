# MULTI-CAMERA SYSTEM DIAGNOSIS & FIXES

## **Root Cause Analysis**

### **Issue 1: Settings Don't Apply to Live Previews**
**Root Cause**: 
- GUI sends `SET_ALL_SETTINGS` commands to **port 5001** (still_capture.py)
- video_stream.py listens on **port 5004** and never receives settings
- Settings apply to still captures but NOT to live video previews

**Command Flow Problem**:
```
GUI → Port 5001 → still_capture.py ✅ (gets settings)
GUI ↛ Port 5004 → video_stream.py ❌ (never gets settings)
```

### **Issue 2: Streams Don't Restart After Settings**
**Root Cause**: 
- still_capture.py calls `restart_video_stream_with_new_settings()` 
- But video_stream.py runs as separate process and doesn't get the signal
- No inter-process communication between still_capture.py and video_stream.py

### **Issue 3: No Factory Reset Feature**
**Root Cause**: Missing GUI checkbox and backend handlers

---

## **Fixes Implemented**

### **Fix 1: Settings Forwarding**
**Solution**: still_capture.py now forwards `SET_ALL_SETTINGS` commands to video_stream.py

```python
# In still_capture.py handle_settings_package():
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as forward_sock:
    forward_sock.sendto(command.encode(), ("127.0.0.1", video_control_port))
```

### **Fix 2: Enhanced Logging**
**Solution**: Added detailed logging to trace command delivery and settings application

### **Fix 3: Factory Reset Feature**
**Solution**: 
- Added checkbox in GUI settings dialog
- Added `RESET_TO_FACTORY_DEFAULTS` command handlers
- Clears settings files and resets to original defaults

---

## **Updated Files**

### **Backend Fixes**:
- ✅ `slave/still_capture.py` - Added settings forwarding to video_stream.py
- ✅ `slave/video_stream.py` - Added factory reset handler  
- ✅ `local_camera_slave.py` - Added factory reset handler for rep8

### **GUI Enhancement**:
- ✅ `master/camera_gui/menu/settings_menu.py` - Added factory reset checkbox with confirmation

### **Diagnostic Tool**:
- ✅ `master_diagnostic.sh` - Comprehensive system diagnostic script

---

## **Deployment & Testing**

### **Deploy Updated Files**:
```bash
# From control1, deploy to all remote replicas:
for i in {1..7}; do 
    scp -i ~/.ssh/id_rsa -r /home/andrc1/camera_system_integrated_final andrc1@192.168.0.20$i:/home/andrc1/ && 
    ssh -i ~/.ssh/id_rsa andrc1@192.168.0.20$i "cd /home/andrc1/camera_system_integrated_final && sudo systemctl restart video_stream.service still_capture.service"
done

# Restart local services on control1:
sudo systemctl restart local_camera_slave.service
```

### **Test Protocol**:

1. **Run Diagnostic**:
   ```bash
   cd /home/andrc1/camera_system_integrated_final
   ./master_diagnostic.sh
   ```

2. **Test Settings Application**:
   - Start GUI: `cd master/camera_gui && python3 main.py`
   - Click "Start All Video Streams"
   - Settings → Camera Controls → rep1 Settings
   - Change: ISO=800, Flip Horizontal=True, Grayscale=True
   - Click "Apply Settings"
   - **Expected**: Changes visible immediately in rep1 preview

3. **Test Factory Reset**:
   - Settings → Camera Controls → rep2 Settings  
   - Check "⚠️ Reset this camera to factory defaults"
   - Click "Apply Settings" → Confirm reset
   - **Expected**: rep2 preview returns to default appearance

4. **Verify Settings Persistence**:
   - Apply settings to rep3, restart services
   - **Expected**: Settings survive restart

---

## **Expected Behavior After Fixes**

✅ **Settings Apply Live**: Changes to ISO, brightness, flip, rotate, crop, grayscale immediately visible in preview streams

✅ **Streams Restart**: Video streams automatically restart after settings changes to apply new transforms

✅ **Factory Reset**: Checkbox in settings dialog resets selected camera to defaults

✅ **Command Flow Works**: GUI → still_capture.py (port 5001) → video_stream.py (port 5004)

✅ **Logging Enhanced**: Detailed logs show command delivery and settings application

---

## **Diagnostic Commands**

### **Manual Testing**:
```bash
# Test command delivery to control port (still_capture.py):
echo 'SET_ALL_SETTINGS_{"iso":800,"flip_horizontal":true}' | nc -u -w 2 192.168.0.201 5001

# Test command delivery to video control port (video_stream.py):  
echo 'SET_ALL_SETTINGS_{"iso":800,"flip_horizontal":true}' | nc -u -w 2 192.168.0.201 5004

# Test factory reset:
echo 'RESET_TO_FACTORY_DEFAULTS' | nc -u -w 2 192.168.0.201 5001
```

### **Log Monitoring**:
```bash
# Watch still_capture logs:
ssh -i ~/.ssh/id_rsa andrc1@192.168.0.201 "sudo journalctl -u still_capture.service -f"

# Watch video_stream logs:  
ssh -i ~/.ssh/id_rsa andrc1@192.168.0.201 "sudo journalctl -u video_stream.service -f"
```

---

## **Architecture Summary**

**Fixed Command Flow**:
```
GUI Settings Dialog
    ↓ (Apply Settings clicked)
SET_ALL_SETTINGS_<json> → Port 5001 → still_capture.py
    ↓ (forwards command)  
SET_ALL_SETTINGS_<json> → Port 5004 → video_stream.py
    ↓ (both processes apply settings)
Preview & Still Images Match ✅
```

The system now ensures that both video previews and still captures use identical settings and transforms, with proper inter-process communication between the still_capture.py and video_stream.py services.
