#!/usr/bin/env python3
"""
Manual Device Detection Test Script
Run this on any rep (1-7) to test the offline device detection methods
Usage: python3 test_device_detection.py
"""

import socket
import subprocess
import re
import os

def test_method_1_ip_command():
    """Test Method 1: Direct IP command"""
    print("🔍 Method 1: IP Command Detection")
    try:
        result = subprocess.run(['ip', 'addr', 'show'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            lines = result.stdout.split('\n')
            found_ips = []
            for line in lines:
                if 'inet 192.168.0.' in line and '192.168.0.200' not in line:
                    parts = line.strip().split()
                    for part in parts:
                        if part.startswith('192.168.0.') and '/' in part:
                            ip = part.split('/')[0]
                            if ip != '192.168.0.200':
                                found_ips.append(ip)
            
            if found_ips:
                print(f"✅ Found IPs: {found_ips}")
                return found_ips[0]
            else:
                print("❌ No valid IPs found")
                return None
        else:
            print(f"❌ Command failed with code {result.returncode}")
            return None
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def test_method_2_hostname_parsing():
    """Test Method 2: Hostname parsing"""
    print("\n🔍 Method 2: Hostname Parsing")
    try:
        hostname = socket.gethostname()
        print(f"📝 Current hostname: {hostname}")
        
        hostname_lower = hostname.lower()
        local_ip = None
        
        if "rep" in hostname_lower:
            match = re.search(r'rep(\d+)', hostname_lower)
            if match:
                rep_num = int(match.group(1))
                if 1 <= rep_num <= 7:
                    local_ip = f"192.168.0.20{rep_num}"
                    print(f"✅ Extracted rep{rep_num} -> {local_ip}")
                elif rep_num == 8:
                    local_ip = "192.168.0.200"
                    print(f"✅ Extracted rep8 -> {local_ip}")
                else:
                    print(f"❌ Invalid rep number: {rep_num}")
            else:
                print("❌ No rep pattern found")
        
        if not local_ip:
            match = re.search(r'(\d+)$', hostname_lower)
            if match:
                num = int(match.group(1))
                if 1 <= num <= 7:
                    local_ip = f"192.168.0.20{num}"
                    print(f"✅ Number suffix {num} -> {local_ip}")
                else:
                    print(f"❌ Invalid number suffix: {num}")
            else:
                print("❌ No number suffix found")
        
        return local_ip
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def test_method_3_etc_hostname():
    """Test Method 3: /etc/hostname file"""
    print("\n🔍 Method 3: /etc/hostname File")
    try:
        with open('/etc/hostname', 'r') as f:
            system_hostname = f.read().strip().lower()
            print(f"📝 System hostname: {system_hostname}")
            
            if "rep" in system_hostname:
                match = re.search(r'rep(\d+)', system_hostname)
                if match:
                    rep_num = int(match.group(1))
                    if 1 <= rep_num <= 7:
                        local_ip = f"192.168.0.20{rep_num}"
                        print(f"✅ Extracted rep{rep_num} -> {local_ip}")
                        return local_ip
                    else:
                        print(f"❌ Invalid rep number: {rep_num}")
                else:
                    print("❌ No rep pattern found")
            else:
                print("❌ No 'rep' in system hostname")
                return None
                
    except Exception as e:
        print(f"❌ Error reading /etc/hostname: {e}")
        return None

def test_method_4_socket_binding():
    """Test Method 4: Socket binding test"""
    print("\n🔍 Method 4: Socket Binding Test")
    try:
        for test_rep in range(1, 8):
            test_ip = f"192.168.0.20{test_rep}"
            try:
                test_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                test_sock.bind((test_ip, 0))
                port = test_sock.getsockname()[1]
                test_sock.close()
                print(f"✅ Successfully bound to {test_ip}:{port}")
                return test_ip
            except OSError:
                print(f"❌ Cannot bind to {test_ip}")
                continue
        
        print("❌ Could not bind to any slave IP")
        return None
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def test_method_5_route_table():
    """Test Method 5: Route table method"""
    print("\n🔍 Method 5: Route Table Method")
    try:
        result = subprocess.run(['ip', 'route'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            lines = result.stdout.split('\n')
            for line in lines:
                if 'src 192.168.0.' in line:
                    print(f"📝 Route line: {line}")
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if part == 'src' and i + 1 < len(parts):
                            candidate_ip = parts[i + 1]
                            if candidate_ip.startswith('192.168.0.') and candidate_ip != '192.168.0.200':
                                print(f"✅ Found source IP: {candidate_ip}")
                                return candidate_ip
            
            print("❌ No valid source IP found in routes")
            return None
        else:
            print(f"❌ Route command failed with code {result.returncode}")
            return None
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def map_ip_to_device(ip):
    """Map IP to device name"""
    mapping = {
        "192.168.0.201": "rep1",
        "192.168.0.202": "rep2", 
        "192.168.0.203": "rep3",
        "192.168.0.204": "rep4",
        "192.168.0.205": "rep5",
        "192.168.0.206": "rep6",
        "192.168.0.207": "rep7",
        "192.168.0.200": "rep8",
        "127.0.0.1": "rep8",
        "localhost": "rep8"
    }
    return mapping.get(ip, "unknown")

def main():
    print("🧪 OFFLINE DEVICE DETECTION TEST")
    print("===============================")
    print(f"Running on hostname: {socket.gethostname()}")
    print()
    
    # Test all methods
    results = {}
    
    results['method1'] = test_method_1_ip_command()
    results['method2'] = test_method_2_hostname_parsing()
    results['method3'] = test_method_3_etc_hostname()
    results['method4'] = test_method_4_socket_binding()
    results['method5'] = test_method_5_route_table()
    
    print("\n" + "="*50)
    print("📊 RESULTS SUMMARY")
    print("="*50)
    
    successful_methods = []
    for method, ip in results.items():
        if ip:
            device = map_ip_to_device(ip)
            print(f"✅ {method}: {ip} -> {device}")
            successful_methods.append((method, ip, device))
        else:
            print(f"❌ {method}: Failed")
    
    print(f"\n📈 Success Rate: {len(successful_methods)}/5 methods")
    
    if successful_methods:
        # Use first successful method as final result
        final_method, final_ip, final_device = successful_methods[0]
        print(f"\n🎯 FINAL DETECTION: {final_ip} -> {final_device}")
        print(f"   Using: {final_method}")
        
        # Check if all successful methods agree
        all_same = all(result[1] == final_ip for result in successful_methods)
        if all_same:
            print(f"✅ All successful methods agree on {final_device}")
        else:
            print("⚠️  Methods disagree - potential configuration issue")
            for method, ip, device in successful_methods:
                print(f"   {method}: {device}")
    else:
        print("\n❌ ALL METHODS FAILED")
        print("🔧 Troubleshooting suggestions:")
        print("- Check network configuration: ip addr show")
        print("- Check hostname: hostname")
        print("- Check /etc/hostname file")
        print("- Ensure device is properly configured")

if __name__ == "__main__":
    main()
