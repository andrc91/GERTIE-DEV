#!/bin/bash

# STILL CAPTURE DIAGNOSTIC SCRIPT
# Run this on control1 to diagnose still capture issues on rep1-7

echo "🔍 DIAGNOSING STILL CAPTURE ISSUES"
echo "=================================="

SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=5"

# Function to check a single rep
check_rep() {
    local rep_num=$1
    local ip="192.168.0.20$rep_num"
    
    echo ""
    echo "🔍 CHECKING REP$rep_num ($ip)"
    echo "─────────────────────────────────"
    
    # Test connectivity
    if ! ping -c 1 -W 2 $ip >/dev/null 2>&1; then
        echo "❌ rep$rep_num not reachable"
        return 1
    fi
    
    # Check service status
    echo "📋 Service Status:"
    if ssh $SSH_OPTS "andrc1@$ip" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
        echo "  ✅ still_capture.service is active"
    else
        echo "  ❌ still_capture.service is NOT active"
        ssh $SSH_OPTS "andrc1@$ip" "systemctl status still_capture.service --no-pager -l" 2>/dev/null
    fi
    
    # Check recent logs for device identification
    echo ""
    echo "📋 Device Identification in Logs:"
    ssh $SSH_OPTS "andrc1@$ip" "journalctl -u still_capture.service --since='5 minutes ago' | grep -E 'DEVICE DETECTION|STARTING.*still service|Device:'" 2>/dev/null | tail -5
    
    # Check port binding
    echo ""
    echo "📋 Port 6000 Status:"
    if ssh $SSH_OPTS "andrc1@$ip" "netstat -tulpn 2>/dev/null | grep -q ':6000'" 2>/dev/null; then
        echo "  ✅ Port 6000 is bound"
        ssh $SSH_OPTS "andrc1@$ip" "netstat -tulpn 2>/dev/null | grep ':6000'" 2>/dev/null
    else
        echo "  ❌ Port 6000 is NOT bound"
    fi
    
    # Check if script is the updated version
    echo ""
    echo "📋 Script Version:"
    if ssh $SSH_OPTS "andrc1@$ip" "head -5 /home/andrc1/camera_system_integrated_final/slave/still_capture.py | grep -q 'enhanced device detection'" 2>/dev/null; then
        echo "  ✅ Updated script deployed"
    else
        echo "  ❌ Old script version"
    fi
    
    # Test manual device detection
    echo ""
    echo "📋 Manual Device Detection Test:"
    ssh $SSH_OPTS "andrc1@$ip" "cd /home/andrc1/camera_system_integrated_final && python3 -c \"
import socket
hostname = socket.gethostname()
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('192.168.0.200', 80))
    local_ip = s.getsockname()[0]
    s.close()
    print(f'Method 1 IP: {local_ip}')
except:
    local_ip = socket.gethostbyname(hostname)
    print(f'Method 2 IP: {local_ip}')

device_mapping = {
    '192.168.0.201': 'rep1', '192.168.0.202': 'rep2', '192.168.0.203': 'rep3',
    '192.168.0.204': 'rep4', '192.168.0.205': 'rep5', '192.168.0.206': 'rep6',
    '192.168.0.207': 'rep7', '192.168.0.200': 'rep8', '127.0.0.1': 'rep8'
}
device_name = device_mapping.get(local_ip, 'rep8')
print(f'Hostname: {hostname}')
print(f'Device: {local_ip} -> {device_name}')
\"" 2>/dev/null
}

# Check all reps
for i in {1..7}; do
    check_rep $i
done

echo ""
echo "🎯 SUMMARY AND RECOMMENDATIONS"
echo "============================="
echo ""
echo "If you see issues above:"
echo ""
echo "1. ❌ Service not active:"
echo "   sudo systemctl restart still_capture.service"
echo "   sudo systemctl enable still_capture.service"
echo ""
echo "2. ❌ Wrong device detection (rep showing as rep8):"
echo "   Check network configuration on that rep"
echo "   Verify IP address is correct"
echo ""
echo "3. ❌ Port 6000 not bound:"
echo "   Another service might be using the port"
echo "   Check: sudo netstat -tulpn | grep 6000"
echo ""
echo "4. ❌ Old script version:"
echo "   Re-run ./sync_to_slaves.sh to deploy updated code"
echo ""
echo "📋 To manually restart all services:"
echo "for i in {1..7}; do ssh andrc1@192.168.0.20\$i 'sudo systemctl restart still_capture.service'; done"
