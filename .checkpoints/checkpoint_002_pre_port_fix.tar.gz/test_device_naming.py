#!/usr/bin/env python3
"""
Device Naming Test - Verify repX (not rep_X) settings files are created
Tests the consistent device naming fix
"""

import sys
import os
import json
import socket
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')

# Add project root to path
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

def test_device_naming():
    """Test that device names are generated consistently without underscores"""
    logging.info("🔍 Testing device naming consistency...")
    
    try:
        from shared.transforms import get_device_name_from_ip, DEFAULT_SETTINGS
        
        # Get device name using new consistent function
        device_name = get_device_name_from_ip()
        logging.info(f"✅ Device name from shared function: {device_name}")
        
        # Verify it doesn't have underscore
        if "_" in device_name:
            logging.error(f"❌ Device name '{device_name}' contains underscore - THIS IS THE BUG!")
            return False
        else:
            logging.info(f"✅ Device name '{device_name}' is correct format (no underscore)")
        
        # Verify it follows repX pattern
        if device_name.startswith("rep") and len(device_name) == 4 and device_name[3].isdigit():
            logging.info(f"✅ Device name '{device_name}' follows correct repX pattern")
        else:
            logging.error(f"❌ Device name '{device_name}' doesn't follow repX pattern")
            return False
        
        # Test settings file creation with correct name
        from shared.transforms import save_device_settings, load_device_settings
        
        test_settings = DEFAULT_SETTINGS.copy()
        test_settings['brightness'] = 77  # Test value
        
        # Save settings
        if save_device_settings(device_name, test_settings):
            logging.info(f"✅ Settings saved for device: {device_name}")
            
            # Check that file was created with correct name
            expected_file = f"/home/andrc1/{device_name}_settings.json"
            
            # On macOS, use current directory
            import platform
            if platform.system() == "Darwin":
                expected_file = f"{device_name}_settings.json"
            
            if os.path.exists(expected_file):
                logging.info(f"✅ Settings file created: {expected_file}")
                
                # Verify contents
                with open(expected_file, 'r') as f:
                    saved_settings = json.load(f)
                
                if saved_settings.get('brightness') == 77:
                    logging.info(f"✅ Settings content verified: brightness = {saved_settings['brightness']}")
                else:
                    logging.error(f"❌ Settings content wrong: brightness = {saved_settings.get('brightness')}")
                    return False
                    
                # Check for common default values
                expected_defaults = {
                    'brightness': 77,  # Our test value
                    'contrast': 50,
                    'flip_horizontal': False,
                    'flip_vertical': False,
                    'grayscale': False,
                    'rotation': 0
                }
                
                all_correct = True
                for key, expected_value in expected_defaults.items():
                    actual_value = saved_settings.get(key)
                    if actual_value == expected_value:
                        logging.info(f"✅ {key}: {actual_value} (correct)")
                    else:
                        logging.error(f"❌ {key}: {actual_value} (expected {expected_value})")
                        all_correct = False
                
                if all_correct:
                    logging.info("✅ All default settings values are correct")
                else:
                    logging.error("❌ Some default settings values are incorrect")
                    return False
                
            else:
                logging.error(f"❌ Settings file not created: {expected_file}")
                return False
                
        else:
            logging.error(f"❌ Failed to save settings for {device_name}")
            return False
        
        logging.info("🎉 Device naming test PASSED!")
        return True
        
    except Exception as e:
        logging.error(f"❌ Device naming test failed: {e}")
        import traceback
        logging.error(f"Stack trace: {traceback.format_exc()}")
        return False

def test_old_vs_new_naming():
    """Compare old buggy naming vs new fixed naming"""
    logging.info("🔍 Testing old vs new device naming...")
    
    try:
        import socket
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        last_octet = local_ip.split('.')[-1]
        
        # Old buggy way (with underscore)
        old_device_name = f"rep_{last_octet}"
        logging.info(f"OLD (buggy) device name: {old_device_name}")
        
        # New correct way (no underscore)
        new_device_name = f"rep{last_octet}"
        logging.info(f"NEW (correct) device name: {new_device_name}")
        
        # Using shared function
        from shared.transforms import get_device_name_from_ip
        shared_device_name = get_device_name_from_ip()
        logging.info(f"SHARED function device name: {shared_device_name}")
        
        # Verify shared function returns correct format
        if shared_device_name == new_device_name:
            logging.info("✅ Shared function returns correct device name format")
            return True
        else:
            logging.error(f"❌ Shared function inconsistent: got {shared_device_name}, expected {new_device_name}")
            return False
            
    except Exception as e:
        logging.error(f"❌ Naming comparison failed: {e}")
        return False

def main():
    """Main test function"""
    logging.info("🚀 Testing Device Naming Fix")
    
    # Show system info
    try:
        import socket
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        logging.info(f"Hostname: {hostname}")
        logging.info(f"IP: {local_ip}")
        logging.info(f"Last octet: {local_ip.split('.')[-1]}")
    except:
        logging.info("Could not get network info")
    
    # Test 1: Device naming consistency
    if not test_device_naming():
        logging.error("❌ Device naming test failed")
        return False
    
    # Test 2: Old vs new comparison
    if not test_old_vs_new_naming():
        logging.error("❌ Old vs new naming test failed")
        return False
    
    logging.info("🎉 ALL DEVICE NAMING TESTS PASSED!")
    logging.info("✅ Device names will be: rep1, rep2, rep3, rep4, rep5, rep6, rep7, rep8")
    logging.info("✅ Settings files will be: rep1_settings.json, rep2_settings.json, etc.")
    logging.info("✅ No more rep_X_settings.json files!")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
