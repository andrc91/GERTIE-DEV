#!/bin/bash
# Verify device detection fixes across all reps
# Run on control1 to check all slaves

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_check() { echo -e "${BLUE}🔍 $1${NC}"; }

echo -e "${BLUE}🔍 VERIFYING DEVICE DETECTION FIXES${NC}"
echo -e "${BLUE}=================================${NC}"
echo ""

# Check local camera (rep8) first
log_check "Checking local camera (rep8)..."
if systemctl is-active local_camera_slave.service >/dev/null 2>&1; then
    log_success "rep8: Local camera service is active"
else
    log_error "rep8: Local camera service is not active"
fi

echo ""

# Check all slave cameras (rep1-7)
for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_check "Checking rep$i ($SLAVE_IP)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        continue
    fi
    
    # Check service status
    still_active=false
    video_active=false
    
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
        still_active=true
        log_success "rep$i: Still capture service is active"
    else
        log_error "rep$i: Still capture service is not active"
    fi
    
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active video_stream.service" 2>/dev/null | grep -q "active"; then
        video_active=true
        log_success "rep$i: Video stream service is active"
    else
        log_error "rep$i: Video stream service is not active"
    fi
    
    # Check device detection for both services if active
    if $still_active; then
        # Check device detection in recent logs
        device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='5 minutes ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
        if [[ -n "$device_detection" ]]; then
            # Extract the detected device from the log line
            detected_device=$(echo "$device_detection" | grep -o "rep[0-8]" | tail -1)
            if [[ "$detected_device" == "rep$i" ]]; then
                log_success "rep$i: ✅ STILL CAPTURE: CORRECT device detection ($detected_device)"
            else
                log_error "rep$i: ❌ STILL CAPTURE: WRONG device detection ($detected_device instead of rep$i)"
                echo "    Full log: $device_detection"
            fi
        else
            log_error "rep$i: No recent still capture device detection logs found"
        fi
        
        # Check port binding
        port_binding=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='5 minutes ago' | grep 'BOUND to port' | tail -1" 2>/dev/null)
        if [[ -n "$port_binding" ]]; then
            if echo "$port_binding" | grep -q "port 6000"; then
                log_success "rep$i: ✅ STILL CAPTURE: CORRECT port binding (6000)"
            else
                log_error "rep$i: ❌ STILL CAPTURE: WRONG port binding"
                echo "    Port info: $port_binding"
            fi
        else
            log_error "rep$i: No still capture port binding info found"
        fi
    fi
    
    if $video_active; then
        # Check video stream device detection
        video_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u video_stream.service --since='5 minutes ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
        if [[ -n "$video_detection" ]]; then
            detected_device=$(echo "$video_detection" | grep -o "rep[0-8]" | tail -1)
            if [[ "$detected_device" == "rep$i" ]]; then
                log_success "rep$i: ✅ VIDEO STREAM: CORRECT device detection ($detected_device)"
            else
                log_error "rep$i: ❌ VIDEO STREAM: WRONG device detection ($detected_device instead of rep$i)"
                echo "    Full log: $video_detection"
            fi
        else
            log_error "rep$i: No recent video stream device detection logs found"
        fi
    fi
        
        # Check hostname
        hostname=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "hostname" 2>/dev/null)
        if [[ -n "$hostname" ]]; then
            echo "    Hostname: $hostname"
        fi
        
        # Check IP detection methods
        ip_addr=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "ip addr show | grep '192.168.0.' | head -1" 2>/dev/null)
        if [[ -n "$ip_addr" ]]; then
            echo "    IP info: $ip_addr"
        fi
        
    else
        log_error "rep$i: Services are not active"
        
        # Show service status for debugging
        echo "    Still capture status:"
        ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl status still_capture.service --no-pager -l" 2>/dev/null | head -3 | sed 's/^/      /'
        
        echo "    Video stream status:"
        ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl status video_stream.service --no-pager -l" 2>/dev/null | head -3 | sed 's/^/      /'
    fi
    
    echo ""
done

echo -e "${BLUE}📊 SUMMARY${NC}"
echo -e "${BLUE}=========${NC}"

# Count working services
working_still_count=0
working_video_count=0
total_count=7

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    if ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        # Check still capture
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
            device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='5 minutes ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
            if [[ -n "$device_detection" ]] && echo "$device_detection" | grep -q "rep$i"; then
                working_still_count=$((working_still_count + 1))
            fi
        fi
        
        # Check video stream
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active video_stream.service" 2>/dev/null | grep -q "active"; then
            video_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u video_stream.service --since='5 minutes ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
            if [[ -n "$video_detection" ]] && echo "$video_detection" | grep -q "rep$i"; then
                working_video_count=$((working_video_count + 1))
            fi
        fi
    fi
done

echo -e "${GREEN}Still capture devices working: $working_still_count/$total_count${NC}"
echo -e "${GREEN}Video stream devices working: $working_video_count/$total_count${NC}"

if [[ $working_still_count -eq $total_count ]] && [[ $working_video_count -eq $total_count ]]; then
    log_success "🎉 ALL DEVICES WORKING CORRECTLY!"
    echo -e "${GREEN}Device detection fixes successful!${NC}"
else
    log_error "⚠️  Some devices need attention"
    echo -e "${YELLOW}Run the deployment script again: ./sync_to_slaves.sh${NC}"
fi

echo ""
echo -e "${BLUE}🔧 TROUBLESHOOTING COMMANDS:${NC}"
echo -e "${GREEN}  Check specific device: ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'${NC}"
echo -e "${GREEN}  Restart service: ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture.service'${NC}"
echo -e "${GREEN}  Check hostname: ssh andrc1@192.168.0.201 'hostname'${NC}"
echo -e "${GREEN}  Check IP: ssh andrc1@192.168.0.201 'ip addr show'${NC}"
