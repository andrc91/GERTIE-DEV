# DEPLOYMENT WORKFLOW - MacBook → USB → Control1 Pi

## Step-by-Step Process

### 1. On MacBook (After Making Changes)
```bash
# In camera_system_integrated_final directory
# Copy entire directory to USB drive
cp -R . /Volumes/USB_DRIVE/camera_system_integrated_final/
```

### 2. On Control1 Pi (After USB Transfer)
```bash
# Copy from USB to Pi
sudo rsync -av /media/usb/camera_system_integrated_final/ /home/andrc1/camera_system_integrated_final/

# Navigate to directory
cd /home/andrc1/camera_system_integrated_final

# Create default settings files for all reps
python3 create_default_settings.py

# Sync to all slave devices (rep1-rep7)
./sync_to_slaves.sh

# Run diagnostic to verify everything works
python3 master_diagnostic_comprehensive.py
```

## Files Modified by These Fixes

✅ **shared/transforms.py** - Changed settings path from `/tmp/` to `/home/andrc1/`
✅ **deploy_complete_fix.sh** - Fixed SSH options for modern SSH
✅ **slave/still_capture.py** - Simplified get_device_name() function  
✅ **master_diagnostic_comprehensive.py** - Updated settings file path
✅ **sync_to_slaves.sh** - NEW: Sync script for USB workflow
✅ **create_default_settings.py** - NEW: Creates missing settings files

## Expected Results
- Settings files at `/home/andrc1/rep1_settings.json` through `/home/andrc1/rep8_settings.json`
- SSH deployment works without key algorithm errors  
- All cameras show `settings_applied=true`, `stream_restarted=true`, `transforms_working=true`
- Diagnostic reports 100% success rate

## Quick Verification
```bash
# Check settings files exist
ls -la /home/andrc1/rep*_settings.json

# Verify services running
sudo systemctl status still_capture.service video_stream.service

# Test settings change on rep1
echo 'SET_ALL_SETTINGS_{"brightness":80}' | nc -u 192.168.0.201 5001
cat /home/andrc1/rep1_settings.json | grep brightness  # Should show 80
```
