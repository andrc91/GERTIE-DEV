#!/usr/bin/env python3
"""
Debug script to test transform functions directly
"""

import sys
import os
import numpy as np

# Add project root to path
sys.path.insert(0, '/Users/andrew1/Desktop/camera_system_integrated_final')

def create_test_image(width=100, height=100):
    """Create a test image with known patterns"""
    image = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Top half red, bottom half blue
    image[:height//2, :, 0] = 255  # Red channel
    image[height//2:, :, 2] = 255  # Blue channel
    
    # Add some gradient for flip testing
    for i in range(width):
        image[:, i, 1] = int(255 * i / width)  # Green gradient
    
    return image

def test_manual_transforms():
    """Test transforms manually with debug output"""
    from shared.transforms import apply_unified_transforms, load_device_settings
    
    print("Testing transform functions...")
    
    # Create test image
    image = create_test_image(100, 100)
    print(f"Original image shape: {image.shape}")
    
    # Test default settings (should pass through unchanged)
    print("\n1. Testing default settings:")
    result = apply_unified_transforms(image, "rep8")
    print(f"Result shape: {result.shape}")
    print(f"Images equal: {np.array_equal(image, result)}")
    
    # Test manual settings injection
    print("\n2. Testing with manual settings override:")
    
    # Monkey patch the load function
    import shared.transforms as transforms_module
    original_load = transforms_module.load_device_settings
    
    test_settings = {
        'brightness': 0,
        'contrast': 50,
        'iso': 100,
        'saturation': 50,
        'white_balance': 'auto',
        'jpeg_quality': 95,
        'fps': 30,
        'resolution': '4608x2592',
        'crop_enabled': True,  # Enable crop
        'crop_x': 10,
        'crop_y': 10,
        'crop_width': 50,
        'crop_height': 50,
        'flip_horizontal': False,
        'flip_vertical': False,
        'grayscale': False,
        'rotation': 0
    }
    
    def mock_load_settings(device_name):
        print(f"Mock loading settings for {device_name}")
        print(f"Crop enabled: {test_settings['crop_enabled']}")
        print(f"Crop params: x={test_settings['crop_x']}, y={test_settings['crop_y']}, w={test_settings['crop_width']}, h={test_settings['crop_height']}")
        return test_settings
    
    # Override the function
    transforms_module.load_device_settings = mock_load_settings
    
    try:
        result = apply_unified_transforms(image, "test_device")
        print(f"Result shape after crop: {result.shape}")
        print(f"Expected shape: (50, 50, 3)")
        
        if result.shape == (50, 50, 3):
            print("✅ Crop transform working correctly!")
        else:
            print("❌ Crop transform failed!")
            
    finally:
        # Restore original function
        transforms_module.load_device_settings = original_load

if __name__ == "__main__":
    test_manual_transforms()
