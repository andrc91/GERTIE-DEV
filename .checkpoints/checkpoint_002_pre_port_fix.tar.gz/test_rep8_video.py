#!/usr/bin/env python3
"""
Quick Rep8 Video Stream Test
Run this on control1 to test rep8 video streaming independently
"""

import socket
import time
import logging
import cv2
from picamera2 import Picamera2

logging.basicConfig(level=logging.INFO)

def test_rep8_video():
    """Test rep8 video streaming to master"""
    print("🧪 Testing rep8 video stream...")
    
    # Video stream parameters
    MASTER_IP = "127.0.0.1"
    VIDEO_PORT = 5002
    
    try:
        # Initialize camera
        print("📷 Initializing camera...")
        picam2 = Picamera2()
        config = picam2.create_video_configuration(
            main={"size": (640, 480), "format": "RGB888"},
            controls={"FrameRate": 10}
        )
        picam2.configure(config)
        picam2.start()
        time.sleep(2)
        print("✅ Camera initialized")
        
        # Create UDP socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        print(f"📡 Sending to {MASTER_IP}:{VIDEO_PORT}")
        
        # Send test frames
        for i in range(10):
            print(f"📤 Sending frame {i+1}/10...")
            
            # Capture frame
            frame = picam2.capture_array()
            
            # Convert RGB to BGR for OpenCV
            frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            
            # Encode as JPEG
            success, encoded = cv2.imencode(".jpg", frame_bgr, [cv2.IMWRITE_JPEG_QUALITY, 70])
            
            if success:
                frame_data = encoded.tobytes()
                sock.sendto(frame_data, (MASTER_IP, VIDEO_PORT))
                print(f"   ✅ Sent {len(frame_data)} bytes")
            else:
                print(f"   ❌ Failed to encode frame {i+1}")
            
            time.sleep(1)  # 1 FPS for testing
        
        # Cleanup
        picam2.stop()
        picam2.close()
        sock.close()
        
        print("✅ Test completed")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("🎯 Rep8 Video Stream Test")
    print("=========================")
    print("This will test rep8 video streaming capability")
    print("Make sure GUI is running on control1 to receive frames")
    print("")
    
    input("Press Enter to start test...")
    
    success = test_rep8_video()
    
    if success:
        print("\n🎉 SUCCESS: rep8 can stream video")
        print("If GUI still doesn't show rep8 preview:")
        print("1. Check GUI video receiver is running")
        print("2. Check GUI is listening on port 5002")
        print("3. Check firewall/iptables rules")
    else:
        print("\n💥 FAILED: rep8 cannot stream video")
        print("Check camera permissions and hardware")
