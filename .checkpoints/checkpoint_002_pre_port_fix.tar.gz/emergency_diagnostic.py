#!/usr/bin/env python3
"""
Emergency Resolution Diagnostic Script
Investigates why images are STILL low resolution despite all fixes
Run this to diagnose the actual state of the system
"""

import os
import logging
import subprocess
import json
import time
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def check_deployment_status():
    """Check if fixes have actually been deployed to slaves"""
    logging.info("🔍 CHECKING DEPLOYMENT STATUS")
    logging.info("="*50)
    
    # Check when sync_to_slaves.sh was last run
    sync_script = "/Users/andrew1/Desktop/camera_system_integrated_final/sync_to_slaves.sh"
    if os.path.exists(sync_script):
        stat = os.stat(sync_script)
        mod_time = datetime.fromtimestamp(stat.st_mtime)
        logging.info(f"📅 sync_to_slaves.sh last modified: {mod_time}")
    
    # Check if fixes are in the local code
    still_capture_path = "/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py"
    if os.path.exists(still_capture_path):
        with open(still_capture_path, 'r') as f:
            content = f.read()
        
        # Check for critical fix indicators
        indicators = [
            "Always use processing path for guaranteed high resolution",
            "Using processing path for guaranteed HIGH RESOLUTION",
            "return capture_with_processing(filename)",
            "CRITICAL FIX"
        ]
        
        found = []
        for indicator in indicators:
            if indicator in content:
                found.append(indicator)
        
        logging.info(f"✅ Local code contains {len(found)}/4 fix indicators")
        if len(found) < 3:
            logging.error("❌ CRITICAL: Local code missing fixes!")
            return False
    
    logging.info("💡 RECOMMENDATION: Run deployment if not done recently")
    logging.info("   cd ~/Desktop/camera_system_integrated_final")
    logging.info("   ./sync_to_slaves.sh")
    return True

def check_actual_image_properties():
    """Check properties of actual captured images"""
    logging.info("🔍 CHECKING ACTUAL CAPTURED IMAGES")
    logging.info("="*50)
    
    # Test capture and immediate analysis
    test_commands = [
        {
            'name': 'rep1',
            'ip': '192.168.0.201',
            'port': 6000,
            'service': 'still_capture.service'
        },
        {
            'name': 'rep2', 
            'ip': '192.168.0.202',
            'port': 6000,
            'service': 'still_capture.service'
        }
    ]
    
    for camera in test_commands:
        logging.info(f"📸 Testing {camera['name']} ({camera['ip']})...")
        
        # Test if camera is reachable
        try:
            result = subprocess.run(['ping', '-c', '1', '-W', '2000', camera['ip']], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                logging.error(f"❌ {camera['name']}: Not reachable via ping")
                continue
            else:
                logging.info(f"✅ {camera['name']}: Network reachable")
        except:
            logging.error(f"❌ {camera['name']}: Ping failed")
            continue
        
        # Test still capture port
        try:
            result = subprocess.run(['nc', '-uz', camera['ip'], str(camera['port'])], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                logging.info(f"✅ {camera['name']}: Port {camera['port']} listening")
            else:
                logging.error(f"❌ {camera['name']}: Port {camera['port']} not listening")
                continue
        except:
            logging.error(f"❌ {camera['name']}: Port test failed")
            continue
        
        # Trigger capture
        logging.info(f"📸 Triggering capture on {camera['name']}...")
        try:
            capture_cmd = f"echo 'CAPTURE_STILL' | nc -u {camera['ip']} {camera['port']}"
            subprocess.run(capture_cmd, shell=True, timeout=10)
            logging.info(f"✅ {camera['name']}: Capture command sent")
            
            # Wait for capture to complete
            time.sleep(5)
            
            # Check recent log entries
            log_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{camera['ip']} 'journalctl -u {camera['service']} --since=\"2 minutes ago\" --no-pager'"
            result = subprocess.run(log_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                logs = result.stdout
                
                # Look for resolution indicators
                if "HIGH RES" in logs:
                    logging.info(f"✅ {camera['name']}: Found 'HIGH RES' in logs")
                else:
                    logging.error(f"❌ {camera['name']}: No 'HIGH RES' found in logs")
                
                if "processing path" in logs:
                    logging.info(f"✅ {camera['name']}: Using processing path")
                else:
                    logging.error(f"❌ {camera['name']}: No 'processing path' found in logs")
                
                if "4608" in logs and "2592" in logs:
                    logging.info(f"✅ {camera['name']}: High resolution dimensions in logs")
                else:
                    logging.error(f"❌ {camera['name']}: No high resolution dimensions in logs")
                
                # Look for file size indicators
                if "MB" in logs:
                    import re
                    mb_matches = re.findall(r'(\d+\.?\d*)\s*MB', logs)
                    if mb_matches:
                        file_size = float(mb_matches[-1])
                        if file_size > 1.0:
                            logging.info(f"✅ {camera['name']}: Large file size {file_size}MB")
                        else:
                            logging.error(f"❌ {camera['name']}: Small file size {file_size}MB")
                
                # Show recent relevant log lines
                log_lines = logs.split('\n')
                relevant_lines = [line for line in log_lines if any(keyword in line for keyword in ['SLAVE', 'HIGH RES', 'processing', 'Captured', 'saved'])]
                
                if relevant_lines:
                    logging.info(f"📋 {camera['name']}: Recent relevant logs:")
                    for line in relevant_lines[-5:]:  # Last 5 relevant lines
                        logging.info(f"   {line.strip()}")
                else:
                    logging.warning(f"⚠️  {camera['name']}: No relevant log lines found")
                    # Show last few lines anyway
                    logging.info(f"📋 {camera['name']}: Last log lines:")
                    for line in log_lines[-3:]:
                        if line.strip():
                            logging.info(f"   {line.strip()}")
            
            else:
                logging.error(f"❌ {camera['name']}: Failed to retrieve logs")
                
        except Exception as e:
            logging.error(f"❌ {camera['name']}: Capture test failed: {e}")

def check_settings_files():
    """Check current state of settings files"""
    logging.info("🔍 CHECKING SETTINGS FILES STATE")
    logging.info("="*50)
    
    settings_files = [
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep1_settings.json",
        "/Users/andrew1/Desktop/camera_system_integrated_final/rep2_settings.json"
    ]
    
    for settings_file in settings_files:
        if os.path.exists(settings_file):
            try:
                with open(settings_file, 'r') as f:
                    settings = json.load(f)
                
                device = os.path.basename(settings_file).replace('_settings.json', '')
                resolution = settings.get('resolution', 'unknown')
                quality = settings.get('jpeg_quality', 'unknown')
                brightness = settings.get('brightness', 'unknown')
                
                logging.info(f"📄 {device}:")
                logging.info(f"   Resolution: {resolution}")
                logging.info(f"   JPEG Quality: {quality}%")
                logging.info(f"   Brightness: {brightness}")
                
                if resolution == '4608x2592':
                    logging.info(f"   ✅ High resolution configured")
                else:
                    logging.error(f"   ❌ Low resolution: {resolution}")
                
                if quality >= 90:
                    logging.info(f"   ✅ High quality configured")
                else:
                    logging.warning(f"   ⚠️  Quality could be higher: {quality}%")
                    
            except Exception as e:
                logging.error(f"❌ Failed to read {settings_file}: {e}")
        else:
            logging.error(f"❌ Settings file not found: {settings_file}")

def check_service_status():
    """Check service status on slaves"""
    logging.info("🔍 CHECKING SERVICE STATUS")
    logging.info("="*50)
    
    test_ips = ['192.168.0.201', '192.168.0.202']
    
    for ip in test_ips:
        device = f"rep{ip[-1]}"
        logging.info(f"🔧 Checking {device} ({ip})...")
        
        try:
            # Check service status
            status_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{ip} 'systemctl is-active still_capture.service'"
            result = subprocess.run(status_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0 and 'active' in result.stdout:
                logging.info(f"✅ {device}: Service is active")
            else:
                logging.error(f"❌ {device}: Service not active - {result.stdout.strip()}")
            
            # Check when service was last restarted
            restart_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{ip} 'systemctl show still_capture.service -p ActiveEnterTimestamp'"
            result = subprocess.run(restart_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                logging.info(f"📅 {device}: {result.stdout.strip()}")
            
        except Exception as e:
            logging.error(f"❌ {device}: Service check failed: {e}")

def generate_emergency_actions():
    """Generate emergency diagnostic and fix actions"""
    logging.info("")
    logging.info("🚨 EMERGENCY DIAGNOSTIC COMPLETE")
    logging.info("="*50)
    logging.info("")
    logging.info("🔧 IMMEDIATE ACTIONS:")
    logging.info("")
    logging.info("1. FORCE DEPLOYMENT (if not done recently):")
    logging.info("   cd ~/Desktop/camera_system_integrated_final")
    logging.info("   ./sync_to_slaves.sh")
    logging.info("")
    logging.info("2. MANUAL SERVICE RESTART:")
    logging.info("   ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture.service'")
    logging.info("   ssh andrc1@192.168.0.202 'sudo systemctl restart still_capture.service'")
    logging.info("")
    logging.info("3. CHECK ACTUAL FILE ON SLAVE:")
    logging.info("   ssh andrc1@192.168.0.201 'ls -la /home/andrc1/camera_system_integrated_final/captured_images/ | tail -5'")
    logging.info("   ssh andrc1@192.168.0.201 'file /home/andrc1/camera_system_integrated_final/captured_images/rep1_*.jpg | tail -1'")
    logging.info("")
    logging.info("4. CHECK CODE ON SLAVE:")
    logging.info("   ssh andrc1@192.168.0.201 'grep -n \"processing path\" /home/andrc1/camera_system_integrated_final/slave/still_capture.py'")
    logging.info("")
    logging.info("5. MANUAL CAPTURE TEST:")
    logging.info("   ssh andrc1@192.168.0.201")
    logging.info("   cd /home/andrc1/camera_system_integrated_final/slave")
    logging.info("   python3 -c \"import still_capture; print(still_capture.capture_image())\"")
    logging.info("")
    logging.info("6. CHECK PICAMERA2 DIRECT:")
    logging.info("   ssh andrc1@192.168.0.201")
    logging.info("   python3 -c \"from picamera2 import Picamera2; p=Picamera2(); print(p.camera_properties)\"")

def main():
    """Main emergency diagnostic"""
    logging.info("🚨 EMERGENCY RESOLUTION DIAGNOSTIC")
    logging.info("Images STILL low resolution despite fixes")
    logging.info("Investigating actual system state...")
    logging.info("="*60)
    
    try:
        # Check deployment status
        check_deployment_status()
        print()
        
        # Check settings files
        check_settings_files()
        print()
        
        # Check service status
        check_service_status()
        print()
        
        # Check actual images
        check_actual_image_properties()
        
        # Generate emergency actions
        generate_emergency_actions()
        
    except Exception as e:
        logging.error(f"❌ Diagnostic failed: {e}")

if __name__ == "__main__":
    main()
