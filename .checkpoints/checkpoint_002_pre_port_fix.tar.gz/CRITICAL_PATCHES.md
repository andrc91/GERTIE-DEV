# CRITICAL FIXES PATCH - Apply These Changes

## Fix 1: rep8 Video Stream Issue
**Problem**: local_camera_slave.py might not be sending video correctly
**Quick Test**: Run `python3 test_rep8_video.py` on control1 while GUI is running

## Fix 2: Settings Not Applying Live (rep1-rep7)
**Root Cause**: Settings cache not updating properly in video_stream.py

**PATCH**: Replace the settings refresh mechanism in video_stream.py:

```python
# Replace lines ~62-84 in slave/video_stream.py with:
def get_current_camera_settings():
    """Get current camera settings - force fresh read each time for live updates"""
    try:
        # Force fresh import to get latest settings
        import importlib
        import still_capture
        importlib.reload(still_capture)
        return still_capture.camera_settings
    except Exception as e:
        logging.error(f"Error getting camera settings: {e}")
        return {
            'crop_enabled': False, 'flip_horizontal': False, 'flip_vertical': False,
            'grayscale': False, 'rotation': 0, 'brightness': 50, 'iso': 100
        }
```

## Fix 3: Directory Creation Reliability
**PATCH**: Add this to the beginning of save_and_display_still() in network_manager.py:

```python
# At start of save_and_display_still() function:
# Force create all required directories before saving
base_path = "/home/andrc1/Desktop/captured_images" if platform.system() != "Darwin" else os.path.expanduser("~/Desktop/captured_images")
date_dir = os.path.join(base_path, date_str)
device_dir = os.path.join(date_dir, device_name)

# Create with more robust error handling
for dir_path in [base_path, date_dir, device_dir]:
    try:
        os.makedirs(dir_path, exist_ok=True)
        # Verify directory was created
        if not os.path.exists(dir_path):
            raise OSError(f"Directory creation failed: {dir_path}")
    except Exception as e:
        logging.error(f"Failed to create directory {dir_path}: {e}")
        # Try alternative path
        fallback_dir = "/tmp/camera_images"
        os.makedirs(fallback_dir, exist_ok=True)
        logging.info(f"Using fallback directory: {fallback_dir}")
        break
```

## Fix 4: Settings Package Command Verification
**PATCH**: Add debug logging to still_capture.py settings handler:

```python
# In handle_settings_package() function, add at the start:
logging.info(f"[SETTINGS] Received package with {len(new_settings)} settings")
for key, value in new_settings.items():
    logging.info(f"[SETTINGS] {key}: {old_val} -> {value}")
    
# After camera_settings update, add:
logging.info(f"[SETTINGS] Updated settings: {camera_settings}")
logging.info(f"[SETTINGS] Triggering video stream restart...")
```

## DEPLOYMENT:
1. Apply these patches to the files
2. Run `./deploy_fixes.sh` on each Pi  
3. Run `./diagnostic_endtoend.sh` to verify fixes
4. Test with GUI: Start streams → Change settings → Should see immediate preview changes

## TESTING PRIORITY:
1. **rep8**: Run `python3 test_rep8_video.py` on control1
2. **Settings Live**: Change flip horizontal on rep1, should see immediate preview change
3. **Directory**: Capture still, should save to `/Desktop/captured_images/<date>/rep<N>/`
