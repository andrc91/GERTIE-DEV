#!/bin/bash
# PORT DIAGNOSIS: Check what ports are actually in use
# Run this on control1 to see what's listening on each slave

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_check() { echo -e "${BLUE}🔍 $1${NC}"; }

echo -e "${BLUE}🔍 PORT DIAGNOSIS: Checking All Devices${NC}"
echo -e "${BLUE}=====================================${NC}"
echo ""

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_check "Checking ports on rep$i ($SLAVE_IP)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        continue
    fi
    
    # Check what's listening on key ports
    echo "  Port Status:"
    
    # Port 5001 (Control/Still)
    port_5001=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "netstat -ulnp | grep :5001" 2>/dev/null)
    if [[ -n "$port_5001" ]]; then
        echo "    5001 (Control/Still): ✅ LISTENING"
        echo "      Details: $port_5001"
    else
        echo "    5001 (Control/Still): ❌ NOT LISTENING"
    fi
    
    # Port 5002 (Video)
    port_5002=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "netstat -ulnp | grep :5002" 2>/dev/null)
    if [[ -n "$port_5002" ]]; then
        echo "    5002 (Video): ✅ LISTENING"
    else
        echo "    5002 (Video): ❌ NOT LISTENING"
    fi
    
    # Port 6000 (Old Still Port)
    port_6000=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "netstat -ulnp | grep :6000" 2>/dev/null)
    if [[ -n "$port_6000" ]]; then
        echo "    6000 (Old Still): ⚠️  STILL LISTENING (should not be)"
        echo "      Details: $port_6000"
    else
        echo "    6000 (Old Still): ✅ NOT LISTENING (correct)"
    fi
    
    # Check what services are running
    echo "  Services:"
    still_service=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null)
    echo "    still_capture.service: $still_service"
    
    video_service=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active video_stream.service" 2>/dev/null)
    echo "    video_stream.service: $video_service"
    
    # Test port connectivity
    echo "  Port Tests:"
    if timeout 3 bash -c "echo 'TEST' | nc -u $SLAVE_IP 5001" 2>/dev/null; then
        echo "    5001: ✅ Accepts connections"
    else
        echo "    5001: ❌ No response"
    fi
    
    if timeout 3 bash -c "echo 'TEST' | nc -u $SLAVE_IP 6000" 2>/dev/null; then
        echo "    6000: ⚠️  Still accepts connections (should not)"
    else
        echo "    6000: ✅ No response (correct)"
    fi
    
    echo ""
done

echo "📊 SUMMARY & RECOMMENDATIONS"
echo "============================"
echo ""
echo "✅ CORRECT CONFIGURATION:"
echo "  - rep1-7: Still capture service listening on port 5001"
echo "  - rep8: Still capture service listening on port 6010"
echo "  - GUI sending CAPTURE_STILL commands to port 5001 for rep1-7"
echo ""
echo "❌ PROBLEM INDICATORS:"
echo "  - Port 5001 not listening = Service not running or wrong port"
echo "  - Port 6000 still listening = Old configuration still active"
echo "  - Services not active = Deployment issue"
echo ""
echo "🔧 IF ISSUES FOUND:"
echo "  1. Re-deploy with fixed ports: ./sync_to_slaves.sh"
echo "  2. Restart services: ./quick_fix_capture.sh"
echo "  3. Test manually: echo 'CAPTURE_STILL' | nc -u 192.168.0.201 5001"
