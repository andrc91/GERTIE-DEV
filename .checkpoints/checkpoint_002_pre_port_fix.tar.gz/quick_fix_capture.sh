#!/bin/bash
# QUICK FIX: Restart still capture services on all slaves
# Run this on control1 to fix common still capture issues

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_fix() { echo -e "${BLUE}🔧 $1${NC}"; }

echo -e "${BLUE}🔧 QUICK FIX: Restarting Still Capture Services${NC}"
echo -e "${BLUE}===============================================${NC}"
echo ""

cd /home/andrc1/camera_system_integrated_final

fixed_count=0
total_slaves=7

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_fix "Fixing rep$i ($SLAVE_IP)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        continue
    fi
    
    # Stop and restart still capture service
    log_fix "Restarting still capture service on rep$i..."
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "sudo systemctl stop still_capture.service; sleep 2; sudo systemctl start still_capture.service" 2>/dev/null; then
        log_success "rep$i: Service restarted"
        
        # Give service time to start
        sleep 3
        
        # Check if service is active
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
            log_success "rep$i: Service is active"
            
            # Check device detection
            device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='30 seconds ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
            if [[ -n "$device_detection" ]] && echo "$device_detection" | grep -q "rep$i"; then
                log_success "rep$i: ✅ Device detection correct"
                
                # Check port binding
                port_check=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='30 seconds ago' | grep 'BOUND to port' | tail -1" 2>/dev/null)
                if echo "$port_check" | grep -q "port 5001"; then
                    log_success "rep$i: ✅ Port 5001 bound correctly"
                    fixed_count=$((fixed_count + 1))
                else
                    log_error "rep$i: ❌ Port binding issue"
                fi
            else
                log_error "rep$i: ❌ Device detection still wrong"
                echo "    Detection: $device_detection"
            fi
        else
            log_error "rep$i: Service failed to start"
        fi
    else
        log_error "rep$i: Failed to restart service"
    fi
    
    echo ""
done

echo "📊 QUICK FIX RESULTS"
echo "==================="
log_success "Fixed devices: $fixed_count/$total_slaves"

if [[ $fixed_count -eq $total_slaves ]]; then
    log_success "🎉 ALL DEVICES FIXED!"
    echo -e "${GREEN}Try still capture from GUI now${NC}"
elif [[ $fixed_count -gt 0 ]]; then
    log_success "Some devices fixed"
    echo -e "${YELLOW}$((total_slaves - fixed_count)) devices still need attention${NC}"
else
    log_error "No devices were fixed"
    echo -e "${RED}Deeper troubleshooting needed${NC}"
fi

echo ""
echo "🧪 TEST STILL CAPTURE"
echo "===================="
echo "Test manually with these commands:"
for i in {1..7}; do
    echo "  rep$i: echo 'CAPTURE_STILL' | nc -u 192.168.0.20$i 5001"
done

echo ""
echo "📋 IF STILL NOT WORKING"
echo "======================="
echo "1. Re-run full deployment: ./sync_to_slaves.sh"
echo "2. Check logs: ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'"
echo "3. Run diagnosis: ./diagnose_capture_failure.sh"
