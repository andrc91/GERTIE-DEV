# 🔧 CRITICAL PORT FIX - STILL CAPTURE NOW WORKING

## ✅ **ROOT CAUSE IDENTIFIED & FIXED**

**Issue**: GUI sends still capture commands to port **5001** (control port), but services were listening on port **6000**.

**Solution**: **FIXED** - Services now listen on port **5001** for rep1-7.

---

## 🔧 **Files Fixed (In Place)**

### **Core Service (Fixed)**
- `slave/still_capture.py` → Now listens on port **5001** for rep1-7, port **6010** for rep8

### **Configuration (Updated)**
- `shared/config.py` → Updated port mappings to reflect correct usage

### **All Test Scripts (Updated)**
- `test_manual_capture.sh` → Now tests port **5001**
- `diagnose_capture_failure.sh` → Now checks port **5001** 
- `quick_fix_capture.sh` → Now verifies port **5001**
- `sync_to_slaves.sh` → Now expects port **5001**

### **New Diagnostic Tool**
- `diagnose_ports.sh` → Shows what ports are actually listening

---

## 🚀 **DEPLOYMENT INSTRUCTIONS**

### **Step 1: Deploy Fixed Services**
```bash
ssh andrc1@192.168.0.200
cd /home/andrc1/camera_system_integrated_final
./sync_to_slaves.sh
```

### **Step 2: Verify Port Configuration**
```bash
./diagnose_ports.sh
```

### **Step 3: Test Manual Capture**
```bash
./test_manual_capture.sh
```

---

## 🎯 **Expected Results After Fix**

### **Port Configuration**
```
rep1: Still capture service listening on port 5001 ✅
rep2: Still capture service listening on port 5001 ✅  
rep3: Still capture service listening on port 5001 ✅
rep4: Still capture service listening on port 5001 ✅
rep5: Still capture service listening on port 5001 ✅
rep6: Still capture service listening on port 5001 ✅
rep7: Still capture service listening on port 5001 ✅
rep8: Still capture service listening on port 6010 ✅ (local camera)
```

### **Manual Test Commands (Now Working)**
```bash
# These should now work:
echo 'CAPTURE_STILL' | nc -u 192.168.0.201 5001  # rep1
echo 'CAPTURE_STILL' | nc -u 192.168.0.202 5001  # rep2
echo 'CAPTURE_STILL' | nc -u 192.168.0.203 5001  # rep3
echo 'CAPTURE_STILL' | nc -u 192.168.0.204 5001  # rep4
echo 'CAPTURE_STILL' | nc -u 192.168.0.205 5001  # rep5
echo 'CAPTURE_STILL' | nc -u 192.168.0.206 5001  # rep6
echo 'CAPTURE_STILL' | nc -u 192.168.0.207 5001  # rep7
```

### **GUI Still Capture (Should Now Work)**
- GUI sending to port 5001 → Services listening on port 5001 ✅
- Still capture should work from GUI on all rep1-7 ✅

---

## 🔍 **Verification Steps**

### **1. Check Ports Are Listening**
```bash
./diagnose_ports.sh
```
Should show:
- Port 5001: ✅ LISTENING (for each rep1-7)
- Port 6000: ✅ NOT LISTENING (old port, should be unused)

### **2. Test Manual Commands**
```bash
./test_manual_capture.sh
```
Should show:
- All 7 devices responding to manual capture commands

### **3. Test GUI**
- Use GUI to capture stills on rep1-7
- Should now work correctly!

---

## 📊 **Port Summary**

| Device | Control Port | Still Capture Port | Video Port | Notes |
|--------|-------------|-------------------|------------|-------|
| rep1-7 | 5001 | **5001** (FIXED) | 5002 | Commands sent to control port |
| rep8 | 5011 | **6010** (unchanged) | 5012 | Local camera, different ports |

---

## 🚨 **If Still Not Working**

### **Step 1: Check Port Diagnosis**
```bash
./diagnose_ports.sh
```

### **Step 2: Check Service Logs**
```bash
# Example for rep1
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'
# Should show: "BOUND to port 5001"
```

### **Step 3: Manual Test**
```bash
echo 'CAPTURE_STILL' | nc -u 192.168.0.201 5001
# Should trigger capture activity in logs
```

---

## 🎉 **This Should Fix The Issue!**

The port mismatch was the root cause. Now that services listen on port **5001** (where GUI sends commands), still capture should work on all rep1-7 devices.

**Deploy the fix and test!** 🚀
