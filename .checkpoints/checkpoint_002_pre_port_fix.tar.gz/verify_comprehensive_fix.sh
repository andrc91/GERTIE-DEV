#!/bin/bash
# COMPREHENSIVE VERIFICATION: Check all services and ports
# Run on control1 to verify the fix worked

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }

echo -e "${BLUE}🔍 COMPREHENSIVE SYSTEM VERIFICATION${NC}"
echo -e "${BLUE}===================================${NC}"
echo ""

all_good=true

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    echo -e "${BLUE}📊 Checking rep$i ($SLAVE_IP)...${NC}"
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        all_good=false
        continue
    fi
    log_success "rep$i: Network connectivity OK"
    
    # Check still capture service
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
        log_success "rep$i: Still capture service running"
        
        # Check port binding
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "netstat -uln | grep ':6000'" 2>/dev/null | grep -q "6000"; then
            log_success "rep$i: Port 6000 listening correctly"
        else
            log_error "rep$i: Port 6000 NOT listening"
            all_good=false
        fi
        
        # Check device detection
        device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='5 minutes ago' | grep 'FINAL DETECTION' | tail -1" 2>/dev/null)
        if echo "$device_detection" | grep -q "rep$i"; then
            log_success "rep$i: Device detection correct"
        else
            log_error "rep$i: Device detection wrong or missing"
            all_good=false
        fi
        
    else
        log_error "rep$i: Still capture service NOT running"
        all_good=false
    fi
    
    # Check video stream service
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active video_stream.service" 2>/dev/null | grep -q "active"; then
        log_success "rep$i: Video stream service running"
    else
        log_error "rep$i: Video stream service NOT running"
        all_good=false
    fi
    
    # Test manual still capture
    log_info "Testing manual capture on rep$i..."
    if echo 'CAPTURE_STILL' | timeout 5 nc -u $SLAVE_IP 6000 2>/dev/null; then
        log_success "rep$i: Manual capture command accepted"
    else
        log_error "rep$i: Manual capture command failed"
        all_good=false
    fi
    
    echo ""
done

# Summary
echo -e "${BLUE}📋 OVERALL VERIFICATION RESULT${NC}"
echo -e "${BLUE}=============================${NC}"

if $all_good; then
    log_success "🎉 ALL SYSTEMS WORKING CORRECTLY!"
    echo -e "${GREEN}✅ All rep1-7 services running${NC}"
    echo -e "${GREEN}✅ All devices binding to port 6000${NC}"
    echo -e "${GREEN}✅ All device detection correct${NC}"
    echo -e "${GREEN}✅ All manual captures working${NC}"
    echo ""
    echo -e "${GREEN}GUI still capture should now work perfectly!${NC}"
else
    log_error "⚠️  SOME ISSUES DETECTED"
    echo -e "${RED}Check the individual device results above.${NC}"
    echo -e "${YELLOW}Run deployment again if needed:${NC}"
    echo -e "${YELLOW}  ./sync_to_slaves.sh${NC}"
fi

echo ""
echo -e "${BLUE}💡 MANUAL TEST COMMANDS:${NC}"
echo -e "${GREEN}# Test individual device:${NC}"
echo -e "${GREEN}echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000${NC}"
echo -e "${GREEN}# Check service logs:${NC}"
echo -e "${GREEN}ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'${NC}"
echo ""
