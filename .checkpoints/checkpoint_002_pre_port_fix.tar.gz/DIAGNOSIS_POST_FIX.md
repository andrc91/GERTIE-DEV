# CAMERA SYSTEM DIAGNOSIS - POST-FIX ISSUES

## Issue 1: rep8 Preview Missing
**Problem**: Local camera slave (rep8) not streaming to GUI
**Root Cause**: Possible port conflict or race condition with local_camera_slave.py vs slave/*.py

## Issue 2: Transform Settings Not Applied Live  
**Problem**: Settings changes not visible in preview streams for rep1-rep7
**Root Cause**: Import boundary issue - video_stream.py imports settings but they may not update in real-time

## Issue 3: Directory Structure Wrong
**Problem**: Should save to captured_images/<date>/rep<N>/ but currently saves to Desktop/<date>/rep<N>/
**Root Cause**: Path structure change missed the captured_images parent folder

## MINIMAL FIXES NEEDED:

### Fix 1: rep8 Preview (Local Camera)
- Ensure local_camera_slave.py is NOT running when slave services start
- OR ensure rep8 uses slave/video_stream.py instead of local_camera_slave.py

### Fix 2: Live Transform Updates  
- Make video_stream.py check for settings changes periodically
- OR use shared memory/file for settings instead of Python imports

### Fix 3: Directory Path Correction
- Change network_manager.py path to include captured_images parent folder
