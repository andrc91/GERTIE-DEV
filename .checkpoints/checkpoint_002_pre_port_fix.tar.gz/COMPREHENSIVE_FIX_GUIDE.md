# 🔧 COMPREHENSIVE MULTI-CAMERA SYSTEM FIX

## Problem Summary
- **rep8 (local slave)**: Still capture + transforms working ✅
- **rep1-7 (remote slaves)**: Still capture failing ❌
- **Issue**: Services not binding to correct ports (6000) or failing to start

## Root Causes Fixed
1. **Port Configuration**: Changed rep1-7 to bind to port 6000 (not 5001)
2. **Service Files**: Fixed working directory and executable paths  
3. **Device Detection**: Simplified detection logic to be more reliable
4. **Service Binding**: Ensured proper startup and port binding

## Files Modified (In Place)
- `slave/still_capture.py` → Fixed port binding (6000 for rep1-7)
- `slave/video_stream.py` → Fixed device detection
- `still_capture.service` → Fixed working directory and paths
- `video_stream.service` → Fixed working directory and paths
- `shared/config.py` → Updated port configuration
- `sync_to_slaves.sh` → Enhanced deployment with verification

## Deployment Instructions

### Step 1: Deploy the Fix
```bash
# SSH to control1
ssh andrc1@192.168.0.200
cd /home/andrc1/camera_system_integrated_final

# Deploy comprehensive fix
./sync_to_slaves.sh
```

### Step 2: Verify the Fix
```bash
# Run verification script
./verify_comprehensive_fix.sh
```

### Step 3: Test Manual Capture (If Needed)
```bash
# Test individual devices
echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000  # rep1
echo 'CAPTURE_STILL' | nc -u 192.168.0.202 6000  # rep2
# ... etc for rep3-7
```

## Expected Results After Fix

### Port Configuration
| Device | Still Capture Port | Status |
|--------|-------------------|--------|
| rep1   | 6000             | ✅ Fixed |
| rep2   | 6000             | ✅ Fixed |
| rep3   | 6000             | ✅ Fixed |
| rep4   | 6000             | ✅ Fixed |
| rep5   | 6000             | ✅ Fixed |
| rep6   | 6000             | ✅ Fixed |
| rep7   | 6000             | ✅ Fixed |
| rep8   | 6010             | ✅ Already working |

### Service Status
All devices should show:
- ✅ `still_capture.service` active and running
- ✅ `video_stream.service` active and running  
- ✅ Port 6000 listening (rep1-7) or 6010 (rep8)
- ✅ Correct device detection in logs

## Troubleshooting

### If Services Not Starting
```bash
# Check individual device
ssh andrc1@192.168.0.201 'systemctl status still_capture.service'
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'

# Restart if needed
ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture.service'
```

### If Wrong Port Binding
```bash
# Check what ports are listening
ssh andrc1@192.168.0.201 'netstat -uln | grep 6000'

# Should show: 0.0.0.0:6000
```

### If Device Detection Wrong
```bash
# Check detection logs
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service | grep "FINAL DETECTION"'

# Should show: FINAL DETECTION: 192.168.0.201 -> rep1
```

### If GUI Still Not Working
1. Verify all services running: `./verify_comprehensive_fix.sh`
2. Test manual capture works on all devices
3. Check GUI is sending to port 6000 for rep1-7

## Key Changes Made

### 1. Port Standardization
- **Before**: Inconsistent ports (some 5001, some 6000)
- **After**: Consistent port 6000 for all rep1-7, port 6010 for rep8

### 2. Service File Fixes
- **Before**: Working directory `/home/andrc1/camera_system_integrated_final/slave`
- **After**: Working directory `/home/andrc1/camera_system_integrated_final` with full paths

### 3. Device Detection Simplification
- **Before**: Complex 5-method detection with edge cases
- **After**: Simplified 3-method detection focused on reliability

### 4. Enhanced Deployment
- **Before**: Basic file copy with minimal verification
- **After**: Comprehensive deployment with port testing and verification

## Success Criteria
✅ All rep1-7 services start correctly  
✅ All devices bind to port 6000  
✅ All devices detect correct identity (rep1, rep2, etc.)  
✅ Manual capture commands work on all devices  
✅ GUI still capture works on all rep1-7  

## Emergency Rollback
If issues occur, the original files are backed up:
- `slave/video_stream.py.backup`
- `local_camera_slave.py.backup`

## Contact/Support
- All changes made in place, no file renames
- Services use consistent andrc1 user
- Working in isolated network environment
- No external dependencies required

**The fix should resolve the still capture issues on rep1-7 while maintaining rep8 functionality.**
