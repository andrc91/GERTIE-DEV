#!/usr/bin/env python3
"""
COMPREHENSIVE DEVICE NAMING TEST
Tests all components to ensure consistent rep1, rep2, etc. naming without underscores
"""

import sys
import os
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def test_transforms_module():
    """Test the unified transforms module device naming"""
    logging.info("🔍 Testing shared/transforms.py device naming...")
    
    try:
        sys.path.append('/Users/andrew1/Desktop/camera_system_integrated_final')
        from shared.transforms import get_device_name_from_ip
        
        device_name = get_device_name_from_ip()
        logging.info(f"✅ Transforms module device name: {device_name}")
        
        if "_" in device_name:
            logging.error(f"❌ TRANSFORMS MODULE CONTAINS UNDERSCORE: {device_name}")
            return False
        else:
            logging.info(f"✅ Transforms module naming is correct: {device_name}")
            return True
            
    except Exception as e:
        logging.error(f"❌ Error testing transforms module: {e}")
        return False

def test_still_capture_module():
    """Test still_capture.py device naming"""
    logging.info("🔍 Testing slave/still_capture.py device naming...")
    
    try:
        sys.path.append('/Users/andrew1/Desktop/camera_system_integrated_final/slave')
        
        # Read still_capture.py to check if it uses unified naming
        with open('/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py', 'r') as f:
            content = f.read()
            
        if "get_device_name_from_ip" in content:
            logging.info("✅ still_capture.py uses unified device naming function")
            return True
        elif "def get_device_name" in content:
            # Check if local function uses unified approach
            if "from shared.transforms import get_device_name_from_ip" in content:
                logging.info("✅ still_capture.py local function uses unified approach")
                return True
            else:
                logging.error("❌ still_capture.py has local device naming that may not be unified")
                return False
        else:
            logging.error("❌ still_capture.py doesn't use device naming functions")
            return False
            
    except Exception as e:
        logging.error(f"❌ Error testing still_capture module: {e}")
        return False

def test_video_stream_module():
    """Test video_stream.py device naming"""
    logging.info("🔍 Testing slave/video_stream.py device naming...")
    
    try:
        # Read video_stream.py to check if it uses unified naming
        with open('/Users/andrew1/Desktop/camera_system_integrated_final/slave/video_stream.py', 'r') as f:
            content = f.read()
            
        if "get_device_name_from_ip" in content:
            logging.info("✅ video_stream.py uses unified device naming function")
            return True
        else:
            logging.error("❌ video_stream.py doesn't use unified device naming")
            return False
            
    except Exception as e:
        logging.error(f"❌ Error testing video_stream module: {e}")
        return False

def test_local_camera_module():
    """Test local_camera_slave.py device naming"""
    logging.info("🔍 Testing local_camera_slave.py device naming...")
    
    try:
        # Read local_camera_slave.py to check device naming
        with open('/Users/andrew1/Desktop/camera_system_integrated_final/local_camera_slave.py', 'r') as f:
            content = f.read()
            
        # Check if it uses "rep8" consistently
        if 'device_name = "rep8"' in content:
            logging.info("✅ local_camera_slave.py uses correct rep8 naming")
            return True
        elif "rep_8" in content:
            logging.error("❌ local_camera_slave.py contains underscore format")
            return False
        else:
            logging.warning("⚠️ local_camera_slave.py device naming unclear")
            return True
            
    except Exception as e:
        logging.error(f"❌ Error testing local_camera module: {e}")
        return False

def test_settings_files():
    """Test that settings files exist with correct naming"""
    logging.info("🔍 Testing settings files naming...")
    
    correct_files = []
    incorrect_files = []
    
    # Check for correct format files
    for i in range(1, 9):
        correct_file = f"/Users/andrew1/Desktop/camera_system_integrated_final/rep{i}_settings.json"
        if os.path.exists(correct_file):
            correct_files.append(f"rep{i}_settings.json")
    
    # Check for incorrect format files (with underscore)
    for i in range(1, 9):
        incorrect_file = f"/Users/andrew1/Desktop/camera_system_integrated_final/rep_{i}_settings.json"
        if os.path.exists(incorrect_file):
            incorrect_files.append(f"rep_{i}_settings.json")
    
    logging.info(f"✅ Found correct format files: {correct_files}")
    
    if incorrect_files:
        logging.error(f"❌ Found INCORRECT format files: {incorrect_files}")
        return False
    else:
        logging.info("✅ No incorrect format files found")
        return True

def create_test_settings():
    """Create test settings files to verify naming"""
    logging.info("🔧 Creating test settings files...")
    
    try:
        # Import the unified settings creation system
        sys.path.append('/Users/andrew1/Desktop/camera_system_integrated_final')
        from shared.transforms import save_device_settings, DEFAULT_SETTINGS
        
        for i in range(1, 9):
            device_name = f"rep{i}"
            save_device_settings(device_name, DEFAULT_SETTINGS)
            logging.info(f"✅ Created settings for {device_name}")
            
        return True
        
    except Exception as e:
        logging.error(f"❌ Error creating test settings: {e}")
        return False

def main():
    """Run comprehensive device naming test"""
    logging.info("🚀 COMPREHENSIVE DEVICE NAMING TEST")
    logging.info("=" * 50)
    
    tests_passed = 0
    total_tests = 6
    
    # Test all components
    if test_transforms_module():
        tests_passed += 1
    
    if test_still_capture_module():
        tests_passed += 1
        
    if test_video_stream_module():
        tests_passed += 1
        
    if test_local_camera_module():
        tests_passed += 1
        
    if test_settings_files():
        tests_passed += 1
        
    if create_test_settings():
        tests_passed += 1
    
    logging.info("=" * 50)
    logging.info(f"📊 RESULT: {tests_passed}/{total_tests} tests passed")
    
    if tests_passed == total_tests:
        logging.info("🎉 ALL DEVICE NAMING TESTS PASSED!")
        logging.info("✅ System should create rep1_settings.json, rep2_settings.json, etc.")
        logging.info("✅ No underscore format (rep_1_settings.json) should exist")
        return True
    else:
        logging.error("❌ DEVICE NAMING ISSUES DETECTED!")
        logging.error("🔧 Need to fix components that failed tests")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
