#!/usr/bin/env python3
"""
Brightness Settings Migration Script
Fixes existing rep*_settings.json files to use correct GUI brightness scale
Run this on control1 (Mac) before syncing to slaves
"""

import json
import os
import glob
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def migrate_settings_file(filepath):
    """Migrate a single settings file from old brightness scale to GUI scale"""
    try:
        with open(filepath, 'r') as f:
            settings = json.load(f)
        
        # Check and fix brightness scale
        old_brightness = settings.get('brightness', 0)
        
        if old_brightness > 50:  # Old scale (0-100)
            new_brightness = 0  # Convert to GUI neutral
            logging.info(f"  {os.path.basename(filepath)}: brightness {old_brightness} → {new_brightness} (old scale → GUI neutral)")
            settings['brightness'] = new_brightness
            settings_changed = True
        elif old_brightness == 50:  # Old neutral (50 on 0-100 scale)
            new_brightness = 0  # Convert to GUI neutral  
            logging.info(f"  {os.path.basename(filepath)}: brightness {old_brightness} → {new_brightness} (old neutral → GUI neutral)")
            settings['brightness'] = new_brightness
            settings_changed = True
        elif -50 <= old_brightness <= 50:  # Already on GUI scale
            logging.info(f"  {os.path.basename(filepath)}: brightness {old_brightness} (already on GUI scale)")
            settings_changed = False
        else:  # Invalid range
            new_brightness = 0
            logging.warning(f"  {os.path.basename(filepath)}: brightness {old_brightness} → {new_brightness} (invalid range → GUI neutral)")
            settings['brightness'] = new_brightness
            settings_changed = True
        
        # Save if changed
        if settings_changed:
            # Create backup first
            backup_path = filepath + '.backup'
            if not os.path.exists(backup_path):
                os.rename(filepath, backup_path)
                logging.info(f"  Backup created: {os.path.basename(backup_path)}")
            
            # Save updated settings
            with open(filepath, 'w') as f:
                json.dump(settings, f, indent=2)
            logging.info(f"  ✅ Updated: {os.path.basename(filepath)}")
        
        return True
        
    except Exception as e:
        logging.error(f"  ❌ Failed to migrate {filepath}: {e}")
        return False

def main():
    """Main migration function"""
    logging.info("🔧 Starting brightness settings migration...")
    
    # Find all rep*_settings.json files
    settings_pattern = "/Users/andrew1/Desktop/camera_system_integrated_final/rep*_settings.json"
    settings_files = glob.glob(settings_pattern)
    
    if not settings_files:
        logging.info("No settings files found to migrate")
        return
    
    logging.info(f"Found {len(settings_files)} settings files to check:")
    
    migrated_count = 0
    for settings_file in sorted(settings_files):
        logging.info(f"Checking {os.path.basename(settings_file)}...")
        if migrate_settings_file(settings_file):
            migrated_count += 1
    
    logging.info(f"✅ Migration complete: {migrated_count}/{len(settings_files)} files processed")
    logging.info("All settings files now use GUI brightness scale (-50 to +50, 0 = neutral)")

if __name__ == "__main__":
    main()
