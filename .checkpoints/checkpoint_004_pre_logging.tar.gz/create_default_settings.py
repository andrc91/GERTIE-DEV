#!/usr/bin/env python3
"""
Create default settings files for all camera replicas
Run this on control1 Pi to ensure all rep settings exist
"""

import json
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')

# Default camera settings
DEFAULT_SETTINGS = {
    'brightness': 50,
    'contrast': 50,
    'iso': 100,
    'shutter_speed': 1000,
    'saturation': 50,
    'white_balance': 'auto',
    'exposure_mode': 'auto',
    'jpeg_quality': 80,
    'fps': 30,
    'resolution': '640x480',
    'image_format': 'JPEG',
    'crop_enabled': False,
    'crop_x': 0,
    'crop_y': 0,
    'crop_width': 4608,
    'crop_height': 2592,
    'flip_horizontal': False,
    'flip_vertical': False,
    'grayscale': False,
    'rotation': 0
}

def create_settings_files():
    """Create default settings files for all replicas"""
    # Determine correct path based on OS
    import platform
    if platform.system() == "Darwin":  # macOS
        settings_dir = "."  # Current directory for macOS development
        logging.info("Running on macOS - creating settings files in current directory")
    else:  # Linux/Pi
        settings_dir = "/home/andrc1"
        logging.info("Running on Pi - creating settings files in /home/andrc1")
    
    # Ensure directory exists
    os.makedirs(settings_dir, exist_ok=True)
    
    # Create settings for rep1-rep8
    for i in range(1, 9):
        device_name = f"rep{i}"
        settings_file = f"{settings_dir}/{device_name}_settings.json"
        
        if not os.path.exists(settings_file):
            try:
                with open(settings_file, 'w') as f:
                    json.dump(DEFAULT_SETTINGS, f, indent=2)
                logging.info(f"✅ Created settings file for {device_name}")
            except Exception as e:
                logging.error(f"❌ Failed to create settings for {device_name}: {e}")
        else:
            logging.info(f"📁 Settings file for {device_name} already exists")
    
    logging.info("🎉 All settings files initialized")

def main():
    logging.info("🚀 Creating default settings files for all camera replicas")
    create_settings_files()

if __name__ == "__main__":
    main()
