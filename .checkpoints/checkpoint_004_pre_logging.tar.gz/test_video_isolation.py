#!/usr/bin/env python3
"""
Video Stream Interference Diagnostic
Specifically checks for video stream interfering with still captures
Run this to verify the isolation fix works
"""

import logging
import subprocess
import time
import json

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def test_camera_isolation():
    """Test if still capture properly isolates from video stream"""
    logging.info("🔍 TESTING CAMERA RESOURCE ISOLATION")
    logging.info("="*50)
    
    test_cameras = [
        {'name': 'rep1', 'ip': '192.168.0.201', 'port': 6000},
        {'name': 'rep2', 'ip': '192.168.0.202', 'port': 6000}
    ]
    
    for camera in test_cameras:
        logging.info(f"📸 Testing {camera['name']} ({camera['ip']})...")
        
        try:
            # Trigger still capture
            capture_cmd = f"echo 'CAPTURE_STILL' | nc -u {camera['ip']} {camera['port']}"
            subprocess.run(capture_cmd, shell=True, timeout=10)
            logging.info(f"✅ {camera['name']}: Capture command sent")
            
            # Wait for capture to complete
            time.sleep(8)  # Extended wait for new isolation logic
            
            # Check logs for isolation indicators
            log_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{camera['ip']} 'journalctl -u still_capture.service --since=\"3 minutes ago\" --no-pager'"
            result = subprocess.run(log_cmd, shell=True, capture_output=True, text=True, timeout=15)
            
            if result.returncode == 0:
                logs = result.stdout
                
                # Check for isolation fix indicators
                isolation_indicators = {
                    'video_stop': 'MULTIPLE STOP_STREAM commands',
                    'extended_wait': 'Extended wait for video stream to COMPLETELY stop',
                    'isolated_capture': 'ISOLATED high resolution capture',
                    'exclusive_config': 'EXCLUSIVELY for 4608x2592 still capture',
                    'true_high_res': 'TRUE HIGH RES captured',
                    'resolution_check': 'RESOLUTION MISMATCH' not in logs,
                    'large_file': 'File size.*MB confirms TRUE high resolution',
                    'not_video_frame': 'VIDEO FRAME capture, not STILL capture' not in logs
                }
                
                logging.info(f"📋 {camera['name']}: Isolation test results:")
                for test, condition in isolation_indicators.items():
                    if isinstance(condition, bool):
                        status = "✅" if condition else "❌"
                        logging.info(f"   {status} {test}: {'PASS' if condition else 'FAIL'}")
                    else:
                        found = condition in logs
                        status = "✅" if found else "❌"
                        logging.info(f"   {status} {test}: {'FOUND' if found else 'NOT FOUND'}")
                
                # Check file size from logs
                import re
                file_size_matches = re.findall(r'File size ([0-9.]+)MB', logs)
                if file_size_matches:
                    file_size = float(file_size_matches[-1])
                    if file_size > 2.0:
                        logging.info(f"   ✅ File size: {file_size}MB (TRUE high resolution)")
                    elif file_size > 1.0:
                        logging.warning(f"   ⚠️  File size: {file_size}MB (borderline)")
                    else:
                        logging.error(f"   ❌ File size: {file_size}MB (VIDEO FRAME - not still!)")
                
                # Show key log lines
                key_lines = []
                for line in logs.split('\n'):
                    if any(keyword in line for keyword in ['ISOLATED', 'EXCLUSIVELY', 'TRUE HIGH RES', 'RESOLUTION MISMATCH', 'VIDEO FRAME']):
                        key_lines.append(line.strip())
                
                if key_lines:
                    logging.info(f"📋 {camera['name']}: Key log lines:")
                    for line in key_lines[-5:]:  # Last 5 key lines
                        logging.info(f"   {line}")
                
            else:
                logging.error(f"❌ {camera['name']}: Failed to retrieve logs")
                
        except Exception as e:
            logging.error(f"❌ {camera['name']}: Test failed: {e}")

def check_video_stream_status():
    """Check if video streams are running and their configuration"""
    logging.info("🎥 CHECKING VIDEO STREAM STATUS")
    logging.info("="*50)
    
    test_ips = ['192.168.0.201', '192.168.0.202']
    
    for ip in test_ips:
        device = f"rep{ip[-1]}"
        logging.info(f"🎥 Checking video stream on {device} ({ip})...")
        
        try:
            # Check video stream service status
            status_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{ip} 'systemctl is-active video_stream.service'"
            result = subprocess.run(status_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0 and 'active' in result.stdout:
                logging.info(f"✅ {device}: Video stream service is active")
                
                # Check video stream logs for resolution
                video_log_cmd = f"ssh -o StrictHostKeyChecking=no andrc1@{ip} 'journalctl -u video_stream.service --since=\"5 minutes ago\" | grep -i resolution'"
                result = subprocess.run(video_log_cmd, shell=True, capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0 and result.stdout.strip():
                    logging.info(f"📋 {device}: Video resolution logs:")
                    for line in result.stdout.strip().split('\n'):
                        logging.info(f"   {line}")
                else:
                    logging.info(f"   No recent video resolution logs found")
                    
            else:
                logging.warning(f"⚠️  {device}: Video stream service not active")
                
        except Exception as e:
            logging.error(f"❌ {device}: Video stream check failed: {e}")

def generate_isolation_recommendations():
    """Generate recommendations based on test results"""
    logging.info("")
    logging.info("📋 ISOLATION FIX RECOMMENDATIONS")
    logging.info("="*50)
    logging.info("")
    logging.info("DEPLOY THE ISOLATION FIX:")
    logging.info("   cd ~/Desktop/camera_system_integrated_final")
    logging.info("   # Copy updated directory to USB")
    logging.info("   # Update control1 with USB content")
    logging.info("   # Run: ./sync_to_slaves.sh")
    logging.info("")
    logging.info("VERIFY ISOLATION WORKING:")
    logging.info("   echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000")
    logging.info("   ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since=\"2 minutes ago\" | grep ISOLATED'")
    logging.info("")
    logging.info("CHECK FOR SUCCESS INDICATORS:")
    logging.info("   • 'ISOLATED high resolution capture'")
    logging.info("   • 'EXCLUSIVELY for 4608x2592 still capture'")
    logging.info("   • 'TRUE HIGH RES captured: (2592, 4608)'")
    logging.info("   • 'File size X.XMB confirms TRUE high resolution'")
    logging.info("   • File size >2MB (not <1MB)")
    logging.info("")
    logging.info("FAILURE INDICATORS TO WATCH FOR:")
    logging.info("   • 'RESOLUTION MISMATCH!'")
    logging.info("   • 'Camera still in VIDEO mode - not STILL mode!'")
    logging.info("   • 'VIDEO FRAME capture, not STILL capture!'")
    logging.info("   • File size <1MB")

def main():
    """Main isolation diagnostic"""
    logging.info("🎯 VIDEO STREAM INTERFERENCE DIAGNOSTIC")
    logging.info("Testing camera resource isolation fix")
    logging.info("="*60)
    
    try:
        # Test camera isolation
        test_camera_isolation()
        print()
        
        # Check video stream status
        check_video_stream_status()
        
        # Generate recommendations
        generate_isolation_recommendations()
        
    except Exception as e:
        logging.error(f"❌ Isolation diagnostic failed: {e}")

if __name__ == "__main__":
    main()
