#!/bin/bash
# SERVICE DIAGNOSIS: Check actual service status without external tools
# Run this on control1 to see what's actually running on each slave

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_check() { echo -e "${BLUE}🔍 $1${NC}"; }

echo -e "${BLUE}🔍 SERVICE DIAGNOSIS: Without External Tools${NC}"
echo -e "${BLUE}===========================================${NC}"
echo ""

working_devices=0
total_devices=7

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_check "DIAGNOSING rep$i ($SLAVE_IP)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable via ping"
        continue
    fi
    echo "  📡 Network: OK"
    
    # Check if still capture service is running
    still_status=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null)
    echo "  🔧 still_capture.service: $still_status"
    
    if [[ "$still_status" == "active" ]]; then
        log_success "rep$i: Service is running"
        
        # Check recent logs for startup and device detection
        echo "  📋 Recent service logs:"
        recent_logs=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='5 minutes ago' --no-pager | tail -10" 2>/dev/null)
        if [[ -n "$recent_logs" ]]; then
            echo "$recent_logs" | sed 's/^/    /'
            
            # Check for specific indicators
            if echo "$recent_logs" | grep -q "DEVICE DETECTION.*rep$i"; then
                log_success "rep$i: ✅ Correct device detection found"
            else
                log_error "rep$i: ❌ No correct device detection in recent logs"
            fi
            
            if echo "$recent_logs" | grep -q "BOUND to port"; then
                port_info=$(echo "$recent_logs" | grep "BOUND to port" | tail -1)
                echo "    Port binding: $port_info"
                if echo "$port_info" | grep -q "port 5001"; then
                    log_success "rep$i: ✅ Bound to correct port (5001)"
                else
                    log_error "rep$i: ❌ Bound to wrong port"
                fi
            else
                log_error "rep$i: ❌ No port binding information"
            fi
            
            if echo "$recent_logs" | grep -q "READY.*Waiting for CAPTURE_STILL"; then
                log_success "rep$i: ✅ Service ready to receive commands"
                working_devices=$((working_devices + 1))
            else
                log_error "rep$i: ❌ Service not ready to receive commands"
            fi
        else
            log_error "rep$i: No recent logs found"
        fi
        
        # Check what processes are using network ports
        echo "  🔌 Network ports in use:"
        network_info=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "ss -ulnp | grep python" 2>/dev/null)
        if [[ -n "$network_info" ]]; then
            echo "$network_info" | sed 's/^/    /'
        else
            echo "    No python processes listening on UDP ports"
        fi
        
    else
        log_error "rep$i: Service not active - Status: $still_status"
        
        # Show why service failed
        echo "  🚨 Service failure details:"
        failure_logs=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='10 minutes ago' --no-pager | tail -5" 2>/dev/null)
        if [[ -n "$failure_logs" ]]; then
            echo "$failure_logs" | sed 's/^/    /'
        fi
    fi
    
    # Check if the script file exists and is executable
    script_check=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "ls -la /home/andrc1/camera_system_integrated_final/slave/still_capture.py" 2>/dev/null)
    if [[ -n "$script_check" ]]; then
        echo "  📄 Script file: EXISTS"
        echo "    $script_check"
    else
        log_error "rep$i: ❌ Script file missing"
    fi
    
    # Check service file
    service_file_check=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "ls -la /etc/systemd/system/still_capture.service" 2>/dev/null)
    if [[ -n "$service_file_check" ]]; then
        echo "  📄 Service file: EXISTS"
    else
        log_error "rep$i: ❌ Service file missing"
    fi
    
    echo ""
done

echo "📊 DIAGNOSIS SUMMARY"
echo "==================="
log_success "Working devices: $working_devices/$total_devices"

if [[ $working_devices -eq $total_devices ]]; then
    log_success "🎉 ALL SERVICES APPEAR TO BE WORKING!"
    echo -e "${GREEN}Issue might be in GUI communication or command format${NC}"
elif [[ $working_devices -gt 0 ]]; then
    log_success "Some services working"
    echo -e "${YELLOW}$((total_devices - working_devices)) services need fixing${NC}"
else
    log_error "NO SERVICES WORKING PROPERLY"
    echo -e "${RED}Major deployment or configuration issue${NC}"
fi

echo ""
echo "🔧 NEXT STEPS"
echo "============="
if [[ $working_devices -eq $total_devices ]]; then
    echo "✅ All services running correctly"
    echo "🔍 Issue is likely:"
    echo "   - GUI not sending commands to correct IPs/ports"
    echo "   - Commands not reaching services"
    echo "   - GUI waiting for wrong response format"
elif [[ $working_devices -gt 0 ]]; then
    echo "🔧 Fix non-working services:"
    echo "   - Re-deploy: ./sync_to_slaves.sh"
    echo "   - Check failed service logs above"
else
    echo "🚨 Complete re-deployment needed:"
    echo "   - ./sync_to_slaves.sh"
    echo "   - Check network connectivity"
    echo "   - Verify file permissions"
fi

echo ""
echo "📋 TEST WITHOUT NETCAT"
echo "======================"
echo "Since nc is not installed, test using Python directly:"
echo ""
for i in {1..7}; do
    echo "rep$i test:"
    echo "  ssh andrc1@192.168.0.20$i 'python3 -c \"import socket; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.sendto(b'CAPTURE_STILL', ('127.0.0.1', 5001))\"'"
done
