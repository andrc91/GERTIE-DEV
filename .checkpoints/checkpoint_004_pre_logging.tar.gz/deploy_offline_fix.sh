#!/bin/bash
# OFFLINE FIX: Deploy camera system without external dependencies
# Works in isolated network without internet connection
# Run on control1 after copying from MacBook via USB

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_deploy() { echo -e "${BLUE}📤 $1${NC}"; }

cd /home/andrc1/camera_system_integrated_final

echo -e "${BLUE}🚀 DEPLOYING OFFLINE DEVICE DETECTION FIXES${NC}"
echo -e "${BLUE}==========================================${NC}"
echo -e "${YELLOW}🎯 OFFLINE FIXES:${NC}"
echo -e "${GREEN}  ✅ NO EXTERNAL DEPENDENCIES: Works without internet${NC}"
echo -e "${GREEN}  ✅ ROBUST IP DETECTION: Multiple fallback methods${NC}"
echo -e "${GREEN}  ✅ SYSTEM COMMAND BASED: Uses 'ip addr show' and 'ip route'${NC}"
echo -e "${GREEN}  ✅ FIXED SERVICE USER: Runs as andrc1 (not root)${NC}"
echo -e "${GREEN}  ✅ HOSTNAME PARSING: Extracts rep number from hostname${NC}"
echo ""

log_info "Deploying OFFLINE camera system to all slaves (rep1-rep7)..."

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_deploy "Deploying OFFLINE FIXED code to rep$i ($SLAVE_IP)..."
    
    # Test connectivity first
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        continue
    fi
    
    # Create necessary directories
    ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "mkdir -p /home/andrc1/camera_system_integrated_final/slave /home/andrc1/camera_system_integrated_final/shared" 2>/dev/null
    
    # Sync OFFLINE files (no external dependencies)
    if scp -o StrictHostKeyChecking=no slave/still_capture_offline.py "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/slave/" 2>/dev/null && \
       scp -o StrictHostKeyChecking=no slave/video_stream_offline.py "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/slave/" 2>/dev/null && \
       scp -o StrictHostKeyChecking=no shared/transforms.py "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/shared/" 2>/dev/null && \
       scp -o StrictHostKeyChecking=no shared/config.py "andrc1@$SLAVE_IP:/home/andrc1/camera_system_integrated_final/shared/" 2>/dev/null && \
       scp -o StrictHostKeyChecking=no still_capture_offline.service "andrc1@$SLAVE_IP:/home/andrc1/" 2>/dev/null && \
       scp -o StrictHostKeyChecking=no video_stream_offline.service "andrc1@$SLAVE_IP:/home/andrc1/" 2>/dev/null; then
        log_success "rep$i: OFFLINE files synced"
        
        # Update service configuration
        log_deploy "Installing OFFLINE services on rep$i..."
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "sudo cp /home/andrc1/still_capture_offline.service /etc/systemd/system/ && sudo cp /home/andrc1/video_stream_offline.service /etc/systemd/system/ && sudo systemctl daemon-reload" 2>/dev/null; then
            log_success "rep$i: OFFLINE services installed"
        else
            log_error "rep$i: Failed to install services"
        fi
        
        # Stop old services first (if they exist)
        log_deploy "Stopping old services on rep$i..."
        ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "sudo systemctl stop still_capture.service video_stream.service" 2>/dev/null || true
        ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "sudo systemctl disable still_capture.service video_stream.service" 2>/dev/null || true
        
        # Start new OFFLINE services
        log_deploy "Starting OFFLINE services on rep$i..."
        if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "sudo systemctl enable still_capture_offline.service video_stream_offline.service && sudo systemctl start still_capture_offline.service video_stream_offline.service" 2>/dev/null; then
            log_success "rep$i: OFFLINE services started"
            
            # Check still capture service specifically with more time
            sleep 5  # Give service more time to start and detect device
            if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture_offline.service" 2>/dev/null | grep -q "active"; then
                log_success "rep$i: Still capture OFFLINE service is active"
                
                # CRITICAL: Check device detection in logs 
                device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture_offline.service --since='1 minute ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
                if [[ -n "$device_detection" ]]; then
                    log_success "rep$i: $device_detection"
                    # Check if it's correctly detecting rep$i (not rep8)
                    if echo "$device_detection" | grep -q "rep$i"; then
                        log_success "rep$i: ✅ CORRECT device detection"
                    else
                        log_error "rep$i: ❌ WRONG device detection - check logs"
                    fi
                else
                    log_error "rep$i: No device detection found in logs"
                fi
                
                # Also check port binding
                port_check=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture_offline.service --since='1 minute ago' | grep 'BOUND to port' | tail -1" 2>/dev/null)
                if [[ -n "$port_check" ]]; then
                    log_success "rep$i: $port_check"
                else
                    log_error "rep$i: No port binding info found"
                fi
            else
                log_error "rep$i: Still capture OFFLINE service failed to start"
                # Show service status for debugging
                ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl status still_capture_offline.service --no-pager -l" 2>/dev/null | head -10
            fi
            
            # Check video stream service
            if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active video_stream_offline.service" 2>/dev/null | grep -q "active"; then
                log_success "rep$i: Video stream OFFLINE service is active"
                
                # Check video device detection
                video_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u video_stream_offline.service --since='1 minute ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
                if [[ -n "$video_detection" ]]; then
                    if echo "$video_detection" | grep -q "rep$i"; then
                        log_success "rep$i: ✅ CORRECT video device detection"
                    else
                        log_error "rep$i: ❌ WRONG video device detection"
                    fi
                else
                    log_error "rep$i: No video device detection found in logs"
                fi
            else
                log_error "rep$i: Video stream OFFLINE service failed to start"
            fi
        else
            log_error "rep$i: Failed to start OFFLINE services"
        fi
    else
        log_error "rep$i: Failed to sync files"
    fi
done

# Restart local services too
log_info "Restarting local camera service..."
if sudo systemctl restart local_camera_slave.service 2>/dev/null; then
    log_success "Local camera service restarted"
else
    log_error "Failed to restart local camera service"
fi

echo ""
log_success "🎉 OFFLINE DEVICE DETECTION FIXES DEPLOYED!"
echo -e "${BLUE}🧪 IMMEDIATE VERIFICATION:${NC}"
echo -e "${GREEN}  1. Check rep1 logs: ssh andrc1@192.168.0.201 'journalctl -u still_capture_offline.service -f'${NC}"
echo -e "${GREEN}  2. Should show: DEVICE DETECTION: 192.168.0.201 -> rep1 (NOT rep8)${NC}"
echo -e "${GREEN}  3. Test still capture on each rep - should work correctly${NC}"
echo -e "${GREEN}  4. Each device should bind to correct port (6000 for rep1-7, 6010 for rep8)${NC}"
echo ""
echo -e "${YELLOW}📋 DEBUG COMMANDS:${NC}"
echo -e "${YELLOW}  - Check hostname: ssh andrc1@192.168.0.201 'hostname'${NC}"
echo -e "${YELLOW}  - Check IP: ssh andrc1@192.168.0.201 'ip addr show'${NC}"
echo -e "${YELLOW}  - Check service: ssh andrc1@192.168.0.201 'systemctl status still_capture_offline.service'${NC}"
echo -e "${YELLOW}  - Restart service: ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture_offline.service'${NC}"
echo ""
echo -e "${BLUE}🔍 VERIFY ALL DEVICES:${NC}"
echo -e "${GREEN}  ./verify_offline_detection.sh - Check all devices${NC}"
