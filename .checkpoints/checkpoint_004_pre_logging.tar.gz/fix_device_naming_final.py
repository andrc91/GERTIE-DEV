#!/usr/bin/env python3
"""
DEVICE NAMING FINAL FIX
Ensures all components use consistent rep1, rep2, etc. naming 
Cleans up any incorrect rep_1, rep_2, etc. files
"""

import os
import sys
import json
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# Default settings - corrected to match user requirements
DEFAULT_SETTINGS = {
    'brightness': 50,        # ✅ Default 50
    'contrast': 50,          # ✅ Default 50  
    'grayscale': False,      # ✅ Default False
    'flip_horizontal': False, # ✅ Default False
    'flip_vertical': False,  # ✅ Default False
    'rotation': 0,           # ✅ Default 0 (no rotation)
    'iso': 100,
    'saturation': 50,
    'white_balance': 'auto',
    'jpeg_quality': 80,
    'fps': 30,
    'resolution': '640x480',
    'crop_enabled': False,
    'crop_x': 0,
    'crop_y': 0,
    'crop_width': 4608,
    'crop_height': 2592
}

def clean_incorrect_settings_files():
    """Remove any incorrectly named settings files with underscores"""
    logging.info("🧹 Cleaning up incorrect settings files...")
    
    cleaned_files = []
    base_path = "/Users/andrew1/Desktop/camera_system_integrated_final"
    
    # Check for incorrect format files (rep_1, rep_2, etc.)
    for i in range(1, 9):
        incorrect_file = os.path.join(base_path, f"rep_{i}_settings.json")
        if os.path.exists(incorrect_file):
            try:
                os.remove(incorrect_file)
                cleaned_files.append(f"rep_{i}_settings.json")
                logging.info(f"🗑️  Removed incorrect file: rep_{i}_settings.json")
            except Exception as e:
                logging.error(f"❌ Failed to remove {incorrect_file}: {e}")
    
    if cleaned_files:
        logging.info(f"✅ Cleaned up {len(cleaned_files)} incorrect files: {cleaned_files}")
    else:
        logging.info("✅ No incorrect files found to clean")
    
    return len(cleaned_files)

def create_correct_settings_files():
    """Create correctly named settings files (rep1, rep2, etc.)"""
    logging.info("📁 Creating correct settings files...")
    
    created_files = []
    base_path = "/Users/andrew1/Desktop/camera_system_integrated_final"
    
    for i in range(1, 9):
        correct_file = os.path.join(base_path, f"rep{i}_settings.json")
        
        try:
            # Always overwrite to ensure correct default settings
            with open(correct_file, 'w') as f:
                json.dump(DEFAULT_SETTINGS, f, indent=4)
            
            created_files.append(f"rep{i}_settings.json")
            logging.info(f"✅ Created/updated: rep{i}_settings.json")
            
        except Exception as e:
            logging.error(f"❌ Failed to create {correct_file}: {e}")
    
    logging.info(f"✅ Created {len(created_files)} correct settings files")
    return len(created_files)

def add_settings_verification():
    """Add verification functions to transforms.py"""
    logging.info("🔧 Adding settings verification to transforms.py...")
    
    transforms_file = "/Users/andrew1/Desktop/camera_system_integrated_final/shared/transforms.py"
    
    verification_code = '''

def verify_settings_file_naming():
    """Verify that settings files use correct naming (rep1, not rep_1)"""
    import os
    import logging
    
    base_path = "/home/andrc1"  # Production path on Pi
    incorrect_files = []
    
    # Check for incorrect underscore format
    for i in range(1, 9):
        incorrect_file = os.path.join(base_path, f"rep_{i}_settings.json")
        if os.path.exists(incorrect_file):
            incorrect_files.append(f"rep_{i}_settings.json")
    
    if incorrect_files:
        logging.error(f"❌ INCORRECT SETTINGS FILES DETECTED: {incorrect_files}")
        logging.error("🔧 Run settings fix script to correct this")
        return False
    
    return True

def load_device_settings_safe(device_name):
    """Load device settings with naming verification"""
    import logging
    
    # Verify device name format is correct (no underscores)
    if "_" in device_name and device_name != "rep_8":  # rep_8 is wrong format
        logging.error(f"❌ INCORRECT DEVICE NAME FORMAT: {device_name}")
        logging.error("✅ Correct format: rep1, rep2, rep3, etc. (no underscores)")
        
        # Auto-correct if possible
        if device_name.startswith("rep_"):
            corrected_name = device_name.replace("rep_", "rep")
            logging.info(f"🔧 Auto-correcting {device_name} → {corrected_name}")
            device_name = corrected_name
    
    return load_device_settings(device_name)
'''
    
    try:
        # Read current transforms.py
        with open(transforms_file, 'r') as f:
            content = f.read()
        
        # Add verification code if not already present
        if "verify_settings_file_naming" not in content:
            content += verification_code
            
            with open(transforms_file, 'w') as f:
                f.write(content)
            
            logging.info("✅ Added settings verification to transforms.py")
        else:
            logging.info("✅ Settings verification already present")
        
        return True
        
    except Exception as e:
        logging.error(f"❌ Failed to update transforms.py: {e}")
        return False

def create_settings_monitor_script():
    """Create a script to monitor settings file access on Pi"""
    logging.info("📝 Creating settings monitor script...")
    
    monitor_script = '''#!/bin/bash
# Settings File Monitor - run on Pi to detect incorrect file access
echo "🔍 Monitoring settings file access..."
echo "Watching for incorrect underscore format access..."

# Monitor file system for settings file access
inotifywait -m -r /home/andrc1 --format '%w%f %e' -e access,modify,create,delete | while read file event; do
    if [[ "$file" == *"rep_"*"_settings.json" ]]; then
        echo "❌ INCORRECT FILE ACCESS DETECTED: $file ($event)"
        echo "🔧 This should be: $(echo $file | sed 's/rep_/rep/g')"
    elif [[ "$file" == *"rep"*"_settings.json" ]] && [[ "$file" != *"rep_"* ]]; then
        echo "✅ Correct file access: $file ($event)"
    fi
done
'''
    
    monitor_file = "/Users/andrew1/Desktop/camera_system_integrated_final/monitor_settings_access.sh"
    
    try:
        with open(monitor_file, 'w') as f:
            f.write(monitor_script)
        
        os.chmod(monitor_file, 0o755)
        logging.info("✅ Created settings monitor script")
        return True
        
    except Exception as e:
        logging.error(f"❌ Failed to create monitor script: {e}")
        return False

def update_diagnostic_script():
    """Update diagnostic script to check for naming issues"""
    logging.info("🔧 Updating diagnostic script...")
    
    diagnostic_file = "/Users/andrew1/Desktop/camera_system_integrated_final/master_diagnostic_comprehensive.py"
    
    # Add device naming check to diagnostic
    naming_check_code = '''
def check_device_naming():
    """Check that all devices use correct settings file naming"""
    logging.info("🔍 Checking device naming consistency...")
    
    incorrect_files = []
    missing_files = []
    
    for i in range(1, 8):  # rep1-rep7 (slaves)
        ip = f"192.168.0.20{i}"
        
        # Check for incorrect format on remote device
        try:
            result = subprocess.run([
                'ssh', '-o', 'StrictHostKeyChecking=no', 
                f'andrc1@{ip}', 
                f'ls /home/andrc1/rep_{i}_settings.json 2>/dev/null || echo "NOT_FOUND"'
            ], capture_output=True, text=True, timeout=3)
            
            if "NOT_FOUND" not in result.stdout:
                incorrect_files.append(f"rep_{i}_settings.json on {ip}")
        except:
            pass
            
        # Check for correct format
        try:
            result = subprocess.run([
                'ssh', '-o', 'StrictHostKeyChecking=no', 
                f'andrc1@{ip}', 
                f'ls /home/andrc1/rep{i}_settings.json 2>/dev/null || echo "NOT_FOUND"'
            ], capture_output=True, text=True, timeout=3)
            
            if "NOT_FOUND" in result.stdout:
                missing_files.append(f"rep{i}_settings.json on {ip}")
        except:
            missing_files.append(f"rep{i}_settings.json on {ip} (connection failed)")
    
    if incorrect_files:
        logging.error(f"❌ INCORRECT NAMING FILES: {incorrect_files}")
    
    if missing_files:
        logging.error(f"❌ MISSING CORRECT FILES: {missing_files}")
    
    return len(incorrect_files) == 0 and len(missing_files) == 0
'''
    
    try:
        # Read current diagnostic
        with open(diagnostic_file, 'r') as f:
            content = f.read()
        
        # Add naming check if not present
        if "check_device_naming" not in content:
            # Insert before main function
            main_pos = content.find("def main():")
            if main_pos > 0:
                content = content[:main_pos] + naming_check_code + "\n" + content[main_pos:]
                
                # Add call to naming check in main
                content = content.replace(
                    "logging.info('🚀 Starting comprehensive diagnostic...')",
                    "logging.info('🚀 Starting comprehensive diagnostic...')\n    check_device_naming()"
                )
                
                with open(diagnostic_file, 'w') as f:
                    f.write(content)
                
                logging.info("✅ Updated diagnostic script with naming check")
            else:
                logging.error("❌ Could not find main function in diagnostic")
        else:
            logging.info("✅ Diagnostic already has naming check")
        
        return True
        
    except Exception as e:
        logging.error(f"❌ Failed to update diagnostic: {e}")
        return False

def main():
    """Apply final device naming fixes"""
    logging.info("🚀 DEVICE NAMING FINAL FIX")
    logging.info("=" * 50)
    
    steps_completed = 0
    total_steps = 5
    
    # Step 1: Clean incorrect files
    if clean_incorrect_settings_files() >= 0:  # Success if >= 0 files cleaned
        steps_completed += 1
    
    # Step 2: Create correct files
    if create_correct_settings_files() == 8:  # Must create all 8
        steps_completed += 1
    
    # Step 3: Add verification to transforms.py
    if add_settings_verification():
        steps_completed += 1
    
    # Step 4: Create monitor script
    if create_settings_monitor_script():
        steps_completed += 1
    
    # Step 5: Update diagnostic
    if update_diagnostic_script():
        steps_completed += 1
    
    logging.info("=" * 50)
    logging.info(f"📊 RESULT: {steps_completed}/{total_steps} steps completed")
    
    if steps_completed == total_steps:
        logging.info("🎉 DEVICE NAMING COMPLETELY FIXED!")
        logging.info("✅ All devices will use: rep1_settings.json, rep2_settings.json, etc.")
        logging.info("✅ Default settings: brightness=50, grayscale=false, rotation=0")
        logging.info("✅ GUI should now interact with correct settings files")
        return True
    else:
        logging.error("❌ SOME STEPS FAILED!")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
