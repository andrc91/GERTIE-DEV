#!/bin/bash
# Create a new checkpoint

if [ -z "$1" ]; then
    echo "Usage: ./checkpoint.sh <description>"
    echo "Example: ./checkpoint.sh after_port_fix"
    exit 1
fi

CHECKPOINT_NUM=$(ls .checkpoints/checkpoint_*.tar.gz 2>/dev/null | wc -l | xargs)
CHECKPOINT_NUM=$((CHECKPOINT_NUM + 1))
CHECKPOINT_NAME=$(printf "checkpoint_%03d_%s" $CHECKPOINT_NUM "$1")

echo "Creating checkpoint: $CHECKPOINT_NAME"
tar -czf ".checkpoints/${CHECKPOINT_NAME}.tar.gz" --exclude='.checkpoints' .
echo "$CHECKPOINT_NAME" > .checkpoints/current.txt
echo "✅ Checkpoint created"

# Log to upgrade_log.txt
echo "" >> upgrade_log.txt
echo "[$(date)] Checkpoint created: $CHECKPOINT_NAME" >> upgrade_log.txt
