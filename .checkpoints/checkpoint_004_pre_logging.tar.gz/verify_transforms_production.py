#!/usr/bin/env python3
"""
Production Transform Verification Script
Verifies that transforms are working correctly in the Raspberry Pi environment
"""

import sys
import os
import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_transform_system():
    """Test that the transform system is working in production environment"""
    print("🔍 PRODUCTION TRANSFORM VERIFICATION")
    print("===================================")
    
    try:
        # Test import
        print("1. Testing imports...")
        from shared.transforms import apply_unified_transforms, load_device_settings
        print("   ✅ Imports successful")
        
        # Test settings loading
        print("2. Testing settings loading...")
        devices_to_test = ['rep1', 'rep2', 'rep3', 'rep4', 'rep5', 'rep6', 'rep7', 'rep8']
        
        for device in devices_to_test:
            try:
                settings = load_device_settings(device)
                settings_file = f"/home/andrc1/{device}_settings.json"
                if os.path.exists(settings_file):
                    print(f"   ✅ {device}: Settings loaded (brightness={settings.get('brightness', 'unknown')})")
                else:
                    print(f"   ⚠️  {device}: Using defaults (file not found)")
            except Exception as e:
                print(f"   ❌ {device}: Failed to load settings - {e}")
        
        # Test basic transform
        print("3. Testing basic transforms...")
        test_image = np.zeros((100, 100, 3), dtype=np.uint8)
        test_image[10:30, 10:30, 0] = 255  # Red square
        
        result = apply_unified_transforms(test_image, 'rep1')
        if result.shape == test_image.shape:
            print("   ✅ Basic transform successful")
        else:
            print(f"   ❌ Shape mismatch: {test_image.shape} → {result.shape}")
            return False
        
        # Test flip transform
        print("4. Testing flip transform...")
        from shared import transforms
        original_load = transforms.load_device_settings
        
        # Create test settings with flip enabled
        test_settings = load_device_settings('rep1').copy()
        test_settings['flip_vertical'] = True
        transforms.load_device_settings = lambda device_name: test_settings
        
        try:
            flipped_result = apply_unified_transforms(test_image, 'flip_test')
            top_red = np.sum(flipped_result[:50, :, 0] > 200)
            bottom_red = np.sum(flipped_result[50:, :, 0] > 200)
            
            if bottom_red > top_red:
                print("   ✅ Vertical flip working correctly")
            else:
                print(f"   ❌ Vertical flip not working (top={top_red}, bottom={bottom_red})")
                return False
                
        finally:
            transforms.load_device_settings = original_load
        
        print("5. Testing video stream integration...")
        try:
            # Test that the video stream can use transforms
            from slave.video_stream import apply_frame_transform
            test_result = apply_frame_transform(test_image, "rep1")
            print("   ✅ Video stream transform integration working")
        except Exception as e:
            print(f"   ⚠️  Video stream integration: {e}")
        
        print("6. Testing still capture integration...")  
        try:
            # Test that still capture can use transforms
            from slave.still_capture import apply_all_transforms
            test_result = apply_all_transforms(test_image, "rep1")
            print("   ✅ Still capture transform integration working")
        except Exception as e:
            print(f"   ⚠️  Still capture integration: {e}")
        
        print("\n🎉 TRANSFORM VERIFICATION COMPLETE!")
        print("✅ All core transform functions are working correctly")
        return True
        
    except Exception as e:
        print(f"\n❌ TRANSFORM VERIFICATION FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_transform_system()
    sys.exit(0 if success else 1)
