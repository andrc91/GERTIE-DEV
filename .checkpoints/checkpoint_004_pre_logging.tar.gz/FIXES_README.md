# Camera System Fixes - Transfer Package

## Overview
This package contains fixes for the multi-camera system issues. Deploy to control1 (192.168.0.200) and all remote Pis.

## Critical Issues Fixed

### 1. Directory Creation (control1)
- **Problem**: GUI tried to save to `~/Desktop/captured_images/` (doesn't exist on Pi)
- **Fix**: Changed to `/home/andrc1/Desktop/<date>/rep<N>` with proper directory creation

### 2. Settings Persistence 
- **Problem**: Settings lost on restart, no sync between GUI and slaves
- **Fix**: Network-based settings broadcast + local persistence on each Pi

### 3. Remote Replica Command Handling
- **Problem**: Service files had wrong directory path
- **Fix**: Corrected service files + deployment script

### 4. Auto-Command Prevention
- **Problem**: GUI auto-sent commands on every setting change
- **Fix**: Added "Apply Settings" button, removed auto-apply

### 5. Preview/Still Mismatch
- **Problem**: Different transform pipelines for video vs still
- **Fix**: Unified transform pipeline, preview matches final image

### 6. Color Channel Fix (rep8)
- **Problem**: BGR/RGB swap on local camera
- **Fix**: Proper color space conversion for rep8

## Deployment Instructions

1. **Stop all services on all Pis:**
   ```bash
   sudo systemctl stop video_stream.service still_capture.service
   ```

2. **Copy this entire directory to each Pi:**
   - control1: `/home/andrc1/camera_system_integrated_final/`
   - rep1-rep7: `/home/andrc1/camera_system_integrated_final/`

3. **Run deployment script on each Pi:**
   ```bash
   cd /home/andrc1/camera_system_integrated_final
   chmod +x deploy_fixes.sh
   ./deploy_fixes.sh
   ```

4. **Start GUI on control1:**
   ```bash
   cd /home/andrc1/camera_system_integrated_final/master/camera_gui
   python3 main.py
   ```

## Files Modified
- `shared/config.py` - Fixed master IP handling
- `slave/still_capture.py` - Fixed directory paths + settings sync
- `slave/video_stream.py` - Fixed transforms + color handling
- `master/camera_gui/core/network_manager.py` - Fixed directory creation
- `master/camera_gui/menu/settings_menu.py` - Added apply button
- `*.service` - Fixed service file paths
- `deploy_fixes.sh` - New deployment automation script
