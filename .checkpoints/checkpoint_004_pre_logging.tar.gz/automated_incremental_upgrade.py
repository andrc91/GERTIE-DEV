#!/usr/bin/env python3
"""
GERTIE AUTOMATED INCREMENTAL UPGRADE SYSTEM
============================================
Preserves all knowledge while safely applying upgrades one at a time
With comprehensive logging for Claude continuity
"""

import os
import sys
import subprocess
import json
import shutil
import datetime
import time
import hashlib

class AutomatedUpgradeSystem:
    def __init__(self):
        self.base_dir = "/Users/andrew1/Desktop/camera_system_incremental"
        self.log_file = os.path.join(self.base_dir, "automated_upgrade_log.json")
        self.checkpoint_dir = os.path.join(self.base_dir, ".checkpoints")
        self.current_phase = 0
        self.upgrade_history = []
        self.load_state()
        
    def load_state(self):
        """Load previous state for continuity"""
        if os.path.exists(self.log_file):
            with open(self.log_file, 'r') as f:
                data = json.load(f)
                self.current_phase = data.get('current_phase', 0)
                self.upgrade_history = data.get('history', [])
                print(f"📚 Resuming from Phase {self.current_phase}")
        
    def save_state(self):
        """Save state for Claude's knowledge preservation"""
        state = {
            'current_phase': self.current_phase,
            'last_update': datetime.datetime.now().isoformat(),
            'history': self.upgrade_history,
            'system_status': self.get_system_status()
        }
        with open(self.log_file, 'w') as f:
            json.dump(state, f, indent=2)
            
    def log_action(self, phase, action, status, details=""):
        """Comprehensive logging for each action"""
        entry = {
            'phase': phase,
            'timestamp': datetime.datetime.now().isoformat(),
            'action': action,
            'status': status,
            'details': details,
            'files_modified': self.get_modified_files()
        }
        self.upgrade_history.append(entry)
        self.save_state()
        
        # Also append to text log for easy reading
        with open('automated_upgrade.log', 'a') as f:
            f.write(f"\n[{entry['timestamp']}] PHASE {phase}: {action}\n")
            f.write(f"  Status: {status}\n")
            if details:
                f.write(f"  Details: {details}\n")
                
    def get_system_status(self):
        """Get current system health"""
        status = {}
        
        # Check Python syntax
        try:
            subprocess.run(['python3', '-m', 'py_compile', 'slave/video_stream.py'], 
                         check=True, capture_output=True, text=True)
            status['video_stream_syntax'] = 'OK'
        except:
            status['video_stream_syntax'] = 'ERROR'
            
        # Check critical functions
        with open('slave/video_stream.py', 'r') as f:
            content = f.read()
            status['has_udp_handler'] = 'def handle_video_commands' in content
            status['duplicate_functions'] = content.count('def handle_video_commands') > 1
            
        # Check ports
        status['port_6000'] = '6000' in content
        
        return status
        
    def get_modified_files(self):
        """Track which files were modified"""
        # Simple implementation - in production would use git diff
        return []
        
    def create_checkpoint(self, name):
        """Create a checkpoint before changes"""
        checkpoint_name = f"checkpoint_{self.current_phase:03d}_{name}"
        checkpoint_file = os.path.join(self.checkpoint_dir, f"{checkpoint_name}.tar.gz")
        
        print(f"💾 Creating checkpoint: {checkpoint_name}")
        subprocess.run([
            'tar', '-czf', checkpoint_file,
            '--exclude=.checkpoints', '--exclude=*.pyc', '.'
        ], cwd=self.base_dir)
        
        self.log_action(self.current_phase, f"Created checkpoint: {name}", "SUCCESS", 
                       f"File: {checkpoint_file}")
        return checkpoint_name
        
    def run_tests(self):
        """Run comprehensive tests"""
        print("🧪 Running tests...")
        
        test_results = {
            'syntax': True,
            'functions': True,
            'ports': True,
            'imports': True
        }
        
        # Syntax test
        try:
            for file in ['slave/video_stream.py', 'slave/still_capture.py']:
                subprocess.run(['python3', '-m', 'py_compile', file], 
                             check=True, capture_output=True)
        except:
            test_results['syntax'] = False
            
        # Function test
        with open('slave/video_stream.py', 'r') as f:
            content = f.read()
            if content.count('def handle_video_commands') != 1:
                test_results['functions'] = False
                
        # Port test
        if '6000' not in open('slave/still_capture.py').read():
            test_results['ports'] = False
            
        # Import test (MacBook compatible)
        try:
            sys.path.insert(0, self.base_dir)
            # Don't actually import (would fail on Mac), just check syntax
            subprocess.run(['python3', '-c', 
                          'import ast; ast.parse(open("slave/video_stream.py").read())'],
                         check=True, capture_output=True)
        except:
            test_results['imports'] = False
        finally:
            sys.path.pop(0)
            
        # Log results
        passed = all(test_results.values())
        self.log_action(self.current_phase, "Run tests", 
                       "PASS" if passed else "FAIL", str(test_results))
        
        for test, result in test_results.items():
            print(f"  {'✅' if result else '❌'} {test}")
            
        return passed
    
    def phase_001_fix_duplicates(self):
        """Phase 001: Fix duplicate functions"""
        print("\n" + "="*60)
        print("PHASE 001: Fix Duplicate Functions")
        print("="*60)
        
        self.create_checkpoint("pre_duplicate_fix")
        
        try:
            # Check for duplicates
            with open('slave/video_stream.py', 'r') as f:
                lines = f.readlines()
                
            function_counts = {}
            for i, line in enumerate(lines):
                if line.strip().startswith('def '):
                    func_name = line.strip().split('(')[0].replace('def ', '')
                    if func_name not in function_counts:
                        function_counts[func_name] = []
                    function_counts[func_name].append(i)
                    
            duplicates_found = False
            for func_name, occurrences in function_counts.items():
                if len(occurrences) > 1:
                    duplicates_found = True
                    print(f"  ⚠️  Found duplicate: {func_name} at lines {occurrences}")
                    
                    # Comment out duplicates (keep first)
                    for line_num in occurrences[1:]:
                        # Find function end
                        end_line = line_num + 1
                        while end_line < len(lines):
                            if lines[end_line].strip() and not lines[end_line].startswith(' '):
                                break
                            end_line += 1
                            
                        # Comment out duplicate
                        for i in range(line_num, min(end_line, len(lines))):
                            if not lines[i].strip().startswith('#'):
                                lines[i] = '# DUPLICATE_REMOVED: ' + lines[i]
                                
            if duplicates_found:
                # Write fixed file
                with open('slave/video_stream.py', 'w') as f:
                    f.writelines(lines)
                    
                self.log_action(1, "Fixed duplicate functions", "SUCCESS", 
                              f"Found and commented {len([f for f in function_counts.values() if len(f) > 1])} duplicates")
                print("  ✅ Duplicates fixed")
            else:
                self.log_action(1, "No duplicates found", "SUCCESS")
                print("  ✅ No duplicates found")
                
            return self.run_tests()
            
        except Exception as e:
            self.log_action(1, "Fix duplicates failed", "ERROR", str(e))
            print(f"  ❌ Error: {e}")
            return False
            
    def phase_002_fix_ports(self):
        """Phase 002: Fix port configurations"""
        print("\n" + "="*60)
        print("PHASE 002: Fix Port Configurations")
        print("="*60)
        
        self.create_checkpoint("pre_port_fix")
        
        try:
            # Fix still_capture.py port
            with open('slave/still_capture.py', 'r') as f:
                content = f.read()
                
            if '5001' in content:
                content = content.replace('5001', '6000')
                with open('slave/still_capture.py', 'w') as f:
                    f.write(content)
                print("  ✅ Fixed still_capture.py port 5001 → 6000")
                self.log_action(2, "Fixed still_capture port", "SUCCESS")
            else:
                print("  ✅ Port already correct")
                self.log_action(2, "Port already correct", "SUCCESS")
                
            return self.run_tests()
            
        except Exception as e:
            self.log_action(2, "Fix ports failed", "ERROR", str(e))
            print(f"  ❌ Error: {e}")
            return False
            
    def phase_003_enable_autostart(self):
        """Phase 003: Enable AUTO_START_STREAMS"""
        print("\n" + "="*60)
        print("PHASE 003: Enable AUTO_START_STREAMS")
        print("="*60)
        
        self.create_checkpoint("pre_autostart")
        
        try:
            settings_file = 'master/camera_gui/config/settings.py'
            
            # Check if file exists
            if not os.path.exists(settings_file):
                # Create minimal settings file
                os.makedirs(os.path.dirname(settings_file), exist_ok=True)
                with open(settings_file, 'w') as f:
                    f.write("# Auto-generated settings\n")
                    f.write("AUTO_START_STREAMS = True\n")
                print("  ✅ Created settings with AUTO_START_STREAMS = True")
                self.log_action(3, "Created settings file", "SUCCESS")
            else:
                with open(settings_file, 'r') as f:
                    content = f.read()
                    
                if 'AUTO_START_STREAMS = False' in content:
                    content = content.replace('AUTO_START_STREAMS = False', 
                                            'AUTO_START_STREAMS = True')
                    with open(settings_file, 'w') as f:
                        f.write(content)
                    print("  ✅ Enabled AUTO_START_STREAMS")
                    self.log_action(3, "Enabled AUTO_START_STREAMS", "SUCCESS")
                elif 'AUTO_START_STREAMS' not in content:
                    content += "\n# Added by automated upgrade\n"
                    content += "AUTO_START_STREAMS = True\n"
                    with open(settings_file, 'w') as f:
                        f.write(content)
                    print("  ✅ Added AUTO_START_STREAMS = True")
                    self.log_action(3, "Added AUTO_START_STREAMS", "SUCCESS")
                else:
                    print("  ✅ AUTO_START_STREAMS already enabled")
                    self.log_action(3, "Already enabled", "SUCCESS")
                    
            return self.run_tests()
            
        except Exception as e:
            self.log_action(3, "Enable autostart failed", "ERROR", str(e))
            print(f"  ❌ Error: {e}")
            return False
            
    def phase_004_add_minimal_logging(self):
        """Phase 004: Add minimal debug logging"""
        print("\n" + "="*60)
        print("PHASE 004: Add Minimal Logging")
        print("="*60)
        
        self.create_checkpoint("pre_logging")
        
        try:
            for file_path in ['slave/video_stream.py', 'slave/still_capture.py']:
                with open(file_path, 'r') as f:
                    lines = f.readlines()
                    
                # Add logging import if not present
                has_logging = any('import logging' in line for line in lines)
                
                if not has_logging:
                    # Add at top after other imports
                    insert_pos = 0
                    for i, line in enumerate(lines):
                        if line.strip() and not line.startswith('#') and not line.startswith('import'):
                            insert_pos = i
                            break
                            
                    lines.insert(insert_pos, "import logging\n")
                    lines.insert(insert_pos + 1, "logging.basicConfig(level=logging.INFO, "
                               "format='%(asctime)s - %(name)s - %(message)s')\n")
                    lines.insert(insert_pos + 2, "\n")
                    
                    with open(file_path, 'w') as f:
                        f.writelines(lines)
                        
                    print(f"  ✅ Added logging to {os.path.basename(file_path)}")
                    self.log_action(4, f"Added logging to {file_path}", "SUCCESS")
                else:
                    print(f"  ✅ {os.path.basename(file_path)} already has logging")
                    
            return self.run_tests()
            
        except Exception as e:
            self.log_action(4, "Add logging failed", "ERROR", str(e))
            print(f"  ❌ Error: {e}")
            return False
            
    def generate_report(self):
        """Generate comprehensive report for Claude"""
        print("\n" + "="*60)
        print("GENERATING COMPREHENSIVE REPORT")
        print("="*60)
        
        report = {
            'timestamp': datetime.datetime.now().isoformat(),
            'phases_completed': self.current_phase,
            'system_status': self.get_system_status(),
            'upgrade_history': self.upgrade_history[-10:],  # Last 10 actions
            'files_modified': [],
            'next_steps': [],
            'confidence_score': 0
        }
        
        # Calculate confidence
        status = report['system_status']
        confidence = 100
        if not status.get('video_stream_syntax') == 'OK':
            confidence -= 30
        if status.get('duplicate_functions'):
            confidence -= 20
        if not status.get('has_udp_handler'):
            confidence -= 25
        if not status.get('port_6000'):
            confidence -= 15
            
        report['confidence_score'] = max(0, confidence)
        
        # Determine next steps
        if confidence >= 90:
            report['next_steps'].append("System stable - ready for feature additions")
        elif confidence >= 70:
            report['next_steps'].append("System functional - continue with stability improvements")
        else:
            report['next_steps'].append("Critical issues remain - fix before proceeding")
            
        # Save report
        with open('upgrade_status_report.json', 'w') as f:
            json.dump(report, f, indent=2)
            
        print(f"\n📊 System Confidence: {confidence}%")
        print(f"✅ Phases Completed: {self.current_phase}")
        print(f"📁 Report saved to: upgrade_status_report.json")
        
        return report
        
    def run_upgrade_sequence(self):
        """Run the complete upgrade sequence"""
        print("\n" + "🚀"*20)
        print(" GERTIE AUTOMATED INCREMENTAL UPGRADE SYSTEM")
        print("🚀"*20)
        
        phases = [
            (1, self.phase_001_fix_duplicates),
            (2, self.phase_002_fix_ports),
            (3, self.phase_003_enable_autostart),
            (4, self.phase_004_add_minimal_logging)
        ]
        
        for phase_num, phase_func in phases:
            if self.current_phase >= phase_num:
                print(f"\n⏭️  Skipping Phase {phase_num} (already completed)")
                continue
                
            self.current_phase = phase_num
            success = phase_func()
            
            if not success:
                print(f"\n❌ Phase {phase_num} failed - stopping upgrade sequence")
                print("Run './restore.sh' to rollback if needed")
                break
                
            print(f"\n✅ Phase {phase_num} completed successfully")
            time.sleep(1)  # Brief pause between phases
            
        # Generate final report
        report = self.generate_report()
        
        print("\n" + "="*60)
        print("UPGRADE SEQUENCE COMPLETE")
        print("="*60)
        
        return report

if __name__ == "__main__":
    os.chdir("/Users/andrew1/Desktop/camera_system_incremental")
    upgrader = AutomatedUpgradeSystem()
    report = upgrader.run_upgrade_sequence()
    
    # Exit with appropriate code
    sys.exit(0 if report['confidence_score'] >= 70 else 1)
