#!/bin/bash
# IMMEDIATE DIAGNOSIS: Check why rep1-7 still capture fails
# Run this on control1 to diagnose all slaves

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_check() { echo -e "${BLUE}🔍 $1${NC}"; }

echo -e "${BLUE}🚨 EMERGENCY DIAGNOSIS: Still Capture Failures${NC}"
echo -e "${BLUE}=============================================${NC}"
echo ""

failed_devices=()
working_devices=()

# Check each slave device
for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_check "DIAGNOSING rep$i ($SLAVE_IP)..."
    
    # Test connectivity
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable via ping"
        failed_devices+=("rep$i")
        continue
    fi
    
    echo "  📡 Network: OK"
    
    # Check if still capture service exists and is running
    if ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl is-active still_capture.service" 2>/dev/null | grep -q "active"; then
        echo "  🔧 Service: still_capture.service is ACTIVE"
        
        # Check recent device detection logs
        device_detection=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='10 minutes ago' | grep 'DEVICE DETECTION' | tail -1" 2>/dev/null)
        if [[ -n "$device_detection" ]]; then
            detected_device=$(echo "$device_detection" | grep -o "rep[0-8]" | tail -1)
            if [[ "$detected_device" == "rep$i" ]]; then
                echo "  🆔 Device Detection: ✅ CORRECT ($detected_device)"
                
                # Check port binding
                port_binding=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='10 minutes ago' | grep 'BOUND to port' | tail -1" 2>/dev/null)
                if echo "$port_binding" | grep -q "port 5001"; then
                    echo "  🔌 Port Binding: ✅ CORRECT (5001)"
                    
                    # Check if service is actually listening on port 5001
                    listening_check=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "netstat -ulnp | grep :5001" 2>/dev/null)
                    if [[ -n "$listening_check" ]]; then
                        echo "  👂 Port Listening: ✅ Service listening on port 5001"
                        
                        # Test if we can send a command to the service
                        echo "  🧪 Testing command reception..."
                        if timeout 5 bash -c "echo 'TEST_COMMAND' | nc -u $SLAVE_IP 5001" 2>/dev/null; then
                            echo "  📨 Command Test: ✅ Port accepts UDP commands"
                            working_devices+=("rep$i")
                        else
                            echo "  📨 Command Test: ❌ Port not accepting commands"
                            failed_devices+=("rep$i")
                        fi
                    else
                        echo "  👂 Port Listening: ❌ Service NOT listening on port 5001"
                        failed_devices+=("rep$i")
                    fi
                else
                    echo "  🔌 Port Binding: ❌ WRONG PORT or not found"
                    echo "    Port info: $port_binding"
                    failed_devices+=("rep$i")
                fi
            else
                echo "  🆔 Device Detection: ❌ WRONG ($detected_device instead of rep$i)"
                failed_devices+=("rep$i")
            fi
        else
            echo "  🆔 Device Detection: ❌ NO DETECTION LOGS FOUND"
            failed_devices+=("rep$i")
        fi
    else
        echo "  🔧 Service: ❌ still_capture.service NOT ACTIVE"
        
        # Check service status
        service_status=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "systemctl status still_capture.service --no-pager -l" 2>/dev/null | head -3)
        echo "    Service status: $service_status"
        failed_devices+=("rep$i")
    fi
    
    # Show current hostname and IP for debugging
    hostname_info=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "hostname" 2>/dev/null)
    ip_info=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "ip addr show | grep 'inet 192.168.0.' | head -1" 2>/dev/null | awk '{print $2}')
    echo "  📝 Debug Info: hostname=$hostname_info, detected_ip=$ip_info"
    
    echo ""
done

# Check local camera (rep8) for comparison
log_check "CHECKING LOCAL CAMERA (rep8) for comparison..."
if systemctl is-active local_camera_slave.service >/dev/null 2>&1; then
    echo "  🔧 Service: local_camera_slave.service is ACTIVE ✅"
    log_success "rep8: Working (for comparison)"
else
    echo "  🔧 Service: local_camera_slave.service NOT ACTIVE ❌"
fi

echo ""
echo "📊 DIAGNOSIS SUMMARY"
echo "==================="
echo -e "${GREEN}Working devices: ${#working_devices[@]}/7${NC}"
if [[ ${#working_devices[@]} -gt 0 ]]; then
    echo -e "${GREEN}  Working: ${working_devices[*]}${NC}"
fi

echo -e "${RED}Failed devices: ${#failed_devices[@]}/7${NC}"
if [[ ${#failed_devices[@]} -gt 0 ]]; then
    echo -e "${RED}  Failed: ${failed_devices[*]}${NC}"
fi

echo ""
echo "🔧 RECOMMENDED ACTIONS"
echo "====================="

if [[ ${#failed_devices[@]} -eq 7 ]]; then
    log_error "ALL DEVICES FAILED - Complete deployment issue"
    echo -e "${YELLOW}Actions:${NC}"
    echo "  1. Re-run deployment: ./sync_to_slaves.sh"
    echo "  2. Check if files were actually copied to slaves"
    echo "  3. Verify systemd services are installed correctly"
elif [[ ${#failed_devices[@]} -gt 0 ]]; then
    log_error "Some devices failed - Mixed deployment"
    echo -e "${YELLOW}For failed devices, try:${NC}"
    for device in "${failed_devices[@]}"; do
        device_num=${device#rep}
        device_ip="192.168.0.20$device_num"
        echo "  $device ($device_ip):"
        echo "    - ssh andrc1@$device_ip 'sudo systemctl restart still_capture.service'"
        echo "    - ssh andrc1@$device_ip 'journalctl -u still_capture.service -f'"
    done
else
    log_success "All devices appear to be working!"
    echo "If GUI still capture fails, the issue is likely in the GUI communication."
fi

echo ""
echo "🧪 MANUAL TEST COMMANDS"
echo "======================="
echo "Test individual device still capture:"
for i in {1..7}; do
    echo "  rep$i: echo 'CAPTURE_STILL' | nc -u 192.168.0.20$i 5001"
done

echo ""
echo "📋 DEBUG LOGS"
echo "============="
echo "Check service logs:"
for i in {1..7}; do
    echo "  rep$i: ssh andrc1@192.168.0.20$i 'journalctl -u still_capture.service --since=\"5 minutes ago\"'"
done
