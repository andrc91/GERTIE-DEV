#!/bin/bash
# Restore from checkpoint

if [ -z "$1" ]; then
    echo "Available checkpoints:"
    ls -la .checkpoints/*.tar.gz
    echo ""
    echo "Usage: ./restore.sh <checkpoint_name>"
    echo "Example: ./restore.sh checkpoint_001_baseline"
    exit 1
fi

CHECKPOINT_FILE=".checkpoints/${1}.tar.gz"

if [ ! -f "$CHECKPOINT_FILE" ]; then
    echo "❌ Checkpoint not found: $CHECKPOINT_FILE"
    exit 1
fi

echo "⚠️  This will restore from: $1"
echo "   All current changes will be lost!"
echo ""
echo -n "Are you sure? (yes/no): "
read confirm

if [ "$confirm" != "yes" ]; then
    echo "Restore cancelled"
    exit 0
fi

echo "Restoring from $1..."
tar -xzf "$CHECKPOINT_FILE"
echo "$1" > .checkpoints/current.txt
echo "✅ Restored successfully"

# Log to upgrade_log.txt
echo "" >> upgrade_log.txt
echo "[$(date)] RESTORED from: $1" >> upgrade_log.txt
