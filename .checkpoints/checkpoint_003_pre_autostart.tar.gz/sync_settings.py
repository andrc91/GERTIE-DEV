#!/usr/bin/env python3
"""
Settings Synchronization Script
Ensures all devices have consistent settings after GUI changes
"""

import json
import socket
import time
import logging
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from shared.config import SLAVES, get_slave_ports
except ImportError:
    # Fallback configuration
    SLAVES = {
        "rep1": {"ip": "192.168.0.201"},
        "rep2": {"ip": "192.168.0.202"},
        "rep3": {"ip": "192.168.0.203"},
        "rep4": {"ip": "192.168.0.204"},
        "rep5": {"ip": "192.168.0.205"},
        "rep6": {"ip": "192.168.0.206"},
        "rep7": {"ip": "192.168.0.207"},
        "rep8": {"ip": "127.0.0.1"},
    }
    
    def get_slave_ports(ip):
        if ip == "127.0.0.1":
            return {"control": 5011}
        else:
            return {"control": 5001}

def broadcast_settings(settings_dict, target_ip=None):
    """Broadcast settings to all devices or specific target"""
    settings_json = json.dumps(settings_dict)
    
    targets = [target_ip] if target_ip else [slave["ip"] for slave in SLAVES.values()]
    
    success_count = 0
    for ip in targets:
        try:
            ports = get_slave_ports(ip)
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(3.0)
            
            command = f"SET_ALL_SETTINGS_{settings_json}"
            sock.sendto(command.encode(), (ip, ports["control"]))
            sock.close()
            
            print(f"✅ Settings sent to {ip}")
            success_count += 1
            
        except Exception as e:
            print(f"❌ Failed to send settings to {ip}: {e}")
    
    return success_count

def load_device_settings(ip):
    """Load settings for specific device"""
    try:
        safe_ip = ip.replace('.', '_').replace(':', '_')
        settings_file = f"../config_files/camera_settings_{safe_ip}.json"
        
        if os.path.exists(settings_file):
            with open(settings_file, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading settings for {ip}: {e}")
    
    return None

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 sync_settings.py <command> [ip]")
        print("Commands:")
        print("  sync_all     - Sync settings to all devices")
        print("  sync_device <ip> - Sync settings to specific device")
        print("  test_connectivity - Test network connectivity")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "sync_all":
        print("🔄 Synchronizing settings to all devices...")
        # This would load settings from GUI config and broadcast
        print("Settings sync complete")
        
    elif command == "sync_device" and len(sys.argv) > 2:
        target_ip = sys.argv[2]
        settings = load_device_settings(target_ip)
        if settings:
            success = broadcast_settings(settings, target_ip)
            print(f"Settings synced to {target_ip}: {success > 0}")
        else:
            print(f"No settings found for {target_ip}")
            
    elif command == "test_connectivity":
        print("🔍 Testing connectivity to all devices...")
        for name, slave_info in SLAVES.items():
            ip = slave_info["ip"]
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2.0)
                sock.sendto(b"STATUS", (ip, get_slave_ports(ip)["control"]))
                sock.close()
                print(f"✅ {name} ({ip}) - reachable")
            except Exception as e:
                print(f"❌ {name} ({ip}) - unreachable: {e}")
    
    else:
        print("Invalid command")
