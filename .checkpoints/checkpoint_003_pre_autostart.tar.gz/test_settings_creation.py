#!/usr/bin/env python3
"""
Settings File Test - Verify settings creation works on each device
Run this on any slave to test settings file creation
"""

import sys
import os
import json
import socket
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')

# Add project root to path
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

def test_settings_creation():
    """Test that settings files can be created and loaded"""
    logging.info("🧪 Testing settings file creation...")
    
    # Get device name
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        device_name = f"rep{local_ip.split('.')[-1]}"
        logging.info(f"Device name determined: {device_name}")
    except Exception as e:
        logging.error(f"Failed to determine device name: {e}")
        device_name = "rep_test"
    
    # Test transforms import
    try:
        from shared.transforms import load_device_settings, save_device_settings, DEFAULT_SETTINGS
        logging.info("✅ Successfully imported transforms module")
    except Exception as e:
        logging.error(f"❌ Failed to import transforms: {e}")
        return False
    
    # Test loading settings (should create file if doesn't exist)
    try:
        settings = load_device_settings(device_name)
        logging.info(f"✅ Loaded settings: {len(settings)} keys")
    except Exception as e:
        logging.error(f"❌ Failed to load settings: {e}")
        return False
    
    # Verify settings file exists
    settings_file = f"/home/andrc1/{device_name}_settings.json"
    if os.path.exists(settings_file):
        logging.info(f"✅ Settings file exists: {settings_file}")
        
        # Verify file contents
        try:
            with open(settings_file, 'r') as f:
                file_contents = json.load(f)
            logging.info(f"✅ File contains {len(file_contents)} settings")
            
            # Check a few key settings
            required_keys = ['brightness', 'contrast', 'grayscale', 'rotation']
            missing_keys = [key for key in required_keys if key not in file_contents]
            
            if missing_keys:
                logging.error(f"❌ Missing required keys: {missing_keys}")
                return False
            else:
                logging.info(f"✅ All required keys present")
                
        except Exception as e:
            logging.error(f"❌ Failed to read settings file: {e}")
            return False
    else:
        logging.error(f"❌ Settings file not created: {settings_file}")
        return False
    
    # Test modifying and saving settings
    try:
        test_settings = settings.copy()
        test_settings['brightness'] = 99  # Test value
        test_settings['grayscale'] = True
        
        if save_device_settings(device_name, test_settings):
            logging.info("✅ Successfully saved modified settings")
            
            # Reload and verify
            reloaded = load_device_settings(device_name)
            if reloaded['brightness'] == 99 and reloaded['grayscale'] == True:
                logging.info("✅ Settings modification verified")
            else:
                logging.error(f"❌ Settings not properly saved/loaded")
                return False
        else:
            logging.error("❌ Failed to save settings")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to test settings modification: {e}")
        return False
    
    logging.info("🎉 All settings tests passed!")
    return True

def main():
    """Main test function"""
    logging.info("🚀 Starting settings file test")
    
    # Show current working directory and system info
    logging.info(f"Working directory: {os.getcwd()}")
    logging.info(f"Script location: {os.path.dirname(os.path.abspath(__file__))}")
    logging.info(f"Python path: {sys.path[:3]}...")  # Show first 3 entries
    
    # Check if /home/andrc1 directory exists
    home_dir = "/home/andrc1"
    
    # Handle different operating systems
    import platform
    if platform.system() == "Darwin":  # macOS
        logging.info("Running on macOS - skipping /home/andrc1 directory test")
        logging.info("✅ This test will work properly on the Pi")
        return True  # Success on macOS (can't test real directories)
    
    if os.path.exists(home_dir):
        logging.info(f"✅ Home directory exists: {home_dir}")
        # Check if it's writable
        if os.access(home_dir, os.W_OK):
            logging.info(f"✅ Home directory is writable")
        else:
            logging.error(f"❌ Home directory is not writable")
            return False
    else:
        logging.error(f"❌ Home directory does not exist: {home_dir}")
        # Try to create it
        try:
            os.makedirs(home_dir, exist_ok=True)
            logging.info(f"✅ Created home directory: {home_dir}")
        except Exception as e:
            logging.error(f"❌ Failed to create home directory: {e}")
            return False
    
    # Run the actual test
    if test_settings_creation():
        logging.info("🎉 ALL TESTS PASSED - Settings system working correctly")
        return True
    else:
        logging.error("❌ TESTS FAILED - Settings system has issues")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
