#!/bin/bash
# MANUAL TEST: Test still capture on each device directly
# Run this on control1 to test UDP commands to each slave

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }
log_test() { echo -e "${BLUE}🧪 $1${NC}"; }

echo -e "${BLUE}🧪 MANUAL STILL CAPTURE TEST${NC}"
echo -e "${BLUE}============================${NC}"
echo ""

test_results=()

for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_test "Testing rep$i ($SLAVE_IP) still capture..."
    
    # Test connectivity first
    if ! ping -c 1 -W 2 $SLAVE_IP >/dev/null 2>&1; then
        log_error "rep$i: Not reachable"
        test_results+=("rep$i:UNREACHABLE")
        continue
    fi
    
    # Check if port 5001 is listening (FIXED: correct port)
    if timeout 3 bash -c "echo '' | nc -u $SLAVE_IP 5001" 2>/dev/null; then
        echo "  📡 Port 5001: Accepting connections"
        
        # Send actual still capture command
        log_test "Sending CAPTURE_STILL command to rep$i on port 5001..."
        if timeout 10 bash -c "echo 'CAPTURE_STILL' | nc -u $SLAVE_IP 5001" 2>/dev/null; then
            echo "  📨 Command sent successfully"
            
            # Wait a moment then check logs for capture activity
            sleep 3
            capture_activity=$(ssh -o StrictHostKeyChecking=no "andrc1@$SLAVE_IP" "journalctl -u still_capture.service --since='10 seconds ago' | grep -E '(CAPTURE_STILL|captured|sending|received)'" 2>/dev/null)
            
            if [[ -n "$capture_activity" ]]; then
                log_success "rep$i: ✅ CAPTURE ACTIVITY DETECTED"
                echo "    Activity: $(echo "$capture_activity" | tail -1)"
                test_results+=("rep$i:SUCCESS")
            else
                log_error "rep$i: ❌ NO CAPTURE ACTIVITY in logs"
                test_results+=("rep$i:NO_ACTIVITY")
            fi
        else
            log_error "rep$i: ❌ Command send failed"
            test_results+=("rep$i:COMMAND_FAILED")
        fi
    else
        log_error "rep$i: ❌ Port 5001 not accepting connections"
        test_results+=("rep$i:PORT_CLOSED")
    fi
    
    echo ""
done

echo "📊 TEST RESULTS SUMMARY"
echo "======================="

success_count=0
for result in "${test_results[@]}"; do
    device=$(echo "$result" | cut -d: -f1)
    status=$(echo "$result" | cut -d: -f2)
    
    case $status in
        "SUCCESS")
            log_success "$device: Working correctly ✅"
            success_count=$((success_count + 1))
            ;;
        "UNREACHABLE")
            log_error "$device: Network unreachable ❌"
            ;;
        "PORT_CLOSED")
            log_error "$device: Service not listening on port 6000 ❌"
            ;;
        "COMMAND_FAILED")
            log_error "$device: Command send failed ❌"
            ;;
        "NO_ACTIVITY")
            log_error "$device: No capture activity detected ❌"
            ;;
    esac
done

echo ""
echo "📈 OVERALL RESULTS"
echo "=================="
log_success "Working devices: $success_count/7"

if [[ $success_count -eq 7 ]]; then
    log_success "🎉 ALL DEVICES RESPONDING TO STILL CAPTURE COMMANDS!"
    echo -e "${GREEN}Issue might be in GUI communication with devices${NC}"
elif [[ $success_count -gt 0 ]]; then
    log_success "Some devices working"
    echo -e "${YELLOW}$((7 - success_count)) devices need fixing${NC}"
else
    log_error "NO DEVICES RESPONDING"
    echo -e "${RED}Services not running or major configuration issue${NC}"
fi

echo ""
echo "🔧 NEXT STEPS"
echo "============="
if [[ $success_count -eq 7 ]]; then
    echo "✅ All devices respond to manual commands"
    echo "🔍 Check GUI configuration:"
    echo "   - Verify GUI is sending to correct IPs and ports"
    echo "   - Check GUI logs for errors"
    echo "   - Ensure GUI uses port 5001 for rep1-7 (FIXED)"
elif [[ $success_count -gt 0 ]]; then
    echo "🔧 Fix non-responding devices:"
    echo "   - Run: ./quick_fix_capture.sh"
    echo "   - Check service status on failed devices"
else
    echo "🚨 Major issue - services not running:"
    echo "   - Run: ./sync_to_slaves.sh (re-deploy)"
    echo "   - Check service installation"
    echo "   - Verify device detection is working"
fi

echo ""
echo "📋 DEBUG SPECIFIC DEVICE (example rep1):"
echo "ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'"
