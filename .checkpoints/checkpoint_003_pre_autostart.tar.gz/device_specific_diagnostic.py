#!/usr/bin/env python3
"""
Device-Specific Diagnostic Script
Investigates issues with rep1, rep4 (white images) and rep8 (low-res)
"""

import os
import logging
import subprocess
import json
import time
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def diagnose_white_image_devices():
    """Diagnose rep1 and rep4 white image issues"""
    logging.info("🔍 DIAGNOSING WHITE IMAGE DEVICES (rep1, rep4)")
    logging.info("="*60)
    
    white_devices = ["192.168.0.201", "192.168.0.204"]  # rep1, rep4
    
    for device_ip in white_devices:
        device_name = f"rep{device_ip.split('.')[-1][-1]}"
        logging.info(f"\n📱 Checking {device_name} ({device_ip})...")
        
        # Test connectivity
        if not test_ping(device_ip):
            logging.error(f"❌ {device_name}: Not reachable")
            continue
            
        # Check camera hardware
        check_camera_hardware(device_ip, device_name)
        
        # Test with different exposure settings
        test_exposure_settings(device_ip, device_name)

def diagnose_local_camera():
    """Diagnose rep8 (local camera) low resolution issue"""
    logging.info("\n🔍 DIAGNOSING LOCAL CAMERA (rep8)")
    logging.info("="*40)
    
    # Check local camera service
    try:
        result = subprocess.run(["systemctl", "is-active", "local_camera_slave.service"], 
                              capture_output=True, text=True)
        logging.info(f"📊 Local camera service status: {result.stdout.strip()}")
        
        # Check local camera configuration
        local_script = "/Users/andrew1/Desktop/camera_system_integrated_final/local_camera_slave.py"
        if os.path.exists(local_script):
            logging.info("✅ Local camera script exists")
            # Check if it uses different logic
            with open(local_script, 'r') as f:
                content = f.read()
                if "capture_with_processing" in content:
                    logging.info("📝 Local camera uses processing path")
                if "capture_with_libcamera" in content:
                    logging.info("📝 Local camera uses libcamera path")
        else:
            logging.error("❌ Local camera script not found")
            
    except Exception as e:
        logging.error(f"❌ Error checking local camera: {e}")

def test_ping(ip):
    """Test if device is reachable"""
    try:
        result = subprocess.run(["ping", "-c", "1", "-W", "2", ip], 
                              capture_output=True, text=True)
        return result.returncode == 0
    except:
        return False

def check_camera_hardware(device_ip, device_name):
    """Check camera hardware status on device"""
    try:
        # Check if camera is detected
        cmd = ["ssh", "-o", "StrictHostKeyChecking=no", f"andrc1@{device_ip}", 
               "libcamera-hello --list-cameras"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            logging.info(f"✅ {device_name}: Camera hardware detected")
            if "Available cameras" in result.stdout:
                logging.info(f"📸 {device_name}: {result.stdout.strip()}")
        else:
            logging.error(f"❌ {device_name}: Camera hardware issue")
            logging.error(f"   Error: {result.stderr}")
            
    except Exception as e:
        logging.error(f"❌ {device_name}: Cannot check camera hardware: {e}")

def test_exposure_settings(device_ip, device_name):
    """Test different exposure settings to fix white images"""
    logging.info(f"🧪 Testing exposure settings for {device_name}...")
    
    # Test with different brightness and exposure settings
    test_settings = [
        {"brightness": -30, "iso": 100, "shutter_speed": 5000},   # Very dark
        {"brightness": -20, "iso": 100, "shutter_speed": 10000},  # Dark
        {"brightness": -10, "iso": 100, "shutter_speed": 1000},   # Slightly dark
        {"brightness": 0, "iso": 50, "shutter_speed": 1000},      # Low ISO
    ]
    
    for i, settings in enumerate(test_settings):
        logging.info(f"   Test {i+1}: brightness={settings['brightness']}, ISO={settings['iso']}, shutter={settings['shutter_speed']}")
        
        try:
            # Create test capture with these settings
            test_cmd = f"""
            libcamera-still --nopreview -o /tmp/test_{device_name}_{i+1}.jpg --timeout 1000 \
            --brightness {settings['brightness']/50.0} \
            --gain {settings['iso']/100.0} \
            --shutter {settings['shutter_speed']}
            """
            
            ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no", f"andrc1@{device_ip}", test_cmd]
            result = subprocess.run(ssh_cmd, capture_output=True, text=True, timeout=15)
            
            if result.returncode == 0:
                # Check file size
                size_cmd = ["ssh", "-o", "StrictHostKeyChecking=no", f"andrc1@{device_ip}", 
                           f"ls -la /tmp/test_{device_name}_{i+1}.jpg"]
                size_result = subprocess.run(size_cmd, capture_output=True, text=True)
                
                if size_result.returncode == 0:
                    file_info = size_result.stdout.strip()
                    logging.info(f"   ✅ Test {i+1} created: {file_info}")
                    
                    # Extract file size
                    parts = file_info.split()
                    if len(parts) >= 5:
                        file_size = int(parts[4])
                        if file_size > 500000:  # > 500KB suggests good capture
                            logging.info(f"   🎯 Test {i+1}: GOOD size ({file_size} bytes) - may fix white images!")
                        else:
                            logging.warning(f"   ⚠️  Test {i+1}: Small size ({file_size} bytes)")
                else:
                    logging.error(f"   ❌ Test {i+1}: Cannot check file size")
            else:
                logging.error(f"   ❌ Test {i+1}: Capture failed")
                
        except Exception as e:
            logging.error(f"   ❌ Test {i+1}: Error: {e}")

def create_device_fixes():
    """Create device-specific fixes based on diagnostic results"""
    logging.info("\n🔧 CREATING DEVICE-SPECIFIC FIXES")
    logging.info("="*40)
    
    # For white image devices (rep1, rep4), create exposure fix
    white_image_fix = {
        "brightness": -20,  # Much darker
        "iso": 100,
        "shutter_speed": 5000,  # Faster shutter
        "contrast": 50,
        "saturation": 50,
        "white_balance": "auto",
        "jpeg_quality": 95,
        "fps": 30,
        "resolution": "4608x2592",
        "crop_enabled": False,
        "crop_x": 0,
        "crop_y": 0,
        "crop_width": 4608,
        "crop_height": 2592,
        "flip_horizontal": False,
        "flip_vertical": False,
        "grayscale": False,
        "rotation": 0
    }
    
    # Save special settings for rep1 and rep4
    for rep in ["rep1", "rep4"]:
        settings_file = f"/Users/andrew1/Desktop/camera_system_integrated_final/{rep}_settings.json"
        with open(settings_file, 'w') as f:
            json.dump(white_image_fix, f, indent=2)
        logging.info(f"✅ Created exposure fix settings for {rep}")
    
    logging.info("💡 Fixes created! Run sync_to_slaves.sh to deploy.")

def main():
    """Main diagnostic function"""
    logging.info("🚨 DEVICE-SPECIFIC DIAGNOSTIC STARTING")
    logging.info("Investigating: rep1+rep4 (white images), rep8 (low-res)")
    logging.info("="*60)
    
    # Diagnose specific issues
    diagnose_white_image_devices()
    diagnose_local_camera()
    
    # Create fixes
    create_device_fixes()
    
    logging.info("\n✅ DIAGNOSTIC COMPLETE")
    logging.info("Next step: Run sync_to_slaves.sh to deploy device-specific fixes")

if __name__ == "__main__":
    main()
