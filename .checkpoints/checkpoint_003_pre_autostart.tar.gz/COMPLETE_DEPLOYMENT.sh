#!/bin/bash
# COMPLETE DEPLOYMENT GUIDE - Step by step instructions
# Run this on control1 to deploy the offline fixes

echo "🚀 COMPLETE OFFLINE DEVICE DETECTION FIX"
echo "========================================"
echo ""
echo "This will deploy the complete solution that fixes:"
echo "✅ Still capture failures on rep1-7"
echo "✅ Device detection issues (rep1 showing as rep8)"
echo "✅ ROOT permission warnings"
echo "✅ External dependency issues (netifaces)"
echo "✅ Port binding problems"
echo ""

read -p "Press ENTER to continue with deployment..."

echo ""
echo "🔍 STEP 1: Checking current system..."

# Check if we're on control1
if [[ $(hostname) != *"control"* ]] && [[ $(hostname) != *"rep8"* ]]; then
    echo "❌ This script should be run on control1 (master Pi)"
    echo "Current hostname: $(hostname)"
    exit 1
fi

echo "✅ Running on master/control1"

# Check if we have the offline files
if [[ ! -f "slave/still_capture_offline.py" ]]; then
    echo "❌ Offline files not found. Make sure you copied the complete directory."
    exit 1
fi

echo "✅ Offline files found"

# Check connectivity to slaves
echo ""
echo "🔍 STEP 2: Checking slave connectivity..."
reachable_count=0
for i in {1..7}; do
    if ping -c 1 -W 2 "192.168.0.20$i" >/dev/null 2>&1; then
        echo "✅ rep$i (192.168.0.20$i) - reachable"
        reachable_count=$((reachable_count + 1))
    else
        echo "❌ rep$i (192.168.0.20$i) - not reachable"
    fi
done

echo ""
echo "📊 $reachable_count/7 slaves reachable"

if [[ $reachable_count -eq 0 ]]; then
    echo "❌ No slaves reachable. Check network connectivity."
    exit 1
fi

echo ""
read -p "Continue with deployment to $reachable_count slaves? (y/N): " confirm
if [[ $confirm != "y" ]] && [[ $confirm != "Y" ]]; then
    echo "Deployment cancelled."
    exit 0
fi

echo ""
echo "🚀 STEP 3: Deploying offline fixes..."
./deploy_offline_fix.sh

echo ""
echo "🔍 STEP 4: Verifying deployment..."
sleep 3
./verify_offline_detection.sh

echo ""
echo "🎉 DEPLOYMENT COMPLETE!"
echo ""
echo "📋 NEXT STEPS:"
echo "1. Test still capture through GUI on each rep"
echo "2. Verify video streams are working"
echo "3. Check that transforms (flip/rotate) work correctly"
echo ""
echo "🔧 IF ISSUES PERSIST:"
echo "- Check individual device logs:"
echo "  ssh andrc1@192.168.0.201 'journalctl -u still_capture_offline.service -f'"
echo ""
echo "- Restart specific device services:"
echo "  ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture_offline.service'"
echo ""
echo "- Re-run verification:"
echo "  ./verify_offline_detection.sh"
echo ""
echo "✅ The offline solution is now deployed and should work without internet!"
