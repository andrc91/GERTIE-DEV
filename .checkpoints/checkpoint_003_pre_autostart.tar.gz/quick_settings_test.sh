#!/bin/bash
"""
Quick Settings Test - Test all devices from control1
Run this after deploying fixes to verify settings files are created
"""

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'  
NC='\033[0m'

log_info() { echo -e "${YELLOW}🔍 $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }

log_info "🚀 Testing settings file creation on all devices..."

# Test local rep8 first
log_info "Testing rep8 (local)..."
if python3 test_settings_creation.py; then
    log_success "rep8: Settings test passed"
else
    log_error "rep8: Settings test failed"
fi

# Test remote devices rep1-rep7
for i in {1..7}; do
    SLAVE_IP="192.168.0.20$i"
    log_info "Testing rep$i ($SLAVE_IP)..."
    
    if ssh "andrc1@$SLAVE_IP" "cd /home/andrc1/camera_system_integrated_final && python3 test_settings_creation.py" 2>/dev/null; then
        log_success "rep$i: Settings test passed"
        
        # Check if settings file actually exists
        if ssh "andrc1@$SLAVE_IP" "test -f /home/andrc1/rep$i_settings.json" 2>/dev/null; then
            log_success "rep$i: Settings file exists on device"
        else
            log_error "rep$i: Settings file missing on device"
        fi
    else
        log_error "rep$i: Settings test failed or device unreachable"
    fi
done

log_info "🧪 Testing a quick settings change..."
# Test settings change on rep1
echo 'SET_ALL_SETTINGS_{"brightness":88,"grayscale":true}' | nc -u 192.168.0.201 5001 2>/dev/null || true
sleep 3

# Check if settings were applied
if ssh "andrc1@192.168.0.201" "grep '\"brightness\": 88' /home/andrc1/rep1_settings.json" >/dev/null 2>&1; then
    log_success "rep1: Settings change verified (brightness=88)"
else
    log_error "rep1: Settings change not applied"
fi

log_info "✨ Settings test complete! Now run full diagnostic:"
log_info "   python3 master_diagnostic_comprehensive.py"
