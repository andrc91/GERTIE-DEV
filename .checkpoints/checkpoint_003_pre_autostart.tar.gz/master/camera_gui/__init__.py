"""
Multi-Camera GUI - Modular Architecture
"""

__version__ = "2.0.0"
__author__ = "Camera System Team"
