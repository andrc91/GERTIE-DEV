#!/bin/bash
# Quick diagnostic script to verify fixes are working
# Run on each Pi after deployment

echo "🔍 CAMERA SYSTEM POST-FIX DIAGNOSTICS"
echo "====================================="

HOSTNAME=$(hostname)
IP=$(hostname -I | awk '{print $1}')
echo "Testing: $HOSTNAME ($IP)"
echo ""

echo "1. DIRECTORY STRUCTURE"
echo "====================="
[ -d "/home/andrc1/Desktop" ] && echo "✅ Desktop directory exists" || echo "❌ Desktop directory missing"
[ -d "/home/andrc1/Desktop/captured_images" ] && echo "✅ Captured images base directory exists" || echo "❌ Captured images base directory missing"
[ -d "/home/andrc1/camera_system_integrated_final/config_files" ] && echo "✅ Config files directory exists" || echo "❌ Config files directory missing"

TODAY=$(date +%Y-%m-%d)
echo "📁 Today's directories (captured_images/$TODAY/):"
for rep in rep1 rep2 rep3 rep4 rep5 rep6 rep7 rep8; do
    [ -d "/home/andrc1/Desktop/captured_images/$TODAY/$rep" ] && echo "   ✅ $rep" || echo "   ❌ $rep missing"
done
echo ""

echo "2. SERVICE STATUS"
echo "================"
echo "📊 Video Stream Service:"
systemctl is-active video_stream.service && echo "   ✅ Active" || echo "   ❌ Inactive"

echo "📊 Still Capture Service:"
systemctl is-active still_capture.service && echo "   ✅ Active" || echo "   ❌ Inactive"
echo ""

echo "3. NETWORK PORTS"
echo "================"
echo "🌐 Required ports should be listening:"
netstat -tuln | grep ':5001' && echo "   ✅ Control port 5001" || echo "   ❌ Control port 5001 not listening"
netstat -tuln | grep ':5002' && echo "   ✅ Video port 5002" || echo "   ❌ Video port 5002 not listening"  
netstat -tuln | grep ':5003' && echo "   ✅ Heartbeat port 5003" || echo "   ❌ Heartbeat port 5003 not listening"
netstat -tuln | grep ':5004' && echo "   ✅ Video control port 5004" || echo "   ❌ Video control port 5004 not listening"
netstat -tuln | grep ':6000' && echo "   ✅ Still port 6000" || echo "   ❌ Still port 6000 not listening"
echo ""

echo "4. PROCESS CHECK"
echo "==============="
echo "🔍 Python processes:"
ps aux | grep python | grep -E '(video_stream|still_capture)' | grep -v grep
echo ""

echo "5. CAMERA HARDWARE"
echo "=================="
[ -e "/dev/video0" ] && echo "✅ Camera device exists: /dev/video0" || echo "❌ No camera device found"

# Test camera permissions
if [ -e "/dev/video0" ]; then
    if [ -r "/dev/video0" ] && [ -w "/dev/video0" ]; then
        echo "✅ Camera permissions OK"
    else
        echo "❌ Camera permission issue"
        ls -la /dev/video0
    fi
fi
echo ""

echo "6. USER PERMISSIONS"
echo "=================="
groups andrc1 | grep video && echo "✅ User in video group" || echo "❌ User NOT in video group (reboot needed)"
echo ""

echo "7. CONFIGURATION FILES"
echo "======================"
[ -f "/home/andrc1/camera_system_integrated_final/config_files/device_names.json" ] && echo "✅ Device names config exists" || echo "❌ Device names config missing"

# Check if settings files exist
echo "📄 Settings files:"
ls -la /home/andrc1/camera_system_integrated_final/config_files/*.json 2>/dev/null || echo "   No settings files found (normal on first run)"
echo ""

echo "SUMMARY"
echo "======="
echo "If all items show ✅, the system should work correctly."
echo "If any show ❌, address those issues first."
echo ""
echo "To test manually:"
echo "1. Send test command: echo 'STATUS' | nc -u $IP 5001"
echo "2. Check recent logs: sudo journalctl -u video_stream.service -n 20"
echo "3. Start GUI on control1 if this is the master device"
