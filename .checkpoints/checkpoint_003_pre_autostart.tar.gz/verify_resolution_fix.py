#!/usr/bin/env python3
"""
Final Resolution Fix Verification Script
Verifies that the critical decision logic fix resolves low resolution captures
Run this after deploying the logic fix to slaves
"""

import os
import logging
import subprocess
import time
import json

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def check_logic_fix():
    """Check that the decision logic fix has been applied"""
    logging.info("🔍 Checking decision logic fix in still_capture.py...")
    
    still_capture_path = "/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py"
    
    try:
        with open(still_capture_path, 'r') as f:
            content = f.read()
        
        # Check for the fix indicators
        logic_indicators = [
            "Always use processing path for guaranteed high resolution",
            "Using processing path for guaranteed HIGH RESOLUTION", 
            "return capture_with_processing(filename)",
            "THIS WAS THE PROBLEM"
        ]
        
        found_indicators = []
        for indicator in logic_indicators:
            if indicator in content:
                found_indicators.append(indicator)
        
        # Check that old logic is commented out or removed
        old_logic_removed = "needs_processing = (" not in content or "# needs_processing = (" in content
        
        if len(found_indicators) >= 3 and old_logic_removed:
            logging.info("✅ Decision logic fix APPLIED: Always uses processing path")
            logging.info(f"   Found indicators: {len(found_indicators)}/4")
            logging.info(f"   Old logic removed: {old_logic_removed}")
            return True
        else:
            logging.error("❌ Decision logic fix NOT APPLIED")
            logging.error(f"   Found indicators: {len(found_indicators)}/4")
            logging.error(f"   Old logic removed: {old_logic_removed}")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to check logic fix: {e}")
        return False

def check_processing_enhancements():
    """Check that the processing function has been enhanced"""
    logging.info("🔍 Checking processing function enhancements...")
    
    still_capture_path = "/Users/andrew1/Desktop/camera_system_integrated_final/slave/still_capture.py"
    
    try:
        with open(still_capture_path, 'r') as f:
            content = f.read()
        
        # Check for enhancement indicators
        enhancement_indicators = [
            "GUARANTEED HIGH RESOLUTION",
            "NON-NEGOTIABLE",
            "Verify we got the expected high resolution",
            "file_size_mb",
            "File size.*MB seems small",
            "Transform changed resolution"
        ]
        
        found_enhancements = []
        for indicator in enhancement_indicators:
            if indicator in content:
                found_enhancements.append(indicator)
        
        if len(found_enhancements) >= 4:
            logging.info(f"✅ Processing enhancements APPLIED: {len(found_enhancements)}/6 features")
            return True
        else:
            logging.error(f"❌ Processing enhancements INCOMPLETE: {len(found_enhancements)}/6 features")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to check processing enhancements: {e}")
        return False

def simulate_capture_decision():
    """Simulate the capture decision logic"""
    logging.info("🧪 Simulating capture decision logic...")
    
    # Simulate default camera settings (no transforms enabled)
    default_settings = {
        'crop_enabled': False,
        'flip_horizontal': False,
        'flip_vertical': False,
        'grayscale': False,
        'rotation': 0
    }
    
    # Old logic (problematic)
    old_needs_processing = (
        default_settings.get('crop_enabled', False) or
        default_settings.get('flip_horizontal', False) or
        default_settings.get('flip_vertical', False) or
        default_settings.get('grayscale', False) or
        default_settings.get('rotation', 0) != 0
    )
    
    logging.info(f"📊 Simulation results:")
    logging.info(f"   Default settings: {default_settings}")
    logging.info(f"   Old logic would use: {'processing' if old_needs_processing else 'libcamera'} ← PROBLEM")
    logging.info(f"   New logic will use: processing ← SOLUTION")
    
    if not old_needs_processing:
        logging.info("✅ Confirmed: Default settings would trigger libcamera path (low res)")
        logging.info("✅ Fix: New logic always uses processing path (high res)")
        return True
    else:
        logging.warning("⚠️  Default settings would use processing path anyway")
        return False

def generate_deployment_plan():
    """Generate step-by-step deployment plan"""
    logging.info("📋 DEPLOYMENT PLAN:")
    logging.info("===================")
    logging.info("")
    logging.info("1. DEPLOY CRITICAL LOGIC FIX:")
    logging.info("   cd ~/Desktop/camera_system_integrated_final")
    logging.info("   ./sync_to_slaves.sh")
    logging.info("")
    logging.info("2. VERIFY DEPLOYMENT:")
    logging.info("   ssh andrc1@192.168.0.201 'systemctl status still_capture.service'")
    logging.info("   ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since=\"1 minute ago\" | grep RESTART'")
    logging.info("")
    logging.info("3. TEST HIGH RESOLUTION CAPTURE:")
    logging.info("   echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000")
    logging.info("")
    logging.info("4. CHECK FOR SUCCESS INDICATORS:")
    logging.info("   ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since=\"2 minutes ago\" | grep -E \"(HIGH RES|processing path)\"'")
    logging.info("")
    logging.info("5. VERIFY FILE PROPERTIES:")
    logging.info("   ssh andrc1@192.168.0.201 'ls -la /home/andrc1/camera_system_integrated_final/captured_images/ | tail -3'")
    logging.info("   ssh andrc1@192.168.0.201 'file /home/andrc1/camera_system_integrated_final/captured_images/rep1_*.jpg | tail -1'")
    logging.info("")
    logging.info("6. EXPECTED SUCCESS INDICATORS:")
    logging.info("   • Log: 'Using processing path for guaranteed HIGH RESOLUTION'")
    logging.info("   • Log: 'Captured HIGH RES (2592, 4608) RGB from camera'")
    logging.info("   • Log: 'HIGH RES image saved: filename (X.XMB, Q=95%)'")
    logging.info("   • File size: >1MB (preferably 2-4MB)")
    logging.info("   • Dimensions: 4608x2592 pixels")

def test_all_cameras():
    """Generate test commands for all cameras"""
    logging.info("")
    logging.info("🎯 TEST ALL CAMERAS:")
    logging.info("====================")
    
    for rep in range(1, 8):
        ip = f"192.168.0.20{rep}"
        logging.info(f"rep{rep} ({ip}):")
        logging.info(f"  echo 'CAPTURE_STILL' | nc -u {ip} 6000")
        logging.info(f"  ssh andrc1@{ip} 'journalctl -u still_capture.service --since=\"1 minute ago\" | grep \"HIGH RES\"'")
    
    # rep8 (local camera)
    logging.info("rep8 (192.168.0.200):")
    logging.info("  echo 'CAPTURE_STILL' | nc -u 192.168.0.200 6010")
    logging.info("  ssh andrc1@192.168.0.200 'journalctl -u local_camera_slave.service --since=\"1 minute ago\" | grep \"HIGH RES\"'")

def main():
    """Main verification function"""
    logging.info("🔧 CRITICAL RESOLUTION FIX VERIFICATION")
    logging.info("========================================")
    logging.info("")
    logging.info("PROBLEM: Images still low resolution despite previous fixes")
    logging.info("ROOT CAUSE: Decision logic used libcamera path (limited) when no transforms enabled")
    logging.info("SOLUTION: Always use processing path for guaranteed high resolution control")
    logging.info("")
    
    try:
        # Check that fixes have been applied
        logic_ok = check_logic_fix()
        processing_ok = check_processing_enhancements()
        simulation_ok = simulate_capture_decision()
        
        logging.info("")
        logging.info("📊 VERIFICATION RESULTS:")
        logging.info("========================")
        
        if logic_ok:
            logging.info("✅ Decision logic fix: APPLIED")
        else:
            logging.error("❌ Decision logic fix: NOT APPLIED")
        
        if processing_ok:
            logging.info("✅ Processing enhancements: APPLIED")
        else:
            logging.error("❌ Processing enhancements: INCOMPLETE")
        
        if simulation_ok:
            logging.info("✅ Decision simulation: Confirms fix addresses root cause")
        else:
            logging.warning("⚠️  Decision simulation: Unexpected result")
        
        if logic_ok and processing_ok:
            logging.info("")
            logging.info("🎉 CRITICAL FIX READY FOR DEPLOYMENT!")
            logging.info("This fix should resolve the low resolution issue by:")
            logging.info("• Always using processing path (guaranteed high resolution)")
            logging.info("• Enhanced verification and logging")
            logging.info("• Comprehensive error detection")
        else:
            logging.error("")
            logging.error("⚠️  CRITICAL FIX NEEDS ATTENTION")
            logging.error("Some components not properly applied")
        
        # Generate deployment instructions
        generate_deployment_plan()
        test_all_cameras()
        
    except Exception as e:
        logging.error(f"❌ Verification failed: {e}")

if __name__ == "__main__":
    main()
