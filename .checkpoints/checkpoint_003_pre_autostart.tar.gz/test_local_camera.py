#!/usr/bin/env python3
"""
Local Camera (rep8) Diagnostic Script
Tests still capture and transform functionality
"""

import os
import json
import time
import socket
import logging
import subprocess
import datetime
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def test_local_camera_service():
    """Test if local camera service is running"""
    logging.info("🔍 Testing local camera service status...")
    
    try:
        result = subprocess.run(["systemctl", "is-active", "local_camera_slave.service"], 
                              capture_output=True, text=True)
        status = result.stdout.strip()
        
        if status == "active":
            logging.info("✅ Local camera service is active")
            return True
        else:
            logging.error(f"❌ Local camera service is not active: {status}")
            
            # Show detailed status
            detail_result = subprocess.run(["systemctl", "status", "local_camera_slave.service", "--no-pager", "-l"], 
                                         capture_output=True, text=True)
            logging.error("Service status details:")
            for line in detail_result.stdout.split('\n')[:10]:
                logging.error(f"   {line}")
            return False
            
    except Exception as e:
        logging.error(f"❌ Error checking service: {e}")
        return False

def test_settings_file():
    """Test if rep8_settings.json exists and is readable"""
    logging.info("🔍 Testing rep8 settings file...")
    
    settings_file = "/Users/andrew1/Desktop/camera_system_integrated_final/rep8_settings.json"
    
    try:
        if not os.path.exists(settings_file):
            logging.error(f"❌ Settings file does not exist: {settings_file}")
            return False
            
        with open(settings_file, 'r') as f:
            settings = json.load(f)
            
        logging.info(f"✅ Settings file loaded successfully")
        logging.info(f"   flip_horizontal: {settings.get('flip_horizontal', False)}")
        logging.info(f"   flip_vertical: {settings.get('flip_vertical', False)}")
        logging.info(f"   rotation: {settings.get('rotation', 0)}")
        logging.info(f"   crop_enabled: {settings.get('crop_enabled', False)}")
        logging.info(f"   grayscale: {settings.get('grayscale', False)}")
        
        return True
        
    except Exception as e:
        logging.error(f"❌ Error reading settings file: {e}")
        return False

def test_still_capture_command():
    """Test sending still capture command to local camera"""
    logging.info("🔍 Testing still capture command...")
    
    try:
        # Send capture command to local camera port
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(5.0)
            sock.sendto(b"CAPTURE_STILL", ("127.0.0.1", 6010))
            
        logging.info("✅ Still capture command sent successfully")
        
        # Wait a moment for capture to complete
        time.sleep(3)
        
        # Check for recent capture files
        capture_dir = Path("/tmp")
        capture_files = list(capture_dir.glob("local_capture_*.jpg"))
        
        if capture_files:
            # Find most recent file
            latest_file = max(capture_files, key=lambda f: f.stat().st_mtime)
            file_size = latest_file.stat().st_size
            file_size_mb = file_size / (1024 * 1024)
            
            logging.info(f"✅ Found recent capture: {latest_file.name}")
            logging.info(f"   File size: {file_size_mb:.1f}MB")
            
            if file_size_mb > 1.0:
                logging.info("✅ File size indicates high resolution capture")
            else:
                logging.warning(f"⚠️ File size {file_size_mb:.1f}MB may indicate low resolution")
                
            return True
        else:
            logging.error("❌ No recent capture files found in /tmp")
            return False
            
    except Exception as e:
        logging.error(f"❌ Error testing still capture: {e}")
        return False

def test_transform_application():
    """Test transform application by temporarily enabling flip_vertical"""
    logging.info("🔍 Testing transform application...")
    
    settings_file = "/Users/andrew1/Desktop/camera_system_integrated_final/rep8_settings.json"
    backup_file = settings_file + ".test_backup"
    
    try:
        # Backup original settings
        with open(settings_file, 'r') as f:
            original_settings = json.load(f)
        with open(backup_file, 'w') as f:
            json.dump(original_settings, f, indent=2)
        logging.info("✅ Backed up original settings")
        
        # Enable flip_vertical for testing
        test_settings = original_settings.copy()
        test_settings['flip_vertical'] = True
        
        with open(settings_file, 'w') as f:
            json.dump(test_settings, f, indent=2)
        logging.info("✅ Enabled flip_vertical for testing")
        
        # Wait a moment for settings to be picked up
        time.sleep(2)
        
        # Trigger a capture
        logging.info("🔄 Triggering test capture with flip_vertical enabled...")
        test_still_capture_command()
        
        # Restore original settings
        with open(backup_file, 'r') as f:
            original_settings = json.load(f)
        with open(settings_file, 'w') as f:
            json.dump(original_settings, f, indent=2)
        os.remove(backup_file)
        logging.info("✅ Restored original settings")
        
        return True
        
    except Exception as e:
        logging.error(f"❌ Error testing transforms: {e}")
        # Try to restore settings if possible
        try:
            if os.path.exists(backup_file):
                with open(backup_file, 'r') as f:
                    original_settings = json.load(f)
                with open(settings_file, 'w') as f:
                    json.dump(original_settings, f, indent=2)
                os.remove(backup_file)
                logging.info("✅ Restored settings after error")
        except:
            logging.error("❌ Could not restore settings after error")
        return False

def check_service_logs():
    """Check recent service logs for errors"""
    logging.info("🔍 Checking recent service logs...")
    
    try:
        result = subprocess.run([
            "journalctl", "-u", "local_camera_slave.service", 
            "--since", "5 minutes ago", "--no-pager"
        ], capture_output=True, text=True)
        
        logs = result.stdout
        
        # Look for key indicators
        error_lines = [line for line in logs.split('\n') if 'ERROR' in line or 'Error' in line]
        transform_lines = [line for line in logs.split('\n') if 'Applied transforms' in line or 'Loaded settings' in line]
        
        if error_lines:
            logging.warning("⚠️ Found error lines in logs:")
            for line in error_lines[-5:]:  # Show last 5 errors
                logging.warning(f"   {line}")
        else:
            logging.info("✅ No recent errors in service logs")
            
        if transform_lines:
            logging.info("✅ Found transform activity in logs:")
            for line in transform_lines[-3:]:  # Show last 3 transform logs
                logging.info(f"   {line}")
        else:
            logging.warning("⚠️ No recent transform activity in logs")
            
        return True
        
    except Exception as e:
        logging.error(f"❌ Error checking logs: {e}")
        return False

def main():
    """Run all diagnostic tests"""
    logging.info("🚨 LOCAL CAMERA (rep8) DIAGNOSTIC STARTING")
    logging.info("="*60)
    
    tests_passed = 0
    total_tests = 5
    
    # Test 1: Service status
    if test_local_camera_service():
        tests_passed += 1
    
    # Test 2: Settings file
    if test_settings_file():
        tests_passed += 1
        
    # Test 3: Service logs
    if check_service_logs():
        tests_passed += 1
    
    # Test 4: Still capture command
    if test_still_capture_command():
        tests_passed += 1
        
    # Test 5: Transform application
    if test_transform_application():
        tests_passed += 1
    
    logging.info("="*60)
    logging.info(f"📊 DIAGNOSTIC RESULTS: {tests_passed}/{total_tests} tests passed")
    
    if tests_passed == total_tests:
        logging.info("🎉 ALL TESTS PASSED - Local camera should be working correctly!")
    elif tests_passed >= 3:
        logging.warning("⚠️ Most tests passed - minor issues may exist")
    else:
        logging.error("❌ Multiple tests failed - significant issues detected")
        
    logging.info("Next step: Check GUI to see if transforms are visible in video preview")

if __name__ == "__main__":
    main()
