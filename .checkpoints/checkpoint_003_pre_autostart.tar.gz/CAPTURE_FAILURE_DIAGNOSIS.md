# 🚨 STILL CAPTURE NOT WORKING ON REP1-7 - DIAGNOSIS & FIX

## Current Status
- ✅ **rep8 (local)**: Still capture works
- ❌ **rep1-7**: Still capture does NOT work from GUI

## 🔍 **STEP 1: Run Diagnosis (MOST IMPORTANT)**

SSH into control1 and run the comprehensive diagnosis:

```bash
ssh andrc1@192.168.0.200
cd /home/andrc1/camera_system_integrated_final
./diagnose_capture_failure.sh
```

This will check:
- ✅ Network connectivity to each device
- ✅ Service status (still_capture.service)
- ✅ Device detection logs (should show correct rep number)
- ✅ Port binding (should bind to 6000)
- ✅ Port listening (service accepting connections)
- ✅ Command reception test

## 🧪 **STEP 2: Test Manual Capture**

Test each device manually to isolate GUI vs service issues:

```bash
./test_manual_capture.sh
```

This sends UDP commands directly to each device to test if the services are working.

## 🔧 **STEP 3: Quick Fix Attempt**

If services are installed but not working correctly:

```bash
./quick_fix_capture.sh
```

This restarts all still capture services and verifies they're working.

## 📋 **LIKELY ISSUES & SOLUTIONS**

### **Issue A: Services Not Running**
**Symptoms**: Diagnosis shows services inactive
**Solution**: 
```bash
# Re-deploy completely
./sync_to_slaves.sh
```

### **Issue B: Wrong Device Detection**
**Symptoms**: Device detection shows wrong rep number (e.g., rep1 shows as rep8)
**Solution**: Check hostname and IP detection
```bash
# Check individual device
ssh andrc1@192.168.0.201 'hostname'
ssh andrc1@192.168.0.201 'ip addr show | grep 192.168.0'
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service -f'
```

### **Issue C: Port Binding Problems**
**Symptoms**: Service running but not listening on port 6000
**Solution**: 
```bash
# Check what's using port 6000
ssh andrc1@192.168.0.201 'netstat -ulnp | grep 6000'
# Restart service
ssh andrc1@192.168.0.201 'sudo systemctl restart still_capture.service'
```

### **Issue D: GUI Communication Problem**
**Symptoms**: Manual tests work, but GUI doesn't
**Solution**: 
- Check GUI is sending to correct IPs (192.168.0.201-207)
- Check GUI is using port 6000 for rep1-7
- Check GUI logs for errors

## 🎯 **STEP-BY-STEP TROUBLESHOOTING**

### **1. Quick Check Individual Device (Example: rep1)**
```bash
# Check service status
ssh andrc1@192.168.0.201 'systemctl status still_capture.service'

# Check recent logs
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since="5 minutes ago"'

# Test manual capture
echo 'CAPTURE_STILL' | nc -u 192.168.0.201 6000

# Check if command was received
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since="30 seconds ago" | grep CAPTURE'
```

### **2. If Service Not Running**
```bash
# Check service file exists
ssh andrc1@192.168.0.201 'ls -la /etc/systemd/system/still_capture.service'

# Restart service
ssh andrc1@192.168.0.201 'sudo systemctl daemon-reload'
ssh andrc1@192.168.0.201 'sudo systemctl enable still_capture.service'
ssh andrc1@192.168.0.201 'sudo systemctl start still_capture.service'
```

### **3. If Wrong Device Detection**
```bash
# Check what IP detection methods found
ssh andrc1@192.168.0.201 'journalctl -u still_capture.service --since="5 minutes ago" | grep Method'

# Check hostname patterns
ssh andrc1@192.168.0.201 'hostname'
ssh andrc1@192.168.0.201 'cat /etc/hostname'

# Check IP detection
ssh andrc1@192.168.0.201 'ip addr show'
```

## 🚨 **EMERGENCY FULL RE-DEPLOYMENT**

If diagnosis shows multiple issues, completely re-deploy:

```bash
# 1. Stop all services
for i in {1..7}; do
  ssh andrc1@192.168.0.20$i 'sudo systemctl stop still_capture.service video_stream.service' 2>/dev/null || true
done

# 2. Re-deploy everything
./sync_to_slaves.sh

# 3. Verify deployment
./diagnose_capture_failure.sh
```

## 📊 **EXPECTED WORKING STATE**

After fixes, you should see:
```
rep1: ✅ Service active, device detection correct, port 6000 listening
rep2: ✅ Service active, device detection correct, port 6000 listening
rep3: ✅ Service active, device detection correct, port 6000 listening
rep4: ✅ Service active, device detection correct, port 6000 listening
rep5: ✅ Service active, device detection correct, port 6000 listening
rep6: ✅ Service active, device detection correct, port 6000 listening
rep7: ✅ Service active, device detection correct, port 6000 listening
```

## 🎯 **MOST LIKELY CAUSE**

Based on "only rep8 works", the most likely issue is:
1. **Services not properly deployed** to rep1-7
2. **Device detection still failing** on rep1-7
3. **Services not listening** on correct ports

Run the diagnosis script first - it will pinpoint exactly what's wrong! 

## 📞 **Immediate Action Plan**

1. **Run**: `./diagnose_capture_failure.sh`
2. **Based on results**, run appropriate fix
3. **Test**: GUI still capture after fixes
4. **If still failing**: Check GUI configuration

The diagnosis will tell us exactly what's wrong! 🔍
