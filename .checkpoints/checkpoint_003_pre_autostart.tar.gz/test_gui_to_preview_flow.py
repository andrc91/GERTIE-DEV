#!/usr/bin/env python3
"""
GUI Command Flow Test - Verify settings reach video previews
Tests complete chain: GUI command → settings file → video stream restart → visible changes
"""

import socket
import time
import json
import logging
import subprocess
import sys

logging.basicConfig(level=logging.INFO, format='%(levelname)s - %(message)s')

def test_gui_to_preview_flow(target_ip, target_rep):
    """Test complete GUI→preview command flow for one device"""
    logging.info(f"🧪 Testing GUI→preview flow for {target_rep} ({target_ip})")
    
    # Step 1: Send factory reset command (simulates GUI button)
    logging.info(f"🔄 Step 1: Sending factory reset to {target_rep}...")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(5.0)
            sock.sendto(b"RESET_TO_FACTORY_DEFAULTS", (target_ip, 5001))
            logging.info(f"✅ Factory reset command sent to {target_rep}")
    except Exception as e:
        logging.error(f"❌ Failed to send factory reset: {e}")
        return False
    
    # Wait for reset to process
    time.sleep(5)
    
    # Step 2: Check settings file was created/reset
    settings_file = f"/home/andrc1/{target_rep}_settings.json"
    logging.info(f"🔍 Step 2: Checking settings file {settings_file}...")
    
    if target_ip == "127.0.0.1":
        # Local check
        try:
            with open(settings_file, 'r') as f:
                settings = json.load(f)
            if settings.get('brightness') == 50 and settings.get('grayscale') == False:
                logging.info(f"✅ {target_rep}: Settings file reset correctly (brightness=50, grayscale=false)")
            else:
                logging.error(f"❌ {target_rep}: Settings file not reset properly")
                return False
        except Exception as e:
            logging.error(f"❌ {target_rep}: Could not read local settings file: {e}")
            return False
    else:
        # Remote check
        try:
            result = subprocess.run(
                ["ssh", f"andrc1@{target_ip}", f"cat {settings_file}"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                settings = json.loads(result.stdout)
                if settings.get('brightness') == 50 and settings.get('grayscale') == False:
                    logging.info(f"✅ {target_rep}: Remote settings file reset correctly")
                else:
                    logging.error(f"❌ {target_rep}: Remote settings not reset properly")
                    return False
            else:
                logging.error(f"❌ {target_rep}: Could not read remote settings file")
                return False
        except Exception as e:
            logging.error(f"❌ {target_rep}: Remote settings check failed: {e}")
            return False
    
    # Step 3: Send distinctive test settings (simulates GUI changes)
    logging.info(f"🎨 Step 3: Sending test transform settings to {target_rep}...")
    test_settings = {
        'brightness': 85,     # Should be visible in preview
        'grayscale': True,    # Should make preview grayscale  
        'rotation': 90,       # Should rotate preview
        'flip_horizontal': True  # Should flip preview
    }
    
    settings_command = f"SET_ALL_SETTINGS_{json.dumps(test_settings)}"
    
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(5.0)
            sock.sendto(settings_command.encode(), (target_ip, 5001))
            logging.info(f"✅ Test settings sent to {target_rep}")
    except Exception as e:
        logging.error(f"❌ Failed to send test settings: {e}")
        return False
    
    # Wait for settings to apply
    time.sleep(8)
    
    # Step 4: Verify settings were saved
    logging.info(f"🔍 Step 4: Verifying test settings were applied...")
    
    if target_ip == "127.0.0.1":
        # Local verification
        try:
            with open(settings_file, 'r') as f:
                settings = json.load(f)
            if (settings.get('brightness') == 85 and 
                settings.get('grayscale') == True and
                settings.get('rotation') == 90 and
                settings.get('flip_horizontal') == True):
                logging.info(f"✅ {target_rep}: Test settings verified locally")
            else:
                logging.error(f"❌ {target_rep}: Test settings not applied locally")
                logging.error(f"   Expected: brightness=85, grayscale=true, rotation=90, flip_horizontal=true")
                logging.error(f"   Got: brightness={settings.get('brightness')}, grayscale={settings.get('grayscale')}, rotation={settings.get('rotation')}, flip_horizontal={settings.get('flip_horizontal')}")
                return False
        except Exception as e:
            logging.error(f"❌ {target_rep}: Could not verify local test settings: {e}")
            return False
    else:
        # Remote verification
        try:
            result = subprocess.run(
                ["ssh", f"andrc1@{target_ip}", f"cat {settings_file}"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                settings = json.loads(result.stdout)
                if (settings.get('brightness') == 85 and 
                    settings.get('grayscale') == True and
                    settings.get('rotation') == 90 and
                    settings.get('flip_horizontal') == True):
                    logging.info(f"✅ {target_rep}: Test settings verified remotely")
                else:
                    logging.error(f"❌ {target_rep}: Test settings not applied remotely")
                    return False
            else:
                logging.error(f"❌ {target_rep}: Could not verify remote test settings")
                return False
        except Exception as e:
            logging.error(f"❌ {target_rep}: Remote verification failed: {e}")
            return False
    
    # Step 5: Final reset to defaults
    logging.info(f"🔄 Step 5: Final reset to defaults for {target_rep}...")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(5.0)
            sock.sendto(b"RESET_TO_FACTORY_DEFAULTS", (target_ip, 5001))
            logging.info(f"✅ Final reset sent to {target_rep}")
    except Exception as e:
        logging.error(f"❌ Failed to send final reset: {e}")
        return False
    
    time.sleep(3)
    
    logging.info(f"🎉 {target_rep}: Complete GUI→preview flow test PASSED")
    logging.info(f"👁️  CHECK GUI NOW: {target_rep} preview should show factory defaults")
    logging.info(f"   - Brightness should be normal (not bright)")
    logging.info(f"   - Should be color (not grayscale)")
    logging.info(f"   - Should not be rotated")
    logging.info(f"   - Should not be flipped")
    
    return True

def main():
    """Test GUI command flow on multiple devices"""
    logging.info("🚀 Testing GUI→Preview command flow")
    
    # Test devices
    test_devices = [
        ("192.168.0.201", "rep1"),
        ("127.0.0.1", "rep8")  # Local camera
    ]
    
    success_count = 0
    
    for ip, rep_name in test_devices:
        logging.info(f"\n{'='*50}")
        
        if test_gui_to_preview_flow(ip, rep_name):
            success_count += 1
            logging.info(f"✅ {rep_name}: GUI→Preview flow test PASSED")
        else:
            logging.error(f"❌ {rep_name}: GUI→Preview flow test FAILED")
    
    logging.info(f"\n📊 GUI→Preview Flow Test Results:")
    logging.info(f"   Tested: {len(test_devices)} devices")
    logging.info(f"   Passed: {success_count}")
    logging.info(f"   Success Rate: {(success_count/len(test_devices))*100:.1f}%")
    
    if success_count == len(test_devices):
        logging.info(f"🎉 ALL GUI→PREVIEW TESTS PASSED!")
        logging.info(f"👁️  Check GUI now - previews should be visually reset to defaults")
        return True
    else:
        logging.error(f"❌ Some GUI→Preview tests failed")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
